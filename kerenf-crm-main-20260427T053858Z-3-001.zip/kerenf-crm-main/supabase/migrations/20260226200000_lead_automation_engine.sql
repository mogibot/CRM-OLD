-- ============================================================
-- Lead Generation Optimization: Automation Engine + Schema Updates
-- ============================================================

-- ── 1. Automation Execution Log Table ──
-- Tracks every automation that fired, for debugging and audit
CREATE TABLE IF NOT EXISTS public.automation_runs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  automation_id UUID REFERENCES public.automations(id) ON DELETE SET NULL,
  lead_id UUID REFERENCES public.leads(id) ON DELETE SET NULL,
  trigger_type TEXT NOT NULL,
  actions_executed JSONB DEFAULT '[]',
  status TEXT NOT NULL DEFAULT 'success',
  error_message TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.automation_runs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can view automation runs"
  ON public.automation_runs FOR SELECT TO authenticated USING (true);

CREATE POLICY "System can insert automation runs"
  ON public.automation_runs FOR INSERT WITH CHECK (true);

-- ── 2. Automation Execution Engine (PL/pgSQL) ──
-- Fires on new lead INSERT. Checks active automations with trigger_type = 'new_lead'
-- and executes internal CRM actions (create task, add note, change stage, add tag).

CREATE OR REPLACE FUNCTION public.execute_lead_automations()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  auto_record RECORD;
  action_item JSONB;
  actions_executed JSONB;
  action_type TEXT;
  run_status TEXT;
  error_msg TEXT;
BEGIN
  -- Only process new leads (stage = 'new_lead')
  IF NEW.stage != 'new_lead' THEN
    RETURN NEW;
  END IF;

  -- Find all active automations that trigger on new_lead
  FOR auto_record IN
    SELECT id, name, trigger_config, actions
    FROM public.automations
    WHERE is_active = true
      AND trigger_type = 'new_lead'
    ORDER BY created_at ASC
  LOOP
    BEGIN
      actions_executed := '[]'::JSONB;
      run_status := 'success';
      error_msg := NULL;

      -- Check trigger conditions (source filter)
      IF auto_record.trigger_config ? 'field'
         AND auto_record.trigger_config->>'field' = 'source'
         AND auto_record.trigger_config ? 'value'
         AND auto_record.trigger_config->>'value' != NEW.source::TEXT THEN
        CONTINUE; -- Skip this automation, source doesn't match
      END IF;

      -- Execute each action in the automation
      FOR action_item IN SELECT * FROM jsonb_array_elements(auto_record.actions)
      LOOP
        action_type := action_item->>'type';

        IF action_type = 'create_task' THEN
          -- Create a follow-up task for the assigned agent
          INSERT INTO public.tasks (
            lead_id, assigned_to, title, description, priority, due_date
          ) VALUES (
            NEW.id,
            NEW.assigned_to,
            COALESCE(action_item->>'task_title', 'טיפול בליד חדש: ' || NEW.full_name),
            COALESCE(action_item->>'value', 'ליד חדש נכנס למערכת. יש ליצור קשר.'),
            'high',
            now() + INTERVAL '1 day'
          );
          actions_executed := actions_executed || jsonb_build_object('type', 'create_task', 'done', true);

        ELSIF action_type = 'update_lead' THEN
          -- Update a field on the lead (e.g., auto-assign, change stage)
          IF action_item->>'field' = 'stage' AND action_item->>'value' IS NOT NULL THEN
            UPDATE public.leads SET stage = (action_item->>'value')::lead_stage WHERE id = NEW.id;
          ELSIF action_item->>'field' = 'assigned_to' AND action_item->>'value' IS NOT NULL THEN
            UPDATE public.leads SET assigned_to = (action_item->>'value')::UUID WHERE id = NEW.id;
          ELSIF action_item->>'field' = 'score' AND action_item->>'value' IS NOT NULL THEN
            UPDATE public.leads SET score = (action_item->>'value')::INTEGER WHERE id = NEW.id;
          END IF;
          actions_executed := actions_executed || jsonb_build_object('type', 'update_lead', 'field', action_item->>'field', 'done', true);

        ELSIF action_type = 'send_notification' THEN
          -- Create a note as a notification (visible in lead activity)
          INSERT INTO public.lead_notes (lead_id, content)
          VALUES (
            NEW.id,
            COALESCE(action_item->>'notification_text', 'התראה: ליד חדש נכנס למערכת')
          );
          -- Also log as activity
          INSERT INTO public.lead_activities (lead_id, activity_type, description)
          VALUES (NEW.id, 'note_added', COALESCE(action_item->>'notification_text', 'התראה אוטומטית: ליד חדש'));
          actions_executed := actions_executed || jsonb_build_object('type', 'send_notification', 'done', true);

        END IF;
      END LOOP;

      -- Log the automation run
      INSERT INTO public.automation_runs (automation_id, lead_id, trigger_type, actions_executed, status, error_message)
      VALUES (auto_record.id, NEW.id, 'new_lead', actions_executed, run_status, error_msg);

    EXCEPTION WHEN OTHERS THEN
      -- Log failed automation run (don't block lead creation)
      INSERT INTO public.automation_runs (automation_id, lead_id, trigger_type, actions_executed, status, error_message)
      VALUES (auto_record.id, NEW.id, 'new_lead', '[]'::JSONB, 'error', SQLERRM);
    END;
  END LOOP;

  RETURN NEW;
END;
$$;

-- Create the trigger (AFTER INSERT so the lead row exists)
DROP TRIGGER IF EXISTS trigger_lead_automations ON public.leads;
CREATE TRIGGER trigger_lead_automations
  AFTER INSERT ON public.leads
  FOR EACH ROW
  EXECUTE FUNCTION public.execute_lead_automations();

-- ── 3. Stage-change automation trigger ──
-- Fires when lead.stage changes (for automations with trigger_type = 'stage_changed')

CREATE OR REPLACE FUNCTION public.execute_stage_change_automations()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  auto_record RECORD;
  action_item JSONB;
  actions_executed JSONB;
  action_type TEXT;
BEGIN
  -- Only fire when stage actually changed
  IF OLD.stage = NEW.stage THEN
    RETURN NEW;
  END IF;

  -- Log the stage change activity
  INSERT INTO public.lead_activities (lead_id, activity_type, description, metadata)
  VALUES (
    NEW.id,
    'stage_changed',
    'שלב השתנה מ-' || OLD.stage::TEXT || ' ל-' || NEW.stage::TEXT,
    jsonb_build_object('from', OLD.stage::TEXT, 'to', NEW.stage::TEXT)
  );

  -- Find matching automations
  FOR auto_record IN
    SELECT id, name, trigger_config, actions
    FROM public.automations
    WHERE is_active = true
      AND trigger_type = 'stage_changed'
      AND (
        NOT (trigger_config ? 'value')
        OR trigger_config->>'value' = NEW.stage::TEXT
      )
    ORDER BY created_at ASC
  LOOP
    BEGIN
      actions_executed := '[]'::JSONB;

      FOR action_item IN SELECT * FROM jsonb_array_elements(auto_record.actions)
      LOOP
        action_type := action_item->>'type';

        IF action_type = 'create_task' THEN
          INSERT INTO public.tasks (lead_id, assigned_to, title, priority, due_date)
          VALUES (
            NEW.id,
            NEW.assigned_to,
            COALESCE(action_item->>'task_title', 'משימה לשלב: ' || NEW.stage::TEXT),
            'medium',
            now() + INTERVAL '1 day'
          );
          actions_executed := actions_executed || jsonb_build_object('type', 'create_task', 'done', true);

        ELSIF action_type = 'send_notification' THEN
          INSERT INTO public.lead_activities (lead_id, activity_type, description)
          VALUES (NEW.id, 'note_added', COALESCE(action_item->>'notification_text', 'התראה: שלב הליד השתנה'));
          actions_executed := actions_executed || jsonb_build_object('type', 'send_notification', 'done', true);
        END IF;
      END LOOP;

      INSERT INTO public.automation_runs (automation_id, lead_id, trigger_type, actions_executed, status)
      VALUES (auto_record.id, NEW.id, 'stage_changed', actions_executed, 'success');

    EXCEPTION WHEN OTHERS THEN
      INSERT INTO public.automation_runs (automation_id, lead_id, trigger_type, actions_executed, status, error_message)
      VALUES (auto_record.id, NEW.id, 'stage_changed', '[]'::JSONB, 'error', SQLERRM);
    END;
  END LOOP;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trigger_stage_change_automations ON public.leads;
CREATE TRIGGER trigger_stage_change_automations
  AFTER UPDATE ON public.leads
  FOR EACH ROW
  EXECUTE FUNCTION public.execute_stage_change_automations();

-- ── 4. Enable realtime for key tables ──
-- leads was already added in a previous migration; add integration_logs and tasks
DO $$
BEGIN
  -- Safely add tables to realtime publication
  BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.integration_logs;
  EXCEPTION WHEN duplicate_object THEN
    NULL; -- Already added
  END;

  BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.tasks;
  EXCEPTION WHEN duplicate_object THEN
    NULL;
  END;

  BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.lead_activities;
  EXCEPTION WHEN duplicate_object THEN
    NULL;
  END;
END;
$$;

-- ── 5. Index improvements for deduplication performance ──
CREATE INDEX IF NOT EXISTS idx_leads_phone ON public.leads(phone) WHERE phone IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_leads_email ON public.leads(email) WHERE email IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_leads_stage ON public.leads(stage);
CREATE INDEX IF NOT EXISTS idx_leads_source ON public.leads(source);
CREATE INDEX IF NOT EXISTS idx_leads_created_at ON public.leads(created_at DESC);
