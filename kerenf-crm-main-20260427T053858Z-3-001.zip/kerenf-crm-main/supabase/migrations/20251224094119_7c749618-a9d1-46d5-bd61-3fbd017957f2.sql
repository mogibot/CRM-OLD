-- Create integration_logs table for tracking webhook requests
CREATE TABLE public.integration_logs (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  source TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'success',
  request_data JSONB,
  response_data JSONB,
  error_message TEXT,
  lead_id UUID REFERENCES public.leads(id) ON DELETE SET NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.integration_logs ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Anyone can view integration logs"
ON public.integration_logs
FOR SELECT
USING (true);

CREATE POLICY "System can insert integration logs"
ON public.integration_logs
FOR INSERT
WITH CHECK (true);

-- Create index for faster queries by source and date
CREATE INDEX idx_integration_logs_source ON public.integration_logs(source);
CREATE INDEX idx_integration_logs_created_at ON public.integration_logs(created_at DESC);