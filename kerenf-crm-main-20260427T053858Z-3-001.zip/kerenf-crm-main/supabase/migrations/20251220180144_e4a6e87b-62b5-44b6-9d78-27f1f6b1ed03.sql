-- Add external fields to leads table for webhook integrations
ALTER TABLE public.leads 
ADD COLUMN IF NOT EXISTS external_id TEXT,
ADD COLUMN IF NOT EXISTS external_source TEXT,
ADD COLUMN IF NOT EXISTS raw_data JSONB DEFAULT '{}'::jsonb;

-- Create index for external lookups
CREATE INDEX IF NOT EXISTS idx_leads_external ON public.leads(external_source, external_id);

-- Drop existing restrictive RLS policies
DROP POLICY IF EXISTS "Admins and managers can manage all leads" ON public.leads;
DROP POLICY IF EXISTS "Admins and managers can view all leads" ON public.leads;
DROP POLICY IF EXISTS "Investor guides can update assigned leads" ON public.leads;
DROP POLICY IF EXISTS "Investor guides can view assigned leads" ON public.leads;

-- Create new permissive policies for public access (no auth required)
CREATE POLICY "Anyone can view leads" ON public.leads FOR SELECT USING (true);
CREATE POLICY "Anyone can insert leads" ON public.leads FOR INSERT WITH CHECK (true);
CREATE POLICY "Anyone can update leads" ON public.leads FOR UPDATE USING (true);
CREATE POLICY "Anyone can delete leads" ON public.leads FOR DELETE USING (true);

-- Update other tables for public access
DROP POLICY IF EXISTS "Users can view activities on accessible leads" ON public.lead_activities;
DROP POLICY IF EXISTS "Users can create activities" ON public.lead_activities;
CREATE POLICY "Anyone can view activities" ON public.lead_activities FOR SELECT USING (true);
CREATE POLICY "Anyone can insert activities" ON public.lead_activities FOR INSERT WITH CHECK (true);

-- Update lead_tags for public access
DROP POLICY IF EXISTS "Admins and managers can manage tags" ON public.lead_tags;
DROP POLICY IF EXISTS "All authenticated users can view tags" ON public.lead_tags;
CREATE POLICY "Anyone can view tags" ON public.lead_tags FOR SELECT USING (true);
CREATE POLICY "Anyone can manage tags" ON public.lead_tags FOR ALL USING (true);

-- Update leads_tags junction table
DROP POLICY IF EXISTS "Admins and managers can manage lead tags" ON public.leads_tags;
DROP POLICY IF EXISTS "Users can view lead tags" ON public.leads_tags;
CREATE POLICY "Anyone can view lead_tags" ON public.leads_tags FOR SELECT USING (true);
CREATE POLICY "Anyone can manage lead_tags" ON public.leads_tags FOR ALL USING (true);

-- Update profiles for public access
DROP POLICY IF EXISTS "Users can view all profiles" ON public.profiles;
DROP POLICY IF EXISTS "Users can update own profile" ON public.profiles;
DROP POLICY IF EXISTS "Users can insert own profile" ON public.profiles;
CREATE POLICY "Anyone can view profiles" ON public.profiles FOR SELECT USING (true);
CREATE POLICY "Anyone can manage profiles" ON public.profiles FOR ALL USING (true);