-- Update handle_new_user function to assign admin role for specific email and set name to "קרנף"
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Create profile with custom name for admin email
  INSERT INTO public.profiles (id, full_name, avatar_url)
  VALUES (
    NEW.id,
    CASE 
      WHEN NEW.email = 'ivritoys@gmail.com' THEN 'קרנף'
      ELSE COALESCE(NEW.raw_user_meta_data ->> 'full_name', NEW.email)
    END,
    NEW.raw_user_meta_data ->> 'avatar_url'
  );
  
  -- Assign admin role for specific email, otherwise default to investor_guide
  INSERT INTO public.user_roles (user_id, role)
  VALUES (
    NEW.id, 
    CASE 
      WHEN NEW.email = 'ivritoys@gmail.com' THEN 'admin'::app_role
      ELSE 'investor_guide'::app_role
    END
  );
  
  RETURN NEW;
END;
$$;