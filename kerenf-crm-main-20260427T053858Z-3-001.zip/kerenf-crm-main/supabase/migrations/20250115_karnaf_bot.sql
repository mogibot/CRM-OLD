-- Karnaf Bot: Add bot fields to leads + new tables
-- Migration: 20250115_karnaf_bot.sql

-- 1. Add bot-related fields to leads table
ALTER TABLE leads ADD COLUMN IF NOT EXISTS product_interest text;
ALTER TABLE leads ADD COLUMN IF NOT EXISTS bot_score integer DEFAULT 0;
ALTER TABLE leads ADD COLUMN IF NOT EXISTS bot_stage text DEFAULT 'new';
ALTER TABLE leads ADD COLUMN IF NOT EXISTS wati_contact_id text;
ALTER TABLE leads ADD COLUMN IF NOT EXISTS last_bot_message_at timestamptz;
ALTER TABLE leads ADD COLUMN IF NOT EXISTS transferred_to_agent_at timestamptz;
ALTER TABLE leads ADD COLUMN IF NOT EXISTS agent_notes text;

CREATE INDEX IF NOT EXISTS idx_leads_bot_stage ON leads(bot_stage);
CREATE INDEX IF NOT EXISTS idx_leads_wati_contact_id ON leads(wati_contact_id);

-- 2. Bot sessions table
CREATE TABLE IF NOT EXISTS bot_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id uuid REFERENCES leads(id) ON DELETE CASCADE,
  wati_phone text NOT NULL,
  state jsonb NOT NULL DEFAULT '{}',
  last_activity timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_bot_sessions_lead ON bot_sessions(lead_id);
CREATE INDEX IF NOT EXISTS idx_bot_sessions_phone ON bot_sessions(wati_phone);

-- 3. Work queue table
CREATE TABLE IF NOT EXISTS work_queue (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id uuid REFERENCES leads(id) ON DELETE CASCADE,
  reason text NOT NULL,
  priority integer DEFAULT 5,
  status text DEFAULT 'pending',
  agent_id uuid REFERENCES profiles(id),
  created_at timestamptz DEFAULT now(),
  resolved_at timestamptz
);

CREATE INDEX IF NOT EXISTS idx_work_queue_status ON work_queue(status);
CREATE INDEX IF NOT EXISTS idx_work_queue_priority ON work_queue(priority, created_at);

-- 4. Bot config table (key-value store)
CREATE TABLE IF NOT EXISTS bot_config (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  key text UNIQUE NOT NULL,
  value jsonb,
  updated_at timestamptz DEFAULT now()
);

-- Insert default config
INSERT INTO bot_config (key, value) VALUES
  ('system_prompt', '{"content": "אתה נציג מכירות של קרנף נדל״ן..."}'),
  ('transfer_threshold', '{"score": 80}'),
  ('active_hours', '{"start": "09:00", "end": "21:00"}')
ON CONFLICT (key) DO NOTHING;

-- 5. RLS policies
ALTER TABLE bot_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE work_queue ENABLE ROW LEVEL SECURITY;
ALTER TABLE bot_config ENABLE ROW LEVEL SECURITY;

-- Bot sessions: authenticated users can read
CREATE POLICY "Authenticated users can view bot_sessions"
  ON bot_sessions FOR SELECT
  USING (auth.role() = 'authenticated');

CREATE POLICY "Service role can manage bot_sessions"
  ON bot_sessions FOR ALL
  USING (true);

-- Work queue: authenticated users can read and update
CREATE POLICY "Authenticated users can view work_queue"
  ON work_queue FOR SELECT
  USING (auth.role() = 'authenticated');

CREATE POLICY "Authenticated users can update work_queue"
  ON work_queue FOR UPDATE
  USING (auth.role() = 'authenticated');

CREATE POLICY "Service role can manage work_queue"
  ON work_queue FOR ALL
  USING (true);

-- Bot config: authenticated users can read and manage
CREATE POLICY "Authenticated users can view bot_config"
  ON bot_config FOR SELECT
  USING (auth.role() = 'authenticated');

CREATE POLICY "Authenticated users can manage bot_config"
  ON bot_config FOR ALL
  USING (auth.role() = 'authenticated');
