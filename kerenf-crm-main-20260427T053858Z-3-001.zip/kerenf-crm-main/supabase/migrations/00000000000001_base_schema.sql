-- Create enum for user roles
CREATE TYPE public.app_role AS ENUM ('admin', 'manager', 'investor_guide');

-- Create enum for lead stages
CREATE TYPE public.lead_stage AS ENUM (
  'new_lead',
  'contacted',
  'follow_up',
  'info_sent',
  'meeting_scheduled',
  'evaluation',
  'closing',
  'closed_won',
  'closed_lost',
  'not_relevant'
);

-- Create enum for lead sources
CREATE TYPE public.lead_source AS ENUM (
  'instagram',
  'facebook',
  'whatsapp',
  'manychat',
  'smoov',
  'wix_site',
  'email_list',
  'referral',
  'campaign',
  'manual'
);

-- Create enum for message channels
CREATE TYPE public.message_channel AS ENUM (
  'whatsapp',
  'instagram',
  'facebook',
  'email',
  'sms'
);

-- Create enum for activity types
CREATE TYPE public.activity_type AS ENUM (
  'call',
  'message_sent',
  'message_received',
  'meeting',
  'note_added',
  'stage_changed',
  'tag_added',
  'document_uploaded',
  'task_created',
  'email_sent',
  'email_received'
);

-- Create profiles table
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name TEXT NOT NULL,
  avatar_url TEXT,
  phone TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Create user_roles table (separate for security)
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  role app_role NOT NULL DEFAULT 'investor_guide',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);

-- Create lead_tags table
CREATE TABLE public.lead_tags (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  color TEXT NOT NULL DEFAULT '#3B82F6',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Create leads table
CREATE TABLE public.leads (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name TEXT NOT NULL,
  email TEXT,
  phone TEXT,
  source lead_source NOT NULL DEFAULT 'manual',
  stage lead_stage NOT NULL DEFAULT 'new_lead',
  score INTEGER DEFAULT 0 CHECK (score >= 0 AND score <= 100),
  assigned_to UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  notes TEXT,
  city TEXT,
  budget_min NUMERIC,
  budget_max NUMERIC,
  property_interest TEXT,
  last_contact_at TIMESTAMPTZ,
  next_follow_up_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Create leads_tags junction table
CREATE TABLE public.leads_tags (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id UUID REFERENCES public.leads(id) ON DELETE CASCADE NOT NULL,
  tag_id UUID REFERENCES public.lead_tags(id) ON DELETE CASCADE NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (lead_id, tag_id)
);

-- Create lead_notes table
CREATE TABLE public.lead_notes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id UUID REFERENCES public.leads(id) ON DELETE CASCADE NOT NULL,
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  content TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Create lead_activities table
CREATE TABLE public.lead_activities (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id UUID REFERENCES public.leads(id) ON DELETE CASCADE NOT NULL,
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  activity_type activity_type NOT NULL,
  description TEXT,
  metadata JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Create lead_documents table
CREATE TABLE public.lead_documents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id UUID REFERENCES public.leads(id) ON DELETE CASCADE NOT NULL,
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  file_name TEXT NOT NULL,
  file_url TEXT NOT NULL,
  file_type TEXT,
  file_size INTEGER,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Create conversations table
CREATE TABLE public.conversations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id UUID REFERENCES public.leads(id) ON DELETE CASCADE NOT NULL,
  channel message_channel NOT NULL,
  external_id TEXT,
  last_message_at TIMESTAMPTZ,
  unread_count INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Create messages table
CREATE TABLE public.messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id UUID REFERENCES public.conversations(id) ON DELETE CASCADE NOT NULL,
  sender_type TEXT NOT NULL CHECK (sender_type IN ('user', 'lead', 'system')),
  sender_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  content TEXT NOT NULL,
  attachments JSONB DEFAULT '[]',
  is_read BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Create tasks table
CREATE TABLE public.tasks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id UUID REFERENCES public.leads(id) ON DELETE CASCADE,
  assigned_to UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  title TEXT NOT NULL,
  description TEXT,
  due_date TIMESTAMPTZ,
  is_completed BOOLEAN DEFAULT false,
  priority TEXT DEFAULT 'medium' CHECK (priority IN ('low', 'medium', 'high', 'urgent')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Create calendar_events table
CREATE TABLE public.calendar_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id UUID REFERENCES public.leads(id) ON DELETE SET NULL,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  title TEXT NOT NULL,
  description TEXT,
  start_time TIMESTAMPTZ NOT NULL,
  end_time TIMESTAMPTZ NOT NULL,
  location TEXT,
  google_event_id TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Create automations table
CREATE TABLE public.automations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT,
  is_active BOOLEAN DEFAULT true,
  trigger_type TEXT NOT NULL,
  trigger_config JSONB DEFAULT '{}',
  actions JSONB DEFAULT '[]',
  created_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Create ai_insights table
CREATE TABLE public.ai_insights (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id UUID REFERENCES public.leads(id) ON DELETE CASCADE,
  insight_type TEXT NOT NULL,
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  priority TEXT DEFAULT 'medium' CHECK (priority IN ('low', 'medium', 'high')),
  is_dismissed BOOLEAN DEFAULT false,
  action_taken BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Create message_templates table
CREATE TABLE public.message_templates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  channel message_channel NOT NULL,
  content TEXT NOT NULL,
  created_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Enable RLS on all tables
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.lead_tags ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.leads ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.leads_tags ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.lead_notes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.lead_activities ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.lead_documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.calendar_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.automations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ai_insights ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.message_templates ENABLE ROW LEVEL SECURITY;

-- Create security definer function to check roles
CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role app_role)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id
      AND role = _role
  )
$$;

-- Create function to check if user is admin or manager
CREATE OR REPLACE FUNCTION public.is_admin_or_manager(_user_id UUID)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id
      AND role IN ('admin', 'manager')
  )
$$;

-- Create function to get user role
CREATE OR REPLACE FUNCTION public.get_user_role(_user_id UUID)
RETURNS app_role
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT role FROM public.user_roles WHERE user_id = _user_id LIMIT 1
$$;

-- RLS Policies for profiles
CREATE POLICY "Users can view all profiles" ON public.profiles
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Users can update own profile" ON public.profiles
  FOR UPDATE TO authenticated USING (auth.uid() = id);

CREATE POLICY "Users can insert own profile" ON public.profiles
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = id);

-- RLS Policies for user_roles
CREATE POLICY "Users can view their own role" ON public.user_roles
  FOR SELECT TO authenticated USING (auth.uid() = user_id);

CREATE POLICY "Admins can view all roles" ON public.user_roles
  FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can manage roles" ON public.user_roles
  FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'admin'));

-- RLS Policies for lead_tags
CREATE POLICY "All authenticated users can view tags" ON public.lead_tags
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Admins and managers can manage tags" ON public.lead_tags
  FOR ALL TO authenticated USING (public.is_admin_or_manager(auth.uid()));

-- RLS Policies for leads
CREATE POLICY "Admins and managers can view all leads" ON public.leads
  FOR SELECT TO authenticated USING (public.is_admin_or_manager(auth.uid()));

CREATE POLICY "Investor guides can view assigned leads" ON public.leads
  FOR SELECT TO authenticated USING (assigned_to = auth.uid());

CREATE POLICY "Admins and managers can manage all leads" ON public.leads
  FOR ALL TO authenticated USING (public.is_admin_or_manager(auth.uid()));

CREATE POLICY "Investor guides can update assigned leads" ON public.leads
  FOR UPDATE TO authenticated USING (assigned_to = auth.uid());

-- RLS Policies for leads_tags
CREATE POLICY "Users can view lead tags" ON public.leads_tags
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Admins and managers can manage lead tags" ON public.leads_tags
  FOR ALL TO authenticated USING (public.is_admin_or_manager(auth.uid()));

-- RLS Policies for lead_notes
CREATE POLICY "Users can view notes on accessible leads" ON public.lead_notes
  FOR SELECT TO authenticated USING (
    EXISTS (
      SELECT 1 FROM public.leads 
      WHERE leads.id = lead_notes.lead_id 
      AND (public.is_admin_or_manager(auth.uid()) OR leads.assigned_to = auth.uid())
    )
  );

CREATE POLICY "Users can create notes on accessible leads" ON public.lead_notes
  FOR INSERT TO authenticated WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.leads 
      WHERE leads.id = lead_notes.lead_id 
      AND (public.is_admin_or_manager(auth.uid()) OR leads.assigned_to = auth.uid())
    )
  );

-- RLS Policies for lead_activities
CREATE POLICY "Users can view activities on accessible leads" ON public.lead_activities
  FOR SELECT TO authenticated USING (
    EXISTS (
      SELECT 1 FROM public.leads 
      WHERE leads.id = lead_activities.lead_id 
      AND (public.is_admin_or_manager(auth.uid()) OR leads.assigned_to = auth.uid())
    )
  );

CREATE POLICY "Users can create activities" ON public.lead_activities
  FOR INSERT TO authenticated WITH CHECK (true);

-- RLS Policies for lead_documents
CREATE POLICY "Users can view documents on accessible leads" ON public.lead_documents
  FOR SELECT TO authenticated USING (
    EXISTS (
      SELECT 1 FROM public.leads 
      WHERE leads.id = lead_documents.lead_id 
      AND (public.is_admin_or_manager(auth.uid()) OR leads.assigned_to = auth.uid())
    )
  );

CREATE POLICY "Users can upload documents" ON public.lead_documents
  FOR INSERT TO authenticated WITH CHECK (true);

-- RLS Policies for conversations
CREATE POLICY "Users can view conversations on accessible leads" ON public.conversations
  FOR SELECT TO authenticated USING (
    EXISTS (
      SELECT 1 FROM public.leads 
      WHERE leads.id = conversations.lead_id 
      AND (public.is_admin_or_manager(auth.uid()) OR leads.assigned_to = auth.uid())
    )
  );

CREATE POLICY "Users can manage conversations" ON public.conversations
  FOR ALL TO authenticated USING (true);

-- RLS Policies for messages
CREATE POLICY "Users can view messages in accessible conversations" ON public.messages
  FOR SELECT TO authenticated USING (
    EXISTS (
      SELECT 1 FROM public.conversations 
      JOIN public.leads ON leads.id = conversations.lead_id
      WHERE conversations.id = messages.conversation_id 
      AND (public.is_admin_or_manager(auth.uid()) OR leads.assigned_to = auth.uid())
    )
  );

CREATE POLICY "Users can send messages" ON public.messages
  FOR INSERT TO authenticated WITH CHECK (true);

-- RLS Policies for tasks
CREATE POLICY "Admins and managers can view all tasks" ON public.tasks
  FOR SELECT TO authenticated USING (public.is_admin_or_manager(auth.uid()));

CREATE POLICY "Users can view assigned tasks" ON public.tasks
  FOR SELECT TO authenticated USING (assigned_to = auth.uid());

CREATE POLICY "Admins and managers can manage all tasks" ON public.tasks
  FOR ALL TO authenticated USING (public.is_admin_or_manager(auth.uid()));

CREATE POLICY "Users can update assigned tasks" ON public.tasks
  FOR UPDATE TO authenticated USING (assigned_to = auth.uid());

-- RLS Policies for calendar_events
CREATE POLICY "Users can view own events" ON public.calendar_events
  FOR SELECT TO authenticated USING (user_id = auth.uid());

CREATE POLICY "Admins and managers can view all events" ON public.calendar_events
  FOR SELECT TO authenticated USING (public.is_admin_or_manager(auth.uid()));

CREATE POLICY "Users can manage own events" ON public.calendar_events
  FOR ALL TO authenticated USING (user_id = auth.uid());

-- RLS Policies for automations
CREATE POLICY "All authenticated can view automations" ON public.automations
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Admins can manage automations" ON public.automations
  FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'admin'));

-- RLS Policies for ai_insights
CREATE POLICY "Users can view insights on accessible leads" ON public.ai_insights
  FOR SELECT TO authenticated USING (
    lead_id IS NULL OR EXISTS (
      SELECT 1 FROM public.leads 
      WHERE leads.id = ai_insights.lead_id 
      AND (public.is_admin_or_manager(auth.uid()) OR leads.assigned_to = auth.uid())
    )
  );

CREATE POLICY "System can create insights" ON public.ai_insights
  FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "Users can update insights" ON public.ai_insights
  FOR UPDATE TO authenticated USING (true);

-- RLS Policies for message_templates
CREATE POLICY "All authenticated can view templates" ON public.message_templates
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Admins and managers can manage templates" ON public.message_templates
  FOR ALL TO authenticated USING (public.is_admin_or_manager(auth.uid()));

-- Create trigger for new user profile creation
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name, avatar_url)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data ->> 'full_name', NEW.email),
    NEW.raw_user_meta_data ->> 'avatar_url'
  );
  
  -- Assign default role (investor_guide) to new users
  INSERT INTO public.user_roles (user_id, role)
  VALUES (NEW.id, 'investor_guide');
  
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Create trigger for updating updated_at timestamps
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

CREATE TRIGGER update_profiles_updated_at
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_leads_updated_at
  BEFORE UPDATE ON public.leads
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_conversations_updated_at
  BEFORE UPDATE ON public.conversations
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_tasks_updated_at
  BEFORE UPDATE ON public.tasks
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_calendar_events_updated_at
  BEFORE UPDATE ON public.calendar_events
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_automations_updated_at
  BEFORE UPDATE ON public.automations
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_message_templates_updated_at
  BEFORE UPDATE ON public.message_templates
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Enable realtime for messages
ALTER PUBLICATION supabase_realtime ADD TABLE public.messages;

-- Insert default lead tags
INSERT INTO public.lead_tags (name, color) VALUES
  ('VIP', '#EF4444'),
  ('חם', '#F97316'),
  ('קר', '#3B82F6'),
  ('משקיע חוזר', '#10B981'),
  ('דחוף', '#DC2626'),
  ('בתהליך', '#8B5CF6');

-- Insert default message templates
INSERT INTO public.message_templates (name, channel, content) VALUES
  ('ברוכים הבאים', 'whatsapp', 'שלום {name}! תודה על הפנייה לקרנף נדל״ן. שמי {agent_name} ואשמח לסייע לך. מתי נוח לך לשוחח?'),
  ('תזכורת פגישה', 'whatsapp', 'שלום {name}, רציתי להזכיר לך שיש לנו פגישה מחר ב-{time}. נשמח לראותך!'),
  ('מעקב', 'whatsapp', 'שלום {name}, איך הולך? רציתי לבדוק אם יש לך שאלות נוספות לגבי ההשקעה שדיברנו עליה.'),
  ('שליחת מידע', 'email', 'שלום {name},\n\nתודה על השיחה שלנו היום.\nמצורף מידע נוסף על הפרויקטים שלנו.\n\nבברכה,\n{agent_name}\nקרנף נדל״ן');