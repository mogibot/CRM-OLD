/**
 * WhatsApp Cloud API helper (Meta) — FREE replacement for WATI.
 * Docs: https://developers.facebook.com/docs/whatsapp/cloud-api
 *
 * Required env vars:
 *   WHATSAPP_TOKEN        — permanent access token from Meta
 *   WHATSAPP_PHONE_ID     — phone number ID from Meta dashboard
 *   WHATSAPP_VERIFY_TOKEN — webhook verification token (you choose)
 *
 * Optional (fallback to WATI if set):
 *   WATI_TOKEN — if set, uses WATI API instead of Meta Cloud API
 */

const WHATSAPP_TOKEN = Deno.env.get('WHATSAPP_TOKEN') || '';
const WHATSAPP_PHONE_ID = Deno.env.get('WHATSAPP_PHONE_ID') || '';
const WATI_TOKEN = Deno.env.get('WATI_TOKEN') || '';
const WATI_API_URL = Deno.env.get('WATI_API_URL') || 'https://live-mt-server.wati.io';

/** Are we using Meta Cloud API or WATI? */
export const isCloudAPI = !!WHATSAPP_TOKEN && !!WHATSAPP_PHONE_ID;

/** Normalize Israeli phone to international format (no +): 05X → 9725X */
export function toWhatsAppPhone(phone: string): string {
  let p = phone.replace(/[\s\-\(\)\.\+]/g, '');
  if (p.startsWith('0')) {
    p = '972' + p.slice(1);
  } else if (!p.startsWith('972')) {
    p = '972' + p;
  }
  return p;
}

/** Send a text message via WhatsApp (auto-selects Cloud API or WATI) */
export async function sendMessage(phone: string, text: string): Promise<{ ok: boolean; error?: string }> {
  if (isCloudAPI) {
    return sendCloudMessage(phone, text);
  }
  if (WATI_TOKEN) {
    return sendWatiSessionMessage(phone, text);
  }
  console.warn('[WhatsApp] No provider configured (set WHATSAPP_TOKEN or WATI_TOKEN)');
  return { ok: false, error: 'No WhatsApp provider configured' };
}

/** Send a template message (for welcome / outside 24h window) */
export async function sendTemplate(
  phone: string,
  templateName: string,
  languageCode = 'he',
  params: Array<{ type: string; text: string }> = [],
): Promise<{ ok: boolean; error?: string }> {
  if (isCloudAPI) {
    return sendCloudTemplate(phone, templateName, languageCode, params);
  }
  if (WATI_TOKEN) {
    return sendWatiTemplate(phone, templateName, params.map((p) => ({ name: 'name', value: p.text })));
  }
  return { ok: false, error: 'No WhatsApp provider configured' };
}

// ─── Meta Cloud API ───

async function sendCloudMessage(phone: string, text: string): Promise<{ ok: boolean; error?: string }> {
  const waPhone = toWhatsAppPhone(phone);
  try {
    const res = await fetch(
      `https://graph.facebook.com/v21.0/${WHATSAPP_PHONE_ID}/messages`,
      {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${WHATSAPP_TOKEN}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          messaging_product: 'whatsapp',
          to: waPhone,
          type: 'text',
          text: { body: text },
        }),
      },
    );
    if (!res.ok) {
      const body = await res.text();
      console.error(`[WhatsApp Cloud] send failed (${res.status}):`, body);
      return { ok: false, error: `Cloud API ${res.status}: ${body}` };
    }
    return { ok: true };
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'Unknown';
    console.error('[WhatsApp Cloud] send error:', msg);
    return { ok: false, error: msg };
  }
}

async function sendCloudTemplate(
  phone: string,
  templateName: string,
  languageCode: string,
  params: Array<{ type: string; text: string }>,
): Promise<{ ok: boolean; error?: string }> {
  const waPhone = toWhatsAppPhone(phone);
  try {
    const components = params.length > 0
      ? [{ type: 'body', parameters: params.map((p) => ({ type: 'text', text: p.text })) }]
      : [];

    const res = await fetch(
      `https://graph.facebook.com/v21.0/${WHATSAPP_PHONE_ID}/messages`,
      {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${WHATSAPP_TOKEN}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          messaging_product: 'whatsapp',
          to: waPhone,
          type: 'template',
          template: {
            name: templateName,
            language: { code: languageCode },
            ...(components.length > 0 ? { components } : {}),
          },
        }),
      },
    );
    if (!res.ok) {
      const body = await res.text();
      console.error(`[WhatsApp Cloud] template failed (${res.status}):`, body);
      return { ok: false, error: `Cloud API ${res.status}: ${body}` };
    }
    return { ok: true };
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'Unknown';
    console.error('[WhatsApp Cloud] template error:', msg);
    return { ok: false, error: msg };
  }
}

// ─── WATI Fallback ───

async function sendWatiSessionMessage(phone: string, text: string): Promise<{ ok: boolean; error?: string }> {
  const watiPhone = toWhatsAppPhone(phone);
  try {
    const res = await fetch(
      `${WATI_API_URL}/api/v1/sendSessionMessage/${watiPhone}?messageText=${encodeURIComponent(text)}`,
      {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${WATI_TOKEN}`,
          'Content-Type': 'application/json',
        },
      },
    );
    if (!res.ok) {
      const body = await res.text();
      console.error(`[WATI] sendSessionMessage failed (${res.status}):`, body);
      return { ok: false, error: `WATI ${res.status}: ${body}` };
    }
    return { ok: true };
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'Unknown';
    console.error('[WATI] sendSessionMessage error:', msg);
    return { ok: false, error: msg };
  }
}

async function sendWatiTemplate(
  phone: string,
  templateName: string,
  params: Array<{ name: string; value: string }>,
): Promise<{ ok: boolean; error?: string }> {
  const watiPhone = toWhatsAppPhone(phone);
  try {
    const res = await fetch(
      `${WATI_API_URL}/api/v1/sendTemplateMessage?whatsappNumber=${watiPhone}`,
      {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${WATI_TOKEN}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          template_name: templateName,
          broadcast_name: 'bot_welcome',
          parameters: params,
        }),
      },
    );
    if (!res.ok) {
      const body = await res.text();
      console.error(`[WATI] sendTemplateMessage failed (${res.status}):`, body);
      return { ok: false, error: `WATI ${res.status}: ${body}` };
    }
    return { ok: true };
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'Unknown';
    console.error('[WATI] sendTemplateMessage error:', msg);
    return { ok: false, error: msg };
  }
}
