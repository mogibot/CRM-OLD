/**
 * Instagram DM helper — sends messages via Meta Send API.
 * Uses PAGE_ACCESS_TOKEN (same token used for FB Graph API enrichment).
 *
 * Docs: https://developers.facebook.com/docs/messenger-platform/instagram/features/send-message
 */

const PAGE_TOKEN = Deno.env.get('PAGE_ACCESS_TOKEN') || '';

/**
 * Send a text message to an Instagram user via their PSID/IGSID.
 * recipientId should be the raw PSID (numeric string, no "fb_" prefix).
 */
export async function sendInstagramMessage(
  recipientId: string,
  text: string,
): Promise<{ ok: boolean; error?: string }> {
  if (!PAGE_TOKEN) {
    console.warn('[Instagram] PAGE_ACCESS_TOKEN not set, cannot send message');
    return { ok: false, error: 'PAGE_ACCESS_TOKEN not configured' };
  }

  // Strip "fb_" prefix if present (Make.com adds it)
  const cleanId = recipientId.replace(/^fb_/, '');

  try {
    const res = await fetch(
      `https://graph.facebook.com/v21.0/me/messages?access_token=${PAGE_TOKEN}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          recipient: { id: cleanId },
          message: { text },
        }),
      },
    );

    if (!res.ok) {
      const body = await res.text();
      console.error(`[Instagram] send failed (${res.status}):`, body);
      return { ok: false, error: `Meta API ${res.status}: ${body}` };
    }
    return { ok: true };
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'Unknown';
    console.error('[Instagram] send error:', msg);
    return { ok: false, error: msg };
  }
}

/**
 * Fetch a user's profile name from their PSID via Facebook Graph API.
 * Returns the name or null if unavailable.
 */
export async function fetchProfileName(psid: string): Promise<string | null> {
  if (!PAGE_TOKEN) return null;

  const cleanId = psid.replace(/^fb_/, '');

  try {
    const res = await fetch(
      `https://graph.facebook.com/v21.0/${cleanId}?fields=name,username&access_token=${PAGE_TOKEN}`,
    );
    if (!res.ok) {
      const errBody = await res.text();
      console.warn(`[instagram] fetchProfileName ${cleanId} failed (${res.status}): ${errBody.slice(0, 200)}`);
      return null;
    }

    const data = await res.json();
    return data.name || data.username || null;
  } catch (err) {
    console.warn(`[instagram] fetchProfileName error:`, err);
    return null;
  }
}
