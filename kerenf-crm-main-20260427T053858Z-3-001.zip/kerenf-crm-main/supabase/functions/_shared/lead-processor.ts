import { createClient, SupabaseClient } from 'https://esm.sh/@supabase/supabase-js@2';

// ──────────────────────────────────────────────
// Types
// ──────────────────────────────────────────────

export interface IncomingLeadData {
  full_name?: string | null;
  email?: string | null;
  phone?: string | null;
  city?: string | null;
  notes?: string | null;
  property_interest?: string | null;
  budget_min?: number | null;
  budget_max?: number | null;
  external_id?: string | null;
  source: string;
  raw_payload: Record<string, unknown>;
}

export interface ProcessResult {
  success: boolean;
  action: 'created' | 'updated' | 'error';
  lead_id?: string;
  error?: string;
}

const VALID_SOURCES = [
  'instagram', 'facebook', 'whatsapp',
  'smoov', 'wix_site', 'email_list', 'referral',
  'campaign', 'manual',
];

// Normalize common source aliases to canonical values
const SOURCE_ALIASES: Record<string, string> = {
  facebook_messenger: 'facebook',
  fb_messenger: 'facebook',
  fb: 'facebook',
  instagram_dm: 'instagram',
  ig: 'instagram',
  wa: 'whatsapp',
  website_form: 'wix_site',
};

// Hebrew activity descriptions per source
const SOURCE_LABELS: Record<string, string> = {
  whatsapp: 'WhatsApp',
  facebook: 'Facebook',
  facebook_messenger: 'Facebook Messenger',
  instagram: 'Instagram',
  instagram_dm: 'Instagram',
  manychat: 'ManyChat',
  smoov: 'Smoov',
  wix_site: 'טופס אתר',
  website_form: 'טופס אתר',
  email_parsed: 'אימייל',
  generic: 'API חיצוני',
  campaign: 'קמפיין',
  referral: 'הפניה',
  email_list: 'רשימת דיוור',
  manual: 'ידני',
};

// ──────────────────────────────────────────────
// CORS Headers
// ──────────────────────────────────────────────

export const corsHeaders: Record<string, string> = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-api-key',
};

// ──────────────────────────────────────────────
// Helpers
// ──────────────────────────────────────────────

export function getSupabaseClient(): SupabaseClient {
  const url = Deno.env.get('SUPABASE_URL')!;
  const key = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
  return createClient(url, key);
}

/**
 * Normalize a phone number to a consistent format for deduplication.
 * Strips spaces, dashes, parentheses, and the leading +972 country code.
 * Ensures the result starts with "0" for Israeli numbers.
 */
export function normalizePhone(raw: string | null | undefined): string | null {
  if (!raw) return null;

  // Strip everything except digits and leading +
  let phone = raw.replace(/[\s\-\(\)\.]/g, '');

  // Handle Israeli country code +972, 00972, or 972
  if (phone.startsWith('+972')) {
    phone = '0' + phone.slice(4);
  } else if (phone.startsWith('00972')) {
    phone = '0' + phone.slice(5);
  } else if (phone.startsWith('972') && phone.length > 9) {
    phone = '0' + phone.slice(3);
  }

  // Strip leading + if any remains
  phone = phone.replace(/^\+/, '');

  // If it doesn't start with 0 and is 9 digits (Israeli mobile without leading 0)
  if (!phone.startsWith('0') && phone.length === 9) {
    phone = '0' + phone;
  }

  return phone.length >= 9 ? phone : null;
}

/**
 * Validate the incoming API key against the configured WEBHOOK_API_KEY env var.
 * Returns true if no key is configured (backwards-compatible) or if the key matches.
 */
export function validateApiKey(req: Request): boolean {
  const configuredKey = Deno.env.get('WEBHOOK_API_KEY');
  if (!configuredKey) return true; // No key configured = allow all (backwards-compatible)

  const providedKey = req.headers.get('x-api-key') ||
    new URL(req.url).searchParams.get('api_key');

  return providedKey === configuredKey;
}

/**
 * Validate that the source string is a valid lead_source enum value.
 * Falls back to the provided default.
 */
export function validateSource(source: string, fallback: string): string {
  const normalized = SOURCE_ALIASES[source] || source;
  return VALID_SOURCES.includes(normalized) ? normalized : fallback;
}

/**
 * Build a JSON error response.
 */
export function errorResponse(message: string, status = 400): Response {
  return new Response(
    JSON.stringify({ error: message }),
    { status, headers: { ...corsHeaders, 'Content-Type': 'application/json' } },
  );
}

/**
 * Build a JSON success response.
 */
export function successResponse(data: Record<string, unknown>, status = 200): Response {
  return new Response(
    JSON.stringify(data),
    { status, headers: { ...corsHeaders, 'Content-Type': 'application/json' } },
  );
}

// ──────────────────────────────────────────────
// Core: processIncomingLead
// ──────────────────────────────────────────────

/**
 * Central lead-processing pipeline:
 * 1. Normalize phone
 * 2. Deduplicate by phone → email → external_id
 * 3. Create or update the lead
 * 4. Log activity
 * 5. Log to integration_logs
 */
export async function processIncomingLead(
  supabase: SupabaseClient,
  data: IncomingLeadData,
  logSource: string,
): Promise<ProcessResult> {
  const normalizedPhone = normalizePhone(data.phone);
  const validSource = validateSource(data.source, 'manual');

  try {
    // ── Deduplication ──
    let existingLead: { id: string } | null = null;

    if (normalizedPhone) {
      const { data: found } = await supabase
        .from('leads')
        .select('id')
        .eq('phone', normalizedPhone)
        .maybeSingle();
      existingLead = found;
    }

    if (!existingLead && data.email) {
      const { data: found } = await supabase
        .from('leads')
        .select('id')
        .eq('email', data.email.toLowerCase().trim())
        .maybeSingle();
      existingLead = found;
    }

    if (!existingLead && data.external_id) {
      const { data: found } = await supabase
        .from('leads')
        .select('id')
        .eq('external_id', data.external_id)
        .eq('external_source', logSource)
        .order('created_at', { ascending: true })
        .limit(1)
        .maybeSingle();
      existingLead = found;
    }

    let leadId: string;
    let action: 'created' | 'updated';

    if (existingLead) {
      // ── Update existing lead ──
      const updates: Record<string, unknown> = {
        last_contact_at: new Date().toISOString(),
        raw_data: data.raw_payload,
        updated_at: new Date().toISOString(),
      };
      if (data.full_name) updates.full_name = data.full_name;
      if (data.email) updates.email = data.email.toLowerCase().trim();
      if (normalizedPhone) updates.phone = normalizedPhone;
      if (data.city) updates.city = data.city;
      if (data.notes) updates.notes = data.notes;
      if (data.property_interest) updates.property_interest = data.property_interest;
      if (data.budget_min != null) updates.budget_min = data.budget_min;
      if (data.budget_max != null) updates.budget_max = data.budget_max;

      const { error } = await supabase.from('leads').update(updates).eq('id', existingLead.id);
      if (error) throw error;

      leadId = existingLead.id;
      action = 'updated';
    } else {
      // ── Create new lead ──
      const label = SOURCE_LABELS[logSource] || logSource;
      const insertData: Record<string, unknown> = {
        full_name: data.full_name || `ליד מ-${label}`,
        email: data.email?.toLowerCase().trim() || null,
        phone: normalizedPhone,
        city: data.city || null,
        notes: data.notes || null,
        property_interest: data.property_interest || null,
        budget_min: data.budget_min ?? null,
        budget_max: data.budget_max ?? null,
        source: validSource,
        stage: 'new_lead',
        external_id: data.external_id || null,
        external_source: logSource,
        raw_data: data.raw_payload,
      };

      const { data: newLead, error } = await supabase
        .from('leads')
        .insert(insertData)
        .select('id')
        .single();

      if (error) throw error;

      leadId = newLead.id;
      action = 'created';

      // Activity log for new leads
      await supabase.from('lead_activities').insert({
        lead_id: leadId,
        activity_type: 'note_added',
        description: `ליד נוצר אוטומטית מ-${label}`,
      });
    }

    // ── Integration log ──
    await supabase.from('integration_logs').insert({
      source: logSource,
      status: 'success',
      request_data: data.raw_payload,
      response_data: { action, lead_id: leadId },
      lead_id: leadId,
    });

    return { success: true, action, lead_id: leadId };
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    console.error(`[${logSource}] Lead processing error:`, message);

    // Log error
    try {
      await supabase.from('integration_logs').insert({
        source: logSource,
        status: 'error',
        request_data: data.raw_payload,
        error_message: message,
      });
    } catch { /* Don't fail on log write */ }

    return { success: false, action: 'error', error: message };
  }
}
