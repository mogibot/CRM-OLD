/**
 * WATI WhatsApp API helper for Supabase Edge Functions.
 * Docs: https://docs.wati.io/reference
 */

const WATI_API_URL = Deno.env.get('WATI_API_URL') || 'https://live-mt-server.wati.io';
const WATI_TOKEN = Deno.env.get('WATI_TOKEN') || '';

/** Normalize Israeli phone: 05X → 9725X (WATI expects international without +) */
export function toWatiPhone(phone: string): string {
  let p = phone.replace(/[\s\-\(\)\.\+]/g, '');
  if (p.startsWith('0')) {
    p = '972' + p.slice(1);
  } else if (!p.startsWith('972')) {
    p = '972' + p;
  }
  return p;
}

/** Send a session message (within 24h window) */
export async function sendSessionMessage(phone: string, text: string): Promise<{ ok: boolean; error?: string }> {
  const watiPhone = toWatiPhone(phone);
  try {
    const res = await fetch(
      `${WATI_API_URL}/api/v1/sendSessionMessage/${watiPhone}?messageText=${encodeURIComponent(text)}`,
      {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${WATI_TOKEN}`,
          'Content-Type': 'application/json',
        },
      },
    );
    if (!res.ok) {
      const body = await res.text();
      console.error(`[WATI] sendSessionMessage failed (${res.status}):`, body);
      return { ok: false, error: `WATI ${res.status}: ${body}` };
    }
    return { ok: true };
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'Unknown';
    console.error('[WATI] sendSessionMessage error:', msg);
    return { ok: false, error: msg };
  }
}

/** Send a template message (outside 24h window) */
export async function sendTemplateMessage(
  phone: string,
  templateName: string,
  params: Array<{ name: string; value: string }> = [],
): Promise<{ ok: boolean; error?: string }> {
  const watiPhone = toWatiPhone(phone);
  try {
    const res = await fetch(
      `${WATI_API_URL}/api/v1/sendTemplateMessage?whatsappNumber=${watiPhone}`,
      {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${WATI_TOKEN}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          template_name: templateName,
          broadcast_name: 'bot_welcome',
          parameters: params,
        }),
      },
    );
    if (!res.ok) {
      const body = await res.text();
      console.error(`[WATI] sendTemplateMessage failed (${res.status}):`, body);
      return { ok: false, error: `WATI ${res.status}: ${body}` };
    }
    return { ok: true };
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'Unknown';
    console.error('[WATI] sendTemplateMessage error:', msg);
    return { ok: false, error: msg };
  }
}
