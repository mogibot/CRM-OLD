import {
  corsHeaders,
  errorResponse,
  successResponse,
  getSupabaseClient,
  validateApiKey,
  processIncomingLead,
} from '../_shared/lead-processor.ts';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  if (req.method !== 'POST') {
    return errorResponse('Method not allowed', 405);
  }

  if (!validateApiKey(req)) {
    return errorResponse('Unauthorized', 401);
  }

  try {
    const body = await req.json();
    console.log('Smoov webhook received:', JSON.stringify(body));

    const supabase = getSupabaseClient();

    const fullName = body.name || body.full_name ||
      (body.firstName ? `${body.firstName} ${body.lastName || ''}`.trim() : null);
    const email = body.email || body.Email || null;
    const phone = body.phone || body.Phone || body.mobile || null;
    const city = body.city || body.City || null;
    const propertyInterest = body.property || body.propertyName || body.property_interest || null;
    const notes = body.message || body.notes || body.comments || null;
    const externalId = body.id || body.leadId || body.lead_id || null;

    if (!fullName && !phone && !email) {
      return errorResponse('Missing required fields: name, phone, or email');
    }

    const result = await processIncomingLead(supabase, {
      full_name: fullName,
      email,
      phone,
      city,
      notes,
      property_interest: propertyInterest,
      external_id: externalId,
      source: 'smoov',
      raw_payload: body,
    }, 'smoov');

    if (!result.success) {
      return errorResponse(result.error || 'Failed to process lead', 500);
    }

    return successResponse({
      success: true,
      action: result.action,
      lead_id: result.lead_id,
    });
  } catch (error) {
    console.error('Smoov webhook error:', error);
    return errorResponse('Internal server error', 500);
  }
});
