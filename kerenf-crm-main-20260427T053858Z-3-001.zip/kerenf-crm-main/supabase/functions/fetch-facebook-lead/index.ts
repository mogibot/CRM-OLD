import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface FacebookLeadField {
  name: string;
  values: string[];
}

interface FacebookLeadData {
  id: string;
  created_time: string;
  field_data: FacebookLeadField[];
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  if (req.method !== 'POST') {
    return new Response('Method not allowed', { status: 405, headers: corsHeaders });
  }

  try {
    const { leadgen_id, page_access_token } = await req.json();

    if (!leadgen_id) {
      return new Response(
        JSON.stringify({ error: 'leadgen_id is required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Get access token from request or environment
    const accessToken = page_access_token || Deno.env.get('FACEBOOK_PAGE_ACCESS_TOKEN');

    if (!accessToken) {
      console.log('No Facebook Page Access Token available, returning partial data');
      return new Response(
        JSON.stringify({ 
          success: false, 
          message: 'No access token configured',
          leadgen_id 
        }),
        { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Fetch lead data from Facebook Graph API
    const graphUrl = `https://graph.facebook.com/v18.0/${leadgen_id}?access_token=${accessToken}`;
    
    console.log('Fetching lead from Facebook Graph API:', leadgen_id);
    
    const response = await fetch(graphUrl);
    const data = await response.json();

    if (data.error) {
      console.error('Facebook API error:', data.error);
      return new Response(
        JSON.stringify({ 
          success: false, 
          error: data.error.message,
          leadgen_id 
        }),
        { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('Facebook lead data received:', JSON.stringify(data, null, 2));

    // Parse field data
    const leadData: Record<string, string> = {};
    
    if (data.field_data) {
      for (const field of data.field_data) {
        const fieldName = field.name.toLowerCase();
        const fieldValue = field.values?.[0] || '';
        
        // Map common Facebook field names to our schema
        switch (fieldName) {
          case 'full_name':
          case 'name':
            leadData.full_name = fieldValue;
            break;
          case 'email':
            leadData.email = fieldValue;
            break;
          case 'phone_number':
          case 'phone':
            leadData.phone = fieldValue;
            break;
          case 'city':
            leadData.city = fieldValue;
            break;
          default:
            // Store other fields in notes
            if (!leadData.notes) leadData.notes = '';
            leadData.notes += `${field.name}: ${fieldValue}\n`;
        }
      }
    }

    // Initialize Supabase client
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Update existing lead with full data
    const { data: existingLead } = await supabase
      .from('leads')
      .select('id')
      .eq('external_id', leadgen_id)
      .maybeSingle();

    if (existingLead) {
      const { error: updateError } = await supabase
        .from('leads')
        .update({
          full_name: leadData.full_name || undefined,
          email: leadData.email || undefined,
          phone: leadData.phone || undefined,
          city: leadData.city || undefined,
          notes: leadData.notes || undefined,
          raw_data: data,
          updated_at: new Date().toISOString(),
        })
        .eq('id', existingLead.id);

      if (updateError) {
        console.error('Error updating lead:', updateError);
      } else {
        console.log('Lead updated successfully:', existingLead.id);
        
        // Log activity
        await supabase.from('lead_activities').insert({
          lead_id: existingLead.id,
          activity_type: 'note_added',
          description: 'פרטי ליד עודכנו מ-Facebook Graph API'
        });
      }
    }

    // Log the fetch operation
    await supabase.from('integration_logs').insert({
      source: 'facebook_graph_api',
      status: 'success',
      request_data: { leadgen_id },
      response_data: leadData,
      lead_id: existingLead?.id
    });

    return new Response(
      JSON.stringify({ 
        success: true, 
        leadgen_id,
        lead_data: leadData,
        lead_id: existingLead?.id
      }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error fetching Facebook lead:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return new Response(
      JSON.stringify({ error: 'Internal server error', details: errorMessage }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
