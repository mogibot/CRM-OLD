/**
 * Bot Handler — the core AI conversation engine.
 * 1. Find/create lead + bot_session by phone
 * 2. Load last 10 messages for context
 * 3. Load system prompt from bot_config
 * 4. Call Gemini Flash (free tier)
 * 5. Parse JSON response, update lead fields
 * 6. Save message to messages table
 * 7. If should_transfer → insert into work_queue
 * 8. Send reply via WhatsApp
 */
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { corsHeaders, normalizePhone } from '../_shared/lead-processor.ts';
import { sendMessage, toWhatsAppPhone } from '../_shared/whatsapp.ts';

const GEMINI_API_KEY = Deno.env.get('GEMINI_API_KEY') || '';

interface BotResponse {
  reply: string;
  score_delta: number;
  product_guess: string;
  should_transfer: boolean;
  transfer_reason: string;
  summary: string;
  sentiment: string;
  stagnant: boolean;
  lead_type: string;
  intent_strength: string;
  key_info: Record<string, string>;
}

const BUSINESS_PHONE = '972559966175';
const MAX_MESSAGES = 12;
const WRAP_UP_AT = 8;

const DEFAULT_PROMPT = `# מי את
קרן, מקרנף נדל"ן. את מוכרנית מטורפת שיודעת למכור בוואטסאפ. את כותבת כמו חברה — קצר, חד, ישראלי. את לא נציגת שירות. את יועצת נדל"ן שיודעת בדיוק מה הלקוח צריך.

# הכלל העליון:
תשובה = משפט אחד עד שניים מקסימום. כמו הודעת וואטסאפ רגילה.

# אסטרטגיית שיחה — ככה את מנהלת:

## שלב פתיחה (הודעות 1-2):
גלי מי הלקוח. שאלה אחת פתוחה.
לקוח: "היי" → את: "היי! מה מחפש/ת בנדל״ן? 😊"
לקוח: "שלום, ראיתי את הפרסום" → את: "אהלן! איזה פרסום תפס אותך?"

## שלב בירור (הודעות 3-4):
שאלות ממוקדות. הראי שאת מבינה. תני ערך קצר.
לקוח: "מחפש דירה להשקעה" → את: "אחלה, באיזה אזור חשבת?"
לקוח: "באר שבע" → את: "באר שבע מעולה להשקעה עכשיו. על כמה בערך?"

## שלב הצעה (הודעות 5-6):
הצעי מוצר רלוונטי — בטבעיות, לא כ-pitch.
"יש לנו קבוצת משקיעים שעובדים בדיוק ככה, עם תוצאות מטורפות. רוצה לשמוע?"
"הרבה אנשים במצב שלך התחילו מהקורס שלנו ותוך חודשיים סגרו דירה"

## שלב סגירה (הודעות 7-8):
CTA ברור וטבעי.
"רוצה שקרן תתקשר אלייך לשיחה קצרה? בלי לחץ, פשוט לראות אם מתאים"
"שולחת לך קישור לוובינר הקרוב? זה חינמי ושווה"

# טכניקות שאת משתמשת בהן (בטבעיות, לא בכוח):
- Social proof: "היה לנו השבוע זוג שסגר דירה ראשונה דרך הקורס", "יש לנו קבוצה של משקיעים שעובדים ככה"
- Urgency קל: "הקורס הבא מתחיל בקרוב", "נשארו מקומות אחרונים לוובינר"
- מומחיות: "מהניסיון שלי, באזור הזה כדאי לבדוק..." , "הרבה שואלים את זה — בגדול..."
- הקשבה: חזרה על מה שהלקוח אמר ("אז אתה מחפש משהו ב-800K בבאר שבע, נכון?")

# סגנון:
- עברית יומיומית: "סבבה", "וואלה", "אחלה", "יאללה", "בגדול"
- שאלה אחת בלבד בכל הודעה
- שם פרטי — פעם-פעמיים בשיחה, לא בכל הודעה
- אמוג'י — מקסימום 1 בהודעה, ולא בכל הודעה

# זיהוי סוג לקוח (lead_type):
- "first_buyer": מחפש דירה ראשונה, אין ניסיון → דחיפה ל"הדרך לדירה"
- "investor": יש ניסיון, מחפש השקעה/דירה שנייה/תשואה → ליווי משקיעים
- "curious": סתם בודק, לא ברור מה רוצה → הזמנה לוובינר חינמי
- "irrelevant": ספאם, טעות, לא קשור לנדל"ן כלל

# עוצמת כוונה (intent_strength):
- "strong": רוצה לקנות/להשקיע, יש תקציב, יש timeline
- "medium": מתעניין, שואל שאלות רלוונטיות, אין דחיפות
- "weak": סתם בודק, לא בטוח
- "none": לא מעוניין, ביי, ספאם

# מוצרים:
- "הדרך לדירה" — קורס דיגיטלי, 4-5K ש״ח, לרוכש דירה ראשונה
- ליווי משקיעים — 30K ל-6 חודשים, ליווי אישי. תמיד דורש שיחה קודם
- וובינרים — חינם, מצוין לחימום

# העברה לנציגה (should_transfer = true):
ברירת מחדל: false. העבירי רק כש:
- ביקש מפורשות לדבר עם מישהו
- שאלת מימון/משכנתא/מס ספציפית
- כעס/תלונה ממשית
- רוצה ליווי משקיעים (30K) — תמיד דורש שיחה
- שיחה תקועה — אותה שאלה 3+ פעמים
"לא מעוניין" = "סבבה, בהצלחה!" בלי העברה.

# key_info — חלץ מהשיחה:
"budget": תקציב (אם הוזכר), "area": אזור, "timeline": לו"ז, "experience": ניסיון בנדל"ן, "name": שם פרטי

# ביטויים אסורים:
"ברוך הבא", "איך אוכל לעזור", "אשמח לעזור", "אני כאן בשבילך", "הנכס המושלם", "פתרון מושלם", "ללא התחייבות", "הזדמנות", "פנה אלינו", "בכל שאלה"

# מה לא:
- הודעות מעל 2 משפטים
- מחירי נכסים ספציפיים
- הבטחות תשואה
- 2 שאלות בהודעה
- לחשוף שאת AI`;

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  const supabase = createClient(
    Deno.env.get('SUPABASE_URL')!,
    Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
  );

  try {
    const { phone, text, senderName, messageType } = await req.json();
    if (!phone) {
      return jsonResponse({ error: 'Missing phone' }, 400);
    }

    // Handle non-text messages (voice, image, video, etc.)
    if (messageType && messageType !== 'text' && !text) {
      const normalizedPhone = normalizePhone(phone) || phone;
      await sendMessage(normalizedPhone, 'היי! לא הצלחתי לפתוח את זה 😅 תכתוב/י לי בטקסט ואחזור אלייך');
      return jsonResponse({ ok: true, skipped: true, reason: 'Non-text message' });
    }

    if (!text) {
      return jsonResponse({ error: 'Missing text' }, 400);
    }

    const normalizedPhone = normalizePhone(phone) || phone;

    // ── 1. Find or create lead ──
    let { data: lead } = await supabase
      .from('leads')
      .select('id, full_name, bot_score, bot_stage, product_interest')
      .eq('phone', normalizedPhone)
      .maybeSingle();

    if (!lead) {
      const { data: newLead, error } = await supabase
        .from('leads')
        .insert({
          phone: normalizedPhone,
          full_name: senderName || `ליד מ-WhatsApp`,
          source: 'whatsapp',
          stage: 'new_lead',
          bot_score: 0,
          bot_stage: 'new',
        })
        .select('id, full_name, bot_score, bot_stage, product_interest')
        .single();
      if (error) throw error;
      lead = newLead;

      await supabase.from('lead_activities').insert({
        lead_id: lead.id,
        activity_type: 'note_added',
        description: 'ליד נוצר אוטומטית מ-WhatsApp Bot',
      });
    }

    // ── 2. Find or create bot_session ──
    let { data: session } = await supabase
      .from('bot_sessions')
      .select('id, state, last_activity')
      .eq('lead_id', lead.id)
      .order('last_activity', { ascending: false })
      .limit(1)
      .maybeSingle();

    if (!session) {
      const { data: newSession, error } = await supabase
        .from('bot_sessions')
        .insert({
          lead_id: lead.id,
          wati_phone: toWhatsAppPhone(normalizedPhone),
          state: { message_count: 0 },
        })
        .select('id, state, last_activity')
        .single();
      if (error) throw error;
      session = newSession;
    }

    // ── 3. Save incoming message ──
    let { data: convo } = await supabase
      .from('conversations')
      .select('id')
      .eq('lead_id', lead.id)
      .eq('channel', 'whatsapp')
      .maybeSingle();

    if (!convo) {
      const { data: newConvo, error } = await supabase
        .from('conversations')
        .insert({ lead_id: lead.id, channel: 'whatsapp' })
        .select('id')
        .single();
      if (error) throw error;
      convo = newConvo;
    }

    await supabase.from('messages').insert({
      conversation_id: convo.id,
      sender_type: 'lead',
      content: text,
    });

    // ── 4. Load last 10 messages for context ──
    const { data: recentMessages } = await supabase
      .from('messages')
      .select('sender_type, content, created_at')
      .eq('conversation_id', convo.id)
      .order('created_at', { ascending: false })
      .limit(10);

    const history = (recentMessages || []).reverse().map((m) => ({
      role: m.sender_type === 'lead' ? 'user' : 'model',
      parts: [{ text: m.content }],
    }));

    // ── 5. Load all bot_config in one query ──
    const { data: configRows } = await supabase
      .from('bot_config')
      .select('key, value')
      .in('key', ['system_prompt', 'transfer_threshold', 'active_hours']);

    const configMap = new Map((configRows || []).map((r) => [r.key, r.value]));
    const systemPrompt = DEFAULT_PROMPT;
    const activeHours = (configMap.get('active_hours') as { start?: string; end?: string }) || { start: '00:00', end: '23:59' };
    const now = new Date();
    const israelHour = new Date(now.toLocaleString('en-US', { timeZone: 'Asia/Jerusalem' }));
    const currentTime = `${String(israelHour.getHours()).padStart(2, '0')}:${String(israelHour.getMinutes()).padStart(2, '0')}`;

    console.log(`[bot-handler] v5 active_hours=${JSON.stringify(activeHours)} currentTime=${currentTime} prompt_starts=${systemPrompt.slice(0, 30)}`);
    if (currentTime < activeHours.start || currentTime > activeHours.end) {
      console.log(`[bot-handler] Outside active hours (${currentTime}), skipping`);
      return jsonResponse({ ok: true, skipped: true, reason: 'Outside active hours' });
    }

    // ── 6. Call Gemini Flash (free tier) ──
    if (!GEMINI_API_KEY) {
      console.error('[bot-handler] GEMINI_API_KEY not set');
      return jsonResponse({ error: 'Bot not configured' }, 500);
    }

    // ── Context injection: tell the bot where we are in the conversation ──
    const sessionState = (session.state || {}) as {
      message_count?: number;
      lead_type?: string;
      products_mentioned?: string[];
      products_rejected?: string[];
      key_info?: Record<string, string>;
      last_summary?: string;
    };
    const messageCount = (sessionState.message_count || 0) + 1;

    // Determine conversation stage
    let conversationStage = 'opening';
    if (messageCount <= 2) conversationStage = 'opening';
    else if (messageCount <= 4) conversationStage = 'discovery';
    else if (messageCount <= 6) conversationStage = 'offer';
    else conversationStage = 'closing';

    const stageInstructions: Record<string, string> = {
      opening: 'שלב פתיחה — תעני קצר ותשאלי שאלה אחת פתוחה לבירור. מי הלקוח? מה מחפש?',
      discovery: 'שלב בירור — שאלות ממוקדות, הראי מומחיות, בני אמון. תני ערך קצר.',
      offer: 'שלב הצעה — הצעי מוצר ספציפי אם זיהית צורך. בטבעיות, לא כ-pitch.',
      closing: 'שלב סגירה — תני CTA ברור: "רוצה שאתקשר?" / "שולחת קישור?" / "נרשמת לוובינר?"',
    };

    let dynamicContext = `\n\n[הקשר נוכחי]
שם: ${lead.full_name || 'לא ידוע'}
הודעה מספר: ${messageCount}
ציון: ${lead.bot_score || 0}
שלב שיחה: ${conversationStage}
📋 הנחיה: ${stageInstructions[conversationStage]}`;

    // Add memory from previous messages
    if (sessionState.lead_type) {
      dynamicContext += `\nסוג ליד שזוהה: ${sessionState.lead_type}`;
    }
    if (sessionState.key_info && Object.keys(sessionState.key_info).length > 0) {
      const info = Object.entries(sessionState.key_info).map(([k, v]) => `${k}: ${v}`).join(', ');
      dynamicContext += `\nמידע שנאסף: ${info}`;
    }
    if (sessionState.products_mentioned?.length) {
      dynamicContext += `\nמוצרים שהוזכרו: ${sessionState.products_mentioned.join(', ')}`;
    }
    if (sessionState.products_rejected?.length) {
      dynamicContext += `\nמוצרים שנדחו (אל תציעי שוב!): ${sessionState.products_rejected.join(', ')}`;
    }
    if (sessionState.last_summary) {
      dynamicContext += `\nסיכום עד כה: ${sessionState.last_summary}`;
    }

    // Detect returning conversation (gap > 48 hours)
    const lastActivity = session.last_activity ? new Date(session.last_activity as string) : null;
    if (lastActivity && messageCount > 1) {
      const hoursSinceLastMsg = (now.getTime() - lastActivity.getTime()) / (1000 * 60 * 60);
      if (hoursSinceLastMsg > 48) {
        dynamicContext += `\n\n🔄 הלקוח חזר אחרי ${Math.round(hoursSinceLastMsg / 24)} ימים! פתחי בחום: "היי [שם], מה קורה? נשמח לשמוע ממך!" והמשיכי מאיפה שעצרתם.`;
      }
    }

    // Guard: approaching message cap
    if (messageCount >= WRAP_UP_AT && messageCount < MAX_MESSAGES) {
      dynamicContext += `\n\n⚠️ השיחה ארוכה (${messageCount} הודעות). סכמי והציעי שלב הבא — שיחה/קישור.`;
    }

    // Guard: message cap reached — force transfer
    if (messageCount >= MAX_MESSAGES) {
      dynamicContext += `\n\n🛑 הודעה אחרונה! תשובה מסכמת קצרה + should_transfer=true.`;
    }

    const fullPrompt = systemPrompt + dynamicContext;

    const geminiRes = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${GEMINI_API_KEY}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          system_instruction: { parts: [{ text: fullPrompt }] },
          contents: history,
          generationConfig: {
            maxOutputTokens: 1500,
            responseMimeType: 'application/json',
            responseSchema: {
              type: 'OBJECT',
              properties: {
                reply: { type: 'STRING' },
                score_delta: { type: 'INTEGER' },
                product_guess: { type: 'STRING' },
                should_transfer: { type: 'BOOLEAN' },
                transfer_reason: { type: 'STRING' },
                summary: { type: 'STRING' },
                sentiment: { type: 'STRING', enum: ['positive', 'neutral', 'negative'] },
                stagnant: { type: 'BOOLEAN' },
                lead_type: { type: 'STRING', enum: ['first_buyer', 'investor', 'curious', 'irrelevant'] },
                intent_strength: { type: 'STRING', enum: ['strong', 'medium', 'weak', 'none'] },
                key_info: {
                  type: 'OBJECT',
                  properties: {
                    budget: { type: 'STRING' },
                    area: { type: 'STRING' },
                    timeline: { type: 'STRING' },
                    experience: { type: 'STRING' },
                    name: { type: 'STRING' },
                  },
                },
              },
              required: ['reply', 'score_delta', 'product_guess', 'should_transfer', 'transfer_reason', 'summary', 'sentiment', 'stagnant', 'lead_type', 'intent_strength'],
            },
          },
        }),
      },
    );

    if (!geminiRes.ok) {
      const errBody = await geminiRes.text();
      console.error(`[bot-handler] Gemini API error (${geminiRes.status}):`, errBody);
      return jsonResponse({ error: 'AI service error' }, 502);
    }

    const geminiData = await geminiRes.json();
    const rawContent = geminiData.candidates?.[0]?.content?.parts?.[0]?.text || '';

    if (!rawContent) {
      console.error('[bot-handler] Empty Gemini response. Full response:', JSON.stringify(geminiData).slice(0, 500));
    }

    // ── 7. Parse JSON response (with multi-layer protection) ──
    const FALLBACK_REPLY = 'היי, משהו השתבש אצלי רגע. תכתוב/י שוב ואחזור אליך 🙏';
    let botResponse: BotResponse;
    try {
      const jsonMatch = rawContent.match(/\{[\s\S]*\}/);
      botResponse = JSON.parse(jsonMatch?.[0] || rawContent);
    } catch {
      console.warn('[bot-handler] JSON parse failed. Raw:', rawContent.slice(0, 300));
      // Layer 2: Try to extract reply from broken/truncated JSON
      const replyExtract = rawContent.match(/"reply"\s*:\s*"([^"]+)/);
      botResponse = {
        reply: replyExtract ? replyExtract[1] : FALLBACK_REPLY,
        score_delta: 5,
        product_guess: 'unknown',
        should_transfer: false,
        transfer_reason: '',
        summary: '',
        sentiment: 'neutral',
        stagnant: false,
        lead_type: 'curious',
        intent_strength: 'weak',
        key_info: {},
      };
    }

    // Layer 3: Never send anything that looks like JSON/code to the customer
    let finalReply = (botResponse.reply || '').trim();
    const looksLikeJSON = !finalReply
      || finalReply.length < 2
      || finalReply.includes('{"')
      || finalReply.includes('"reply"')
      || finalReply.includes('"score_delta"')
      || finalReply.startsWith('{')
      || finalReply.startsWith('[')
      || /^[\{\}\[\]",:.\s]+$/.test(finalReply);

    if (looksLikeJSON) {
      console.error('[bot-handler] Reply looks like JSON/garbage, using fallback. Raw:', JSON.stringify(botResponse.reply));
      // Last attempt: extract any Hebrew text from the mess
      const hebrewExtract = (botResponse.reply || '').match(/[\u0590-\u05FF][^"{}[\]]+/);
      finalReply = hebrewExtract ? hebrewExtract[0].trim() : FALLBACK_REPLY;
    }
    botResponse.reply = finalReply;

    // ── 8. Smart scoring based on intent ──
    const intentMultiplier: Record<string, number> = { strong: 1.5, medium: 1.0, weak: 0.5, none: 0 };
    const multiplier = intentMultiplier[botResponse.intent_strength] ?? 1.0;
    const adjustedDelta = Math.round((botResponse.score_delta || 0) * multiplier);

    // Auto-disqualify: intent=none + negative sentiment = drop score
    const isDisqualified = botResponse.intent_strength === 'none' && botResponse.sentiment === 'negative';
    const scoreDelta = isDisqualified ? Math.min(adjustedDelta, -10) : adjustedDelta;
    const newScore = Math.max(0, Math.min(100, (lead.bot_score || 0) + scoreDelta));

    let newStage = lead.bot_stage || 'new';
    if (isDisqualified) newStage = 'closed';
    else if (newScore >= 70) newStage = 'hot';
    else if (newScore >= 40) newStage = 'warm';
    else if (messageCount >= 2) newStage = 'qualifying';

    // Transfer ONLY when there's a clear reason
    const shouldTransfer = botResponse.should_transfer
      || messageCount >= MAX_MESSAGES;

    if (shouldTransfer && !isDisqualified) newStage = 'transferred';

    let transferReason = botResponse.transfer_reason || '';
    if (!transferReason && shouldTransfer) {
      if (messageCount >= MAX_MESSAGES) transferReason = `שיחה ארוכה (${messageCount} הודעות)`;
      else transferReason = 'הבוט זיהה צורך בנציגה';
    }

    await supabase.from('leads').update({
      bot_score: newScore,
      bot_stage: newStage,
      product_interest: botResponse.product_guess || lead.product_interest,
      last_bot_message_at: new Date().toISOString(),
      ...(botResponse.summary ? { conversation_summary: botResponse.summary, summary_updated_at: new Date().toISOString() } : {}),
      ...(shouldTransfer ? { transferred_to_agent_at: new Date().toISOString() } : {}),
    }).eq('id', lead.id);

    // ── Update session state with rich memory ──
    const prevProductsMentioned = sessionState.products_mentioned || [];
    const prevProductsRejected = sessionState.products_rejected || [];
    const newKeyInfo = { ...(sessionState.key_info || {}), ...(botResponse.key_info || {}) };
    // Clean empty values from key_info
    for (const k of Object.keys(newKeyInfo)) {
      if (!newKeyInfo[k] || newKeyInfo[k] === '?' || newKeyInfo[k] === 'unknown') delete newKeyInfo[k];
    }

    const productGuess = botResponse.product_guess || '';
    const updatedProductsMentioned = productGuess && !prevProductsMentioned.includes(productGuess)
      ? [...prevProductsMentioned, productGuess] : prevProductsMentioned;
    const updatedProductsRejected = (botResponse.sentiment === 'negative' && productGuess && !prevProductsRejected.includes(productGuess))
      ? [...prevProductsRejected, productGuess] : prevProductsRejected;

    await supabase.from('bot_sessions').update({
      state: {
        message_count: messageCount,
        last_score: newScore,
        lead_type: botResponse.lead_type || sessionState.lead_type || 'curious',
        products_mentioned: updatedProductsMentioned,
        products_rejected: updatedProductsRejected,
        key_info: newKeyInfo,
        last_summary: botResponse.summary || sessionState.last_summary || '',
      },
      last_activity: new Date().toISOString(),
    }).eq('id', session.id);

    // ── 9. Save bot reply ──
    await supabase.from('messages').insert({
      conversation_id: convo.id,
      sender_type: 'bot',
      content: botResponse.reply,
    });

    // ── 10. Transfer to work queue + WhatsApp alerts ──
    if (shouldTransfer && !isDisqualified) {
      const { data: existing } = await supabase
        .from('work_queue')
        .select('id')
        .eq('lead_id', lead.id)
        .eq('status', 'pending')
        .maybeSingle();

      if (!existing) {
        await supabase.from('work_queue').insert({
          lead_id: lead.id,
          reason: transferReason,
          priority: newScore >= 90 ? 1 : newScore >= 70 ? 2 : 3,
          status: 'pending',
        });
      }

      const alertMsg = `🔔 *ליד להעברה*\n\n👤 ${lead.full_name || 'לא ידוע'}\n📱 ${normalizedPhone}\n📊 ציון: ${newScore}\n💡 מוצר: ${botResponse.product_guess || '?'}\n📝 סיבה: ${transferReason}\n\n💬 ${botResponse.summary || 'אין סיכום'}`;
      sendMessage(BUSINESS_PHONE, alertMsg).catch((e) =>
        console.warn('[bot-handler] Alert to business failed:', e)
      );
    }

    // Hot lead alert — even without transfer, notify when lead is very interested
    const wasNotHot = (lead.bot_score || 0) < 70;
    if (newScore >= 70 && wasNotHot && !shouldTransfer) {
      const hotAlert = `🔥 *ליד חם!*\n\n👤 ${lead.full_name || 'לא ידוע'}\n📱 ${normalizedPhone}\n📊 ציון: ${newScore}\n💡 מוצר: ${botResponse.product_guess || '?'}\n🎯 סוג: ${botResponse.lead_type}\n💪 כוונה: ${botResponse.intent_strength}\n\n💬 ${botResponse.summary || 'אין סיכום'}\n\nכדאי להתקשר! 📞`;
      sendMessage(BUSINESS_PHONE, hotAlert).catch((e) =>
        console.warn('[bot-handler] Hot lead alert failed:', e)
      );
    }

    // ── 11. Log analytics for weekly report ──
    supabase.from('integration_logs').insert({
      source: 'bot_analytics',
      status: 'success',
      request_data: {
        lead_id: lead.id,
        message_count: messageCount,
        sentiment: botResponse.sentiment,
        stagnant: botResponse.stagnant,
        score_delta: scoreDelta,
        raw_score_delta: botResponse.score_delta,
        product_guess: botResponse.product_guess,
        should_transfer: shouldTransfer,
        transfer_reason: transferReason,
        reply_length: botResponse.reply.length,
        input_length: text.length,
        lead_type: botResponse.lead_type,
        intent_strength: botResponse.intent_strength,
        conversation_stage: conversationStage,
        is_disqualified: isDisqualified,
      },
    }).then((res: { error: unknown }) => { if (res.error) console.warn('[bot-handler] Analytics log failed:', res.error); });

    // ── 12. Send reply via WhatsApp ──
    const waResult = await sendMessage(normalizedPhone, botResponse.reply);
    if (!waResult.ok) {
      console.warn('[bot-handler] WhatsApp send failed:', waResult.error);
    }

    return jsonResponse({
      ok: true,
      reply: botResponse.reply,
      score: newScore,
      stage: newStage,
      transferred: shouldTransfer,
    });
  } catch (error) {
    console.error('[bot-handler] Error:', error);
    return jsonResponse({ error: 'Internal error' }, 500);
  }
});

function jsonResponse(data: Record<string, unknown>, status = 200): Response {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  });
}
