/**
 * Generic Webhook - universal endpoint for any future lead source.
 *
 * Accepts any JSON payload with flexible field mapping.
 * The `source` field in the payload determines the lead source.
 *
 * Minimum required: at least one of { name, phone, email }
 *
 * Full supported fields:
 * {
 *   name / full_name / first_name + last_name,
 *   phone / phone_number / tel / mobile,
 *   email / mail,
 *   city / location,
 *   notes / message / comments,
 *   property_interest / property,
 *   budget_min / budget_max / budget,
 *   source (string - will be validated against enum),
 *   external_id / id,
 *   ...any other fields stored in raw_data
 * }
 */
import {
  corsHeaders,
  errorResponse,
  successResponse,
  getSupabaseClient,
  validateApiKey,
  validateSource,
  processIncomingLead,
} from '../_shared/lead-processor.ts';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  if (req.method !== 'POST') {
    return errorResponse('Method not allowed', 405);
  }

  if (!validateApiKey(req)) {
    return errorResponse('Unauthorized', 401);
  }

  try {
    const body = await req.json();
    console.log('Received generic webhook:', JSON.stringify(body, null, 2));

    const supabase = getSupabaseClient();

    // Flexible field extraction
    const fullName = body.full_name || body.name || body.fullName ||
      (body.first_name || body.firstName
        ? `${body.first_name || body.firstName} ${body.last_name || body.lastName || ''}`.trim()
        : null) ||
      body.contact_name || null;

    const phone = body.phone || body.phone_number || body.phoneNumber || body.tel || body.mobile || null;
    const email = body.email || body.mail || body.emailAddress || body.email_address || null;
    const city = body.city || body.location || body.address || null;
    const notes = body.notes || body.message || body.comments || body.description || body.details || null;
    const propertyInterest = body.property_interest || body.property || body.interest || null;
    const budgetMin = body.budget_min || body.budgetMin || null;
    const budgetMax = body.budget_max || body.budgetMax || null;
    const budget = body.budget || null;
    const externalId = body.external_id || body.id || null;
    const source = validateSource(body.source || 'manual', 'manual');

    // Parse single budget value into range if needed
    let parsedBudgetMin = budgetMin ? Number(budgetMin) : null;
    let parsedBudgetMax = budgetMax ? Number(budgetMax) : null;
    if (!parsedBudgetMin && !parsedBudgetMax && budget) {
      const budgetNum = parseInt(budget.toString().replace(/[^\d]/g, ''));
      if (!isNaN(budgetNum)) {
        parsedBudgetMin = budgetNum * 0.8;
        parsedBudgetMax = budgetNum * 1.2;
      }
    }

    if (!fullName && !phone && !email) {
      return errorResponse('At least one of: name, phone, or email is required');
    }

    const result = await processIncomingLead(supabase, {
      full_name: fullName,
      email,
      phone,
      city,
      notes,
      property_interest: propertyInterest,
      budget_min: parsedBudgetMin,
      budget_max: parsedBudgetMax,
      external_id: externalId,
      source,
      raw_payload: body,
    }, body.source || 'generic');

    if (!result.success) {
      return errorResponse(result.error || 'Failed to process lead', 500);
    }

    return successResponse({
      success: true,
      action: result.action,
      lead_id: result.lead_id,
    });
  } catch (error) {
    console.error('Error processing generic webhook:', error);
    return errorResponse('Internal server error', 500);
  }
});
