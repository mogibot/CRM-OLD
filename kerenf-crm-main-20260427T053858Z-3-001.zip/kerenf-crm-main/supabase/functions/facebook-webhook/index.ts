import {
  corsHeaders,
  errorResponse,
  successResponse,
  getSupabaseClient,
  validateApiKey,
  processIncomingLead,
} from '../_shared/lead-processor.ts';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  const url = new URL(req.url);

  // ── Facebook Webhook Verification (GET) ──
  if (req.method === 'GET') {
    const mode = url.searchParams.get('hub.mode');
    const token = url.searchParams.get('hub.verify_token');
    const challenge = url.searchParams.get('hub.challenge');

    const verifyToken = Deno.env.get('FACEBOOK_VERIFY_TOKEN') || 'leadflow_verify_2024';

    if (mode === 'subscribe' && token === verifyToken) {
      console.log('Facebook webhook verified successfully');
      return new Response(challenge, {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'text/plain' },
      });
    }

    return new Response('Forbidden', { status: 403, headers: corsHeaders });
  }

  // ── Handle incoming leads (POST) ──
  if (req.method === 'POST') {
    if (!validateApiKey(req)) {
      return errorResponse('Unauthorized', 401);
    }

    try {
      const body = await req.json();
      console.log('Received Facebook webhook:', JSON.stringify(body, null, 2));

      const supabase = getSupabaseClient();

      // Process Facebook Lead Ads format
      if (body.entry) {
        for (const entry of body.entry) {
          const changes = entry.changes || [];

          for (const change of changes) {
            if (change.field === 'leadgen') {
              const leadgenId = change.value?.leadgen_id;
              const formId = change.value?.form_id;
              const pageId = change.value?.page_id;

              console.log('Processing FB lead:', { leadgenId, formId, pageId });

              // Try to enrich with Graph API first
              let enrichedName: string | null = null;
              let enrichedEmail: string | null = null;
              let enrichedPhone: string | null = null;
              let enrichedCity: string | null = null;

              const accessToken = Deno.env.get('FACEBOOK_PAGE_ACCESS_TOKEN');
              if (accessToken && leadgenId) {
                try {
                  const graphUrl = `https://graph.facebook.com/v21.0/${leadgenId}?access_token=${accessToken}`;
                  const graphResp = await fetch(graphUrl);
                  const graphData = await graphResp.json();

                  if (graphData.field_data) {
                    for (const field of graphData.field_data) {
                      const fname = field.name.toLowerCase();
                      const fval = field.values?.[0] || '';
                      if (fname === 'full_name' || fname === 'name') enrichedName = fval;
                      else if (fname === 'email') enrichedEmail = fval;
                      else if (fname === 'phone_number' || fname === 'phone') enrichedPhone = fval;
                      else if (fname === 'city') enrichedCity = fval;
                    }
                  }
                } catch (graphErr) {
                  console.error('Graph API enrichment failed (non-blocking):', graphErr);
                }
              }

              await processIncomingLead(supabase, {
                full_name: enrichedName || `Facebook Lead ${leadgenId?.slice(-6) || 'Unknown'}`,
                email: enrichedEmail,
                phone: enrichedPhone,
                city: enrichedCity,
                external_id: leadgenId,
                source: 'facebook',
                raw_payload: { leadgen_id: leadgenId, form_id: formId, page_id: pageId, ...change.value },
              }, 'facebook');
            }
          }
        }
      }

      // Handle direct lead data (for Instagram or custom integrations)
      // Use else-if to prevent double-processing when entry payload also contains root-level leadgen_id
      else if (body.leadgen_id || body.lead_id) {
        const leadId = body.leadgen_id || body.lead_id;

        await processIncomingLead(supabase, {
          full_name: body.full_name || body.name || `Instagram Lead ${leadId?.slice(-6) || 'Unknown'}`,
          email: body.email,
          phone: body.phone,
          external_id: leadId,
          source: 'instagram',
          raw_payload: body,
        }, 'instagram');
      }

      return successResponse({ success: true });
    } catch (error) {
      console.error('Error processing webhook:', error);
      return errorResponse('Internal server error', 500);
    }
  }

  return errorResponse('Method not allowed', 405);
});
