/**
 * WATI Webhook — receives incoming WA messages from WATI,
 * forwards them to bot-handler for AI processing.
 */
import { corsHeaders, errorResponse, successResponse, getSupabaseClient, normalizePhone } from '../_shared/lead-processor.ts';
import { sendMessage } from '../_shared/whatsapp.ts';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  // Meta webhook verification (GET request)
  if (req.method === 'GET') {
    const url = new URL(req.url);
    const mode = url.searchParams.get('hub.mode');
    const token = url.searchParams.get('hub.verify_token');
    const challenge = url.searchParams.get('hub.challenge');
    const verifyToken = Deno.env.get('WHATSAPP_VERIFY_TOKEN') || 'karnaf_verify_2024';

    if (mode === 'subscribe' && token === verifyToken) {
      console.log('[webhook] Meta verification OK');
      return new Response(challenge, { status: 200 });
    }
    console.warn(`[webhook] Verify failed: mode=${mode}, token=${token?.slice(0, 4)}...`);
    return errorResponse('Forbidden', 403);
  }

  if (req.method !== 'POST') {
    return errorResponse('Method not allowed', 405);
  }

  try {
    const body = await req.json();
    console.log('[webhook] Received:', JSON.stringify(body).slice(0, 500));

    // Parse Meta Cloud API format OR WATI format
    let phone: string | null = null;
    let text = '';
    let senderName: string | null = null;

    // Meta Cloud API format
    const entry = body.entry?.[0];
    const changes = entry?.changes?.[0];
    const value = changes?.value;

    if (value?.messages?.[0]) {
      // Meta Cloud API incoming message
      const msg = value.messages[0];
      phone = msg.from; // e.g. "972501234567"
      text = msg.text?.body || '';
      const contact = value.contacts?.[0];
      senderName = contact?.profile?.name || null;

      // Skip status updates
      if (value.statuses) {
        return successResponse({ ok: true, skipped: true, reason: 'status update' });
      }
    } else if (body.waId || body.senderPhone || body.phone || body.from) {
      // WATI format (fallback)
      phone = body.waId || body.senderPhone || body.phone || body.from;
      text = body.text || body.message?.text || body.data?.text || '';
      senderName = body.senderName || body.pushName || body.name || null;

      const eventType = body.eventType || body.event || '';
      if (eventType && !['message', 'messages', ''].includes(eventType)) {
        return successResponse({ ok: true, skipped: true, reason: `Event type: ${eventType}` });
      }
    } else if (body.entry) {
      // Meta webhook but no message (e.g. status update only)
      return successResponse({ ok: true, skipped: true, reason: 'no message in payload' });
    }

    if (!phone) {
      console.warn('[wati-webhook] No phone in payload');
      return errorResponse('Missing phone number');
    }

    if (!text) {
      // Media message (image, voice, document) — log it and send acknowledgment
      const msg = value?.messages?.[0];
      const mediaType = msg?.type || body.type || 'media';
      console.log(`[wati-webhook] Media message (${mediaType}) from ${phone}`);

      // Save media event to DB so the lead isn't lost
      const supabase = getSupabaseClient();
      const normalizedPhone = normalizePhone(phone) || phone;
      const { data: lead } = await supabase
        .from('leads')
        .select('id')
        .eq('phone', normalizedPhone)
        .maybeSingle();

      if (lead) {
        // Find conversation and save media note
        const { data: convo } = await supabase
          .from('conversations')
          .select('id')
          .eq('lead_id', lead.id)
          .eq('channel', 'whatsapp')
          .maybeSingle();

        if (convo) {
          await supabase.from('messages').insert({
            conversation_id: convo.id,
            sender_type: 'lead',
            content: `[${mediaType === 'image' ? 'תמונה' : mediaType === 'audio' ? 'הודעה קולית' : mediaType === 'document' ? 'מסמך' : 'מדיה'}]`,
          });
        }

        // Send auto-reply for media
        await sendMessage(normalizedPhone, 'קיבלתי! אחזור אליך בהקדם 🙏');
      }

      return successResponse({ ok: true, mediaHandled: true, mediaType });
    }

    // Forward to bot-handler
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;

    const botRes = await fetch(`${supabaseUrl}/functions/v1/bot-handler`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${serviceKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ phone, text, senderName }),
    });

    const botResult = await botRes.json();

    if (!botRes.ok) {
      console.error('[wati-webhook] bot-handler error:', botResult);
      // Still return 200 to WATI so it doesn't retry
    }

    return successResponse({ ok: true, botResult });
  } catch (error) {
    console.error('[wati-webhook] Error:', error);
    // Return 200 even on error to prevent WATI retries
    return successResponse({ ok: false, error: 'Internal error' });
  }
});
