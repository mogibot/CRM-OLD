/**
 * Send Agent Message — allows CRM agents to send WhatsApp messages.
 * Called from the AgentPanel in the Work Queue.
 * Supports both WhatsApp Cloud API (free) and WATI (fallback).
 */
import { corsHeaders, normalizePhone } from '../_shared/lead-processor.ts';
import { sendMessage } from '../_shared/whatsapp.ts';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  if (req.method !== 'POST') {
    return jsonResponse({ error: 'Method not allowed' }, 405);
  }

  try {
    const { phone, text } = await req.json();
    if (!phone || !text) {
      return jsonResponse({ error: 'Missing phone or text' }, 400);
    }

    const normalizedPhone = normalizePhone(phone) || phone;

    const result = await sendMessage(normalizedPhone, text);
    if (!result.ok) {
      console.error('[send-agent-message] WhatsApp error:', result.error);
      return jsonResponse({ error: result.error || 'WhatsApp send failed' }, 502);
    }

    return jsonResponse({ ok: true });
  } catch (error) {
    console.error('[send-agent-message] Error:', error);
    return jsonResponse({ error: 'Internal error' }, 500);
  }
});

function jsonResponse(data: Record<string, unknown>, status = 200): Response {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  });
}
