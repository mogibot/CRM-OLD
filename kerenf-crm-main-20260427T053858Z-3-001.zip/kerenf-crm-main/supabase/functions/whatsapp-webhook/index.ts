import {
  corsHeaders,
  errorResponse,
  successResponse,
  getSupabaseClient,
  validateApiKey,
  processIncomingLead,
} from '../_shared/lead-processor.ts';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  if (req.method !== 'POST') {
    return errorResponse('Method not allowed', 405);
  }

  if (!validateApiKey(req)) {
    return errorResponse('Unauthorized', 401);
  }

  try {
    const body = await req.json();
    console.log('Received WhatsApp webhook:', JSON.stringify(body, null, 2));

    const supabase = getSupabaseClient();

    // Extract lead data - supports WhatsApp Business API, Twilio, 360dialog, generic
    const phone = body.phone || body.phone_number || body.wa_id ||
      body.From?.replace('whatsapp:', '') ||
      body.contacts?.[0]?.wa_id ||
      body.entry?.[0]?.changes?.[0]?.value?.contacts?.[0]?.wa_id || null;

    const fullName = body.full_name || body.name || body.first_name ||
      body.contacts?.[0]?.profile?.name ||
      body.entry?.[0]?.changes?.[0]?.value?.contacts?.[0]?.profile?.name ||
      (body.first_name && body.last_name ? `${body.first_name} ${body.last_name}` : null);

    const email = body.email || null;
    const city = body.city || null;
    const notes = body.notes || body.message || body.text ||
      body.entry?.[0]?.changes?.[0]?.value?.messages?.[0]?.text?.body || null;

    const externalId = body.external_id || body.id || phone || null;

    if (!phone && !email && !fullName) {
      return errorResponse('Missing required fields: phone, email, or full_name');
    }

    const result = await processIncomingLead(supabase, {
      full_name: fullName,
      email,
      phone,
      city,
      notes,
      external_id: externalId,
      source: 'whatsapp',
      raw_payload: body,
    }, 'whatsapp');

    if (!result.success) {
      return errorResponse(result.error || 'Failed to process lead', 500);
    }

    return successResponse({
      success: true,
      action: result.action,
      lead_id: result.lead_id,
    });
  } catch (error) {
    console.error('Error processing WhatsApp webhook:', error);
    return errorResponse('Internal server error', 500);
  }
});
