import {
  corsHeaders,
  errorResponse,
  successResponse,
  getSupabaseClient,
  validateApiKey,
  validateSource,
  processIncomingLead,
} from '../_shared/lead-processor.ts';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  if (req.method !== 'POST') {
    return errorResponse('Method not allowed', 405);
  }

  if (!validateApiKey(req)) {
    return errorResponse('Unauthorized', 401);
  }

  try {
    const body = await req.json();
    console.log('Received website/form webhook:', JSON.stringify(body, null, 2));

    const supabase = getSupabaseClient();

    // Flexible field mapping - supports any form structure
    const fullName = body.full_name || body.name || body.fullName ||
      (body.first_name || body.firstName
        ? `${body.first_name || body.firstName} ${body.last_name || body.lastName || ''}`.trim()
        : null) ||
      body.contact_name || null;

    const phone = body.phone || body.phone_number || body.phoneNumber || body.tel || body.mobile || null;
    const email = body.email || body.mail || body.emailAddress || body.email_address || null;
    const city = body.city || body.location || body.address || null;
    const notes = body.notes || body.message || body.comments || body.description || body.details || null;
    const propertyInterest = body.property_interest || body.property || body.interest || null;
    const budgetMin = body.budget_min || body.budgetMin || body.budget || null;
    const budgetMax = body.budget_max || body.budgetMax || null;

    // Determine source
    const sourceMap: Record<string, string> = {
      wix: 'wix_site',
      wordpress: 'wix_site',
      landing_page: 'campaign',
      email: 'email_list',
      campaign: 'campaign',
      referral: 'referral',
    };
    const sourceHint = body.source || body.utm_source || body.origin || 'wix_site';
    const source = sourceMap[sourceHint] || validateSource(sourceHint, 'wix_site');

    if (!fullName && !phone && !email) {
      return errorResponse('At least one of: name, phone, or email is required');
    }

    const result = await processIncomingLead(supabase, {
      full_name: fullName,
      email,
      phone,
      city,
      notes,
      property_interest: propertyInterest,
      budget_min: budgetMin ? Number(budgetMin) : null,
      budget_max: budgetMax ? Number(budgetMax) : null,
      source,
      raw_payload: body,
    }, 'website_form');

    if (!result.success) {
      return errorResponse(result.error || 'Failed to process lead', 500);
    }

    return successResponse({
      success: true,
      action: result.action,
      lead_id: result.lead_id,
    });
  } catch (error) {
    console.error('Error processing website webhook:', error);
    return errorResponse('Internal server error', 500);
  }
});
