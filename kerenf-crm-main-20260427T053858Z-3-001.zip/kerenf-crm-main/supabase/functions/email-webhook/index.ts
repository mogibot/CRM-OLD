/**
 * Email Webhook - receives parsed email data from Zapier/Make.com
 *
 * Expected payload formats:
 *
 * Zapier Gmail trigger:
 * { from_email, from_name, subject, body_plain, body_html, date }
 *
 * Make.com Gmail module:
 * { from: { address, name }, subject, text, html, date }
 *
 * Generic:
 * { email, name, subject, body, phone? }
 */
import {
  corsHeaders,
  errorResponse,
  successResponse,
  getSupabaseClient,
  validateApiKey,
  processIncomingLead,
} from '../_shared/lead-processor.ts';

// Simple heuristic to extract a phone number from email body text
function extractPhoneFromText(text: string | null | undefined): string | null {
  if (!text) return null;
  // Match Israeli phone patterns: 05X-XXXXXXX, +972-5X-XXXXXXX, etc.
  const match = text.match(/(?:\+972|972|0)[\s\-]?(?:5[0-9])[\s\-]?\d{3}[\s\-]?\d{4}/);
  return match ? match[0] : null;
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  if (req.method !== 'POST') {
    return errorResponse('Method not allowed', 405);
  }

  if (!validateApiKey(req)) {
    return errorResponse('Unauthorized', 401);
  }

  try {
    const body = await req.json();
    console.log('Received email webhook:', JSON.stringify(body, null, 2));

    const supabase = getSupabaseClient();

    // ── Extract sender email ──
    const senderEmail =
      body.from_email ||        // Zapier
      body.from?.address ||     // Make.com
      body.email ||             // Generic
      body.sender_email ||
      null;

    // ── Extract sender name ──
    const senderName =
      body.from_name ||         // Zapier
      body.from?.name ||        // Make.com
      body.name ||              // Generic
      body.sender_name ||
      null;

    // ── Extract subject and body ──
    const subject = body.subject || body.title || '';
    const bodyText = body.body_plain || body.text || body.body || body.message || '';
    // ── Extract phone from body if not provided directly ──
    const phone = body.phone || body.phone_number || extractPhoneFromText(bodyText) || null;

    // Build notes from the email content
    const noteParts: string[] = [];
    if (subject) noteParts.push(`נושא: ${subject}`);
    if (bodyText) noteParts.push(bodyText.slice(0, 500)); // Limit to 500 chars
    const notes = noteParts.join('\n') || null;

    if (!senderEmail && !senderName && !phone) {
      return errorResponse('Missing required fields: email, name, or phone from the parsed email');
    }

    const result = await processIncomingLead(supabase, {
      full_name: senderName,
      email: senderEmail,
      phone,
      notes,
      source: 'email_list',
      raw_payload: body,
    }, 'email_parsed');

    if (!result.success) {
      return errorResponse(result.error || 'Failed to process email lead', 500);
    }

    return successResponse({
      success: true,
      action: result.action,
      lead_id: result.lead_id,
      message: 'Email lead processed successfully',
    });
  } catch (error) {
    console.error('Error processing email webhook:', error);
    return errorResponse('Internal server error', 500);
  }
});
