import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { source, action } = await req.json();
    console.log(`Test webhook called for source: ${source}, action: ${action}`);

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    if (action === 'test_connection') {
      // Log the test connection attempt
      const { error: logError } = await supabase
        .from('integration_logs')
        .insert({
          source: source,
          status: 'test',
          request_data: { type: 'connection_test', timestamp: new Date().toISOString() },
          response_data: { success: true, message: 'Connection test successful' }
        });

      if (logError) {
        console.error('Error logging test:', logError);
        throw logError;
      }

      return new Response(
        JSON.stringify({ 
          success: true, 
          message: 'החיבור תקין! המערכת מוכנה לקבל לידים.',
          timestamp: new Date().toISOString()
        }),
        { 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 200 
        }
      );
    }

    if (action === 'send_test_lead') {
      // Create a test lead
      const testLeadData = {
        full_name: `ליד בדיקה - ${source}`,
        phone: '0501234567',
        email: 'test@example.com',
        source: source as any,
        stage: 'new_lead' as any,
        notes: `ליד בדיקה שנוצר אוטומטית מאשף החיבור - ${new Date().toLocaleDateString('he-IL')}`,
        score: 0,
        raw_data: { test: true, created_via: 'connection_wizard' }
      };

      const { data: lead, error: leadError } = await supabase
        .from('leads')
        .insert(testLeadData)
        .select()
        .single();

      if (leadError) {
        console.error('Error creating test lead:', leadError);
        throw leadError;
      }

      // Log the successful test lead creation
      await supabase
        .from('integration_logs')
        .insert({
          source: source,
          status: 'success',
          lead_id: lead.id,
          request_data: { type: 'test_lead', ...testLeadData },
          response_data: { success: true, lead_id: lead.id }
        });

      return new Response(
        JSON.stringify({ 
          success: true, 
          message: 'ליד בדיקה נוצר בהצלחה! בדוק בדף הלידים.',
          lead_id: lead.id,
          lead_name: lead.full_name
        }),
        { 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 200 
        }
      );
    }

    return new Response(
      JSON.stringify({ success: false, message: 'פעולה לא מוכרת' }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 400 
      }
    );

  } catch (error: unknown) {
    console.error('Test webhook error:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return new Response(
      JSON.stringify({ 
        success: false, 
        message: 'שגיאה בבדיקה',
        error: errorMessage 
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500 
      }
    );
  }
});
