/**
 * Weekly Report — generates analytics + AI insights and emails them.
 * Triggered by pg_cron every Sunday 09:00 or manually via HTTP POST.
 */
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { corsHeaders } from '../_shared/lead-processor.ts';
import { sendEmail } from '../_shared/email.ts';

const GEMINI_API_KEY = Deno.env.get('GEMINI_API_KEY') || '';
const REPORT_EMAIL = 'karnaf.yazamut@gmail.com';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  const supabase = createClient(
    Deno.env.get('SUPABASE_URL')!,
    Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
  );

  try {
    const now = new Date();
    const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    const weekAgoISO = weekAgo.toISOString();

    // ── 1. Fetch analytics from integration_logs ──
    const { data: analytics } = await supabase
      .from('integration_logs')
      .select('request_data, created_at')
      .eq('source', 'bot_analytics')
      .gte('created_at', weekAgoISO)
      .order('created_at', { ascending: false });

    const logs = (analytics || []).map((r: { request_data: Record<string, unknown> }) => r.request_data);

    // ── 2. Fetch new leads this week ──
    const { count: newLeadsCount } = await supabase
      .from('leads')
      .select('id', { count: 'exact', head: true })
      .gte('created_at', weekAgoISO);

    // ── 3. Fetch transferred leads ──
    const { count: transferCount } = await supabase
      .from('work_queue')
      .select('id', { count: 'exact', head: true })
      .gte('created_at', weekAgoISO);

    // ── 4. Compute metrics ──
    const totalConversations = new Set(logs.map((l: Record<string, unknown>) => l.lead_id)).size;
    const totalMessages = logs.length;
    const avgMessages = totalConversations > 0 ? Math.round(totalMessages / totalConversations) : 0;

    const sentimentCounts = { positive: 0, neutral: 0, negative: 0 };
    const productCounts: Record<string, number> = {};
    const transferReasons: Record<string, number> = {};
    let totalInputLen = 0;
    let totalReplyLen = 0;

    for (const l of logs) {
      const s = l.sentiment as string;
      if (s in sentimentCounts) sentimentCounts[s as keyof typeof sentimentCounts]++;

      const p = l.product_guess as string;
      if (p && p !== 'unknown' && p !== '?') productCounts[p] = (productCounts[p] || 0) + 1;

      if (l.should_transfer && l.transfer_reason) {
        const r = l.transfer_reason as string;
        transferReasons[r] = (transferReasons[r] || 0) + 1;
      }

      totalInputLen += (l.input_length as number) || 0;
      totalReplyLen += (l.reply_length as number) || 0;
    }

    const sentimentTotal = sentimentCounts.positive + sentimentCounts.neutral + sentimentCounts.negative || 1;
    const pct = (n: number) => Math.round((n / sentimentTotal) * 100);

    const topProducts = Object.entries(productCounts).sort((a, b) => b[1] - a[1]).slice(0, 5);
    const topReasons = Object.entries(transferReasons).sort((a, b) => b[1] - a[1]).slice(0, 5);

    // Gemini cost estimate (Flash free tier = $0, but estimate tokens for reference)
    const estimatedTokens = totalInputLen + totalReplyLen;
    const estimatedCost = (estimatedTokens / 1_000_000) * 0.075; // ~$0.075/1M tokens for Flash

    // ── 5. Fetch sample conversations for AI analysis ──
    const { data: recentMessages } = await supabase
      .from('messages')
      .select('conversation_id, sender_type, content, created_at')
      .gte('created_at', weekAgoISO)
      .order('created_at', { ascending: true })
      .limit(200);

    // Group by conversation
    const convos: Record<string, Array<{ role: string; text: string }>> = {};
    for (const m of recentMessages || []) {
      if (!convos[m.conversation_id]) convos[m.conversation_id] = [];
      convos[m.conversation_id].push({ role: m.sender_type, text: m.content });
    }

    // Get negative/transferred conversations for prompt improvement
    const negLogs = logs.filter((l: Record<string, unknown>) => l.sentiment === 'negative' || l.should_transfer);
    const negLeadIds = new Set(negLogs.map((l: Record<string, unknown>) => l.lead_id));

    // ── 6. AI Analysis with Gemini ──
    let aiInsights = '';
    let promptSuggestions = '';

    if (GEMINI_API_KEY && totalMessages > 0) {
      const sampleConvos = Object.values(convos).slice(0, 10).map(
        (msgs) => msgs.map((m) => `${m.role}: ${m.text}`).join('\n')
      ).join('\n---\n');

      // General insights
      const insightsPrompt = `אתה אנליסט שיווקי. הנה נתוני שבוע של בוט מכירות נדל"ן:
- ${totalConversations} שיחות, ${totalMessages} הודעות
- סנטימנט: ${pct(sentimentCounts.positive)}% חיובי, ${pct(sentimentCounts.neutral)}% ניטרלי, ${pct(sentimentCounts.negative)}% שלילי
- מוצרים: ${topProducts.map(([k, v]) => `${k}(${v})`).join(', ') || 'אין מספיק נתונים'}
- ${transferCount || 0} הועברו לנציגה

דוגמאות שיחות:
${sampleConvos}

תן 3-5 תובנות על הקהל ו-3-5 המלצות לשיפור הבוט. בעברית, תמציתי.`;

      const insightsRes = await callGemini(insightsPrompt);
      aiInsights = insightsRes || 'לא הצלחתי לייצר תובנות השבוע.';

      // Prompt improvement suggestions
      if (negLeadIds.size > 0) {
        const negConvos = Object.values(convos).slice(0, 5).map(
          (msgs) => msgs.map((m) => `${m.role}: ${m.text}`).join('\n')
        ).join('\n---\n');

        const promptImprovementPrompt = `אתה מומחה לשיפור prompts של בוטים. הנה שיחות שנגמרו בצורה לא טובה (סנטימנט שלילי או הועברו לנציגה):

${negConvos}

תציע 3 שינויים ספציפיים לפרומפט של הבוט שישפרו את התוצאות. כל הצעה צריכה להיות קונקרטית עם דוגמה. בעברית.`;

        promptSuggestions = await callGemini(promptImprovementPrompt) || '';
      }

      // Save suggestions to bot_config
      if (promptSuggestions) {
        await supabase.from('bot_config').upsert({
          key: 'prompt_suggestions',
          value: { suggestions: promptSuggestions, generated_at: now.toISOString() },
        }, { onConflict: 'key' });
      }
    }

    // ── 7. Build HTML email ──
    const dateRange = `${weekAgo.toLocaleDateString('he-IL')} — ${now.toLocaleDateString('he-IL')}`;

    const html = `<!DOCTYPE html>
<html dir="rtl" lang="he">
<head><meta charset="utf-8"><style>
  body { font-family: -apple-system, Arial, sans-serif; direction: rtl; max-width: 600px; margin: 0 auto; padding: 20px; color: #333; background: #f5f5f5; }
  .card { background: white; border-radius: 12px; padding: 20px; margin-bottom: 16px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
  h1 { color: #1a1a2e; font-size: 22px; }
  h2 { color: #16213e; font-size: 16px; margin-top: 0; }
  .metric { display: inline-block; text-align: center; padding: 12px 16px; margin: 4px; background: #f0f4ff; border-radius: 8px; min-width: 80px; }
  .metric .num { font-size: 28px; font-weight: bold; color: #1a1a2e; }
  .metric .label { font-size: 12px; color: #666; }
  .bar { height: 8px; border-radius: 4px; margin: 4px 0; }
  .positive { background: #4caf50; }
  .neutral { background: #ff9800; }
  .negative { background: #f44336; }
  .ai-box { background: #f8f9ff; border-right: 4px solid #5c6bc0; padding: 16px; border-radius: 8px; margin-top: 12px; white-space: pre-wrap; line-height: 1.6; }
  .cost { color: #666; font-size: 13px; }
  ul { padding-right: 20px; }
  li { margin-bottom: 6px; }
</style></head>
<body>
  <div class="card">
    <h1>📊 דוח שבועי — קרנף נדל"ן בוט</h1>
    <p style="color:#666">${dateRange}</p>
  </div>

  <div class="card">
    <h2>📈 מספרים</h2>
    <div class="metric"><div class="num">${totalConversations}</div><div class="label">שיחות</div></div>
    <div class="metric"><div class="num">${totalMessages}</div><div class="label">הודעות</div></div>
    <div class="metric"><div class="num">${transferCount || 0}</div><div class="label">הועברו לנציגה</div></div>
    <div class="metric"><div class="num">${newLeadsCount || 0}</div><div class="label">לידים חדשים</div></div>
    <div class="metric"><div class="num">${avgMessages}</div><div class="label">ממוצע הודעות/שיחה</div></div>
  </div>

  <div class="card">
    <h2>😊 סנטימנט</h2>
    <div>חיובי: ${pct(sentimentCounts.positive)}%</div>
    <div class="bar positive" style="width:${pct(sentimentCounts.positive)}%"></div>
    <div>ניטרלי: ${pct(sentimentCounts.neutral)}%</div>
    <div class="bar neutral" style="width:${pct(sentimentCounts.neutral)}%"></div>
    <div>שלילי: ${pct(sentimentCounts.negative)}%</div>
    <div class="bar negative" style="width:${pct(sentimentCounts.negative)}%"></div>
  </div>

  <div class="card">
    <h2>💡 מוצרים מבוקשים</h2>
    <ul>${topProducts.length > 0 ? topProducts.map(([k, v]) => `<li>${k}: ${v} פניות</li>`).join('') : '<li>אין מספיק נתונים השבוע</li>'}</ul>
  </div>

  <div class="card">
    <h2>🔄 סיבות העברה לנציגה</h2>
    <ul>${topReasons.length > 0 ? topReasons.map(([k, v]) => `<li>${k}: ${v}</li>`).join('') : '<li>אין העברות השבוע</li>'}</ul>
  </div>

  <div class="card">
    <h2>💰 עלויות</h2>
    <p class="cost">Gemini API: ~$${estimatedCost.toFixed(2)} (${totalMessages} requests, ~${Math.round(estimatedTokens / 1000)}K tokens)</p>
    <p class="cost">WhatsApp Cloud API: free tier</p>
    <p class="cost"><strong>סה"כ: ~$${estimatedCost.toFixed(2)}</strong></p>
  </div>

  <div class="card">
    <h2>🧠 תובנות AI והמלצות</h2>
    <div class="ai-box">${aiInsights}</div>
  </div>

  ${promptSuggestions ? `<div class="card">
    <h2>✏️ המלצות לשיפור prompt</h2>
    <div class="ai-box">${promptSuggestions}</div>
  </div>` : ''}

  <p style="color:#999;font-size:11px;text-align:center">נוצר אוטומטית ע"י קרנף בוט • ${now.toLocaleDateString('he-IL')}</p>
</body>
</html>`;

    // ── 8. Send email ──
    const subject = `📊 דוח שבועי קרנף בוט — ${dateRange}`;
    const emailResult = await sendEmail(REPORT_EMAIL, subject, html);

    if (!emailResult.ok) {
      console.error('[weekly-report] Email send failed:', emailResult.error);
    }

    // Log the report generation
    await supabase.from('integration_logs').insert({
      source: 'weekly_report',
      status: emailResult.ok ? 'success' : 'error',
      request_data: {
        date_range: dateRange,
        total_conversations: totalConversations,
        total_messages: totalMessages,
        transfers: transferCount || 0,
        new_leads: newLeadsCount || 0,
        email_sent: emailResult.ok,
      },
    });

    return new Response(JSON.stringify({
      ok: true,
      email_sent: emailResult.ok,
      stats: { totalConversations, totalMessages, transfers: transferCount || 0, newLeads: newLeadsCount || 0 },
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('[weekly-report] Error:', error);
    return new Response(JSON.stringify({ error: 'Internal error' }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});

async function callGemini(prompt: string): Promise<string> {
  try {
    const res = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${GEMINI_API_KEY}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{ role: 'user', parts: [{ text: prompt }] }],
          generationConfig: { maxOutputTokens: 1000 },
        }),
      },
    );
    if (!res.ok) {
      console.error(`[weekly-report] Gemini error (${res.status})`);
      return '';
    }
    const data = await res.json();
    return data.candidates?.[0]?.content?.parts?.[0]?.text || '';
  } catch (err) {
    console.error('[weekly-report] Gemini call failed:', err);
    return '';
  }
}
