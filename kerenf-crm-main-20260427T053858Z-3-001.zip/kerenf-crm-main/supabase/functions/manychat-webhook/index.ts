import {
  corsHeaders,
  errorResponse,
  successResponse,
  getSupabaseClient,
  validateApiKey,
  processIncomingLead,
} from '../_shared/lead-processor.ts';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  if (req.method !== 'POST') {
    return errorResponse('Method not allowed', 405);
  }

  if (!validateApiKey(req)) {
    return errorResponse('Unauthorized', 401);
  }

  try {
    const body = await req.json();
    console.log('Received ManyChat webhook:', JSON.stringify(body, null, 2));

    const supabase = getSupabaseClient();

    // Extract data from ManyChat payload (various formats depending on flow config)
    const firstName = body.first_name || body.firstName || body.name?.split(' ')[0] || '';
    const lastName = body.last_name || body.lastName || body.name?.split(' ').slice(1).join(' ') || '';
    const fullName = body.full_name || `${firstName} ${lastName}`.trim() || null;
    const email = body.email || body.user_email || body.custom_fields?.email || null;
    const phone = body.phone || body.phone_number || body.custom_fields?.phone || null;
    const city = body.city || body.custom_fields?.city || null;
    const budget = body.budget || body.custom_fields?.budget || null;
    const externalId = body.subscriber_id || body.user_id || body.id || null;

    // Parse budget if provided
    let budgetMin: number | null = null;
    let budgetMax: number | null = null;
    if (budget) {
      const budgetNum = parseInt(budget.toString().replace(/[^\d]/g, ''));
      if (!isNaN(budgetNum)) {
        budgetMin = budgetNum * 0.8;
        budgetMax = budgetNum * 1.2;
      }
    }

    if (!fullName && !phone && !email) {
      return errorResponse('Missing required fields: name, phone, or email');
    }

    const result = await processIncomingLead(supabase, {
      full_name: fullName,
      email,
      phone,
      city,
      budget_min: budgetMin,
      budget_max: budgetMax,
      external_id: externalId,
      source: 'manychat',
      raw_payload: body,
    }, 'manychat');

    if (!result.success) {
      return errorResponse(result.error || 'Failed to process lead', 500);
    }

    return successResponse({
      success: true,
      action: result.action,
      lead_id: result.lead_id,
    });
  } catch (error) {
    console.error('Error processing ManyChat webhook:', error);
    return errorResponse('Internal server error', 500);
  }
});
