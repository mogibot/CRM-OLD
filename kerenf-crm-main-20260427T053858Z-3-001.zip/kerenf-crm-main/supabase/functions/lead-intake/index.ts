/**
 * Lead Intake — generic endpoint to receive leads from any source
 * (Make.com, Instagram, FB Lead Ads, manual, etc.)
 * 1. Validate + normalize
 * 2. Enrich name from Graph API if missing/numeric
 * 3. UPSERT lead (dedup by phone → email → external_id)
 * 4. Create bot_session + conversation
 * 5. Send reply via WhatsApp or Instagram DM
 * 6. Extract phone from message text if provided
 * 7. Log to integration_logs
 */
import {
  corsHeaders,
  errorResponse,
  successResponse,
  getSupabaseClient,
  validateApiKey,
  processIncomingLead,
  normalizePhone,
} from '../_shared/lead-processor.ts';
import { sendTemplate, toWhatsAppPhone } from '../_shared/whatsapp.ts';
import { sendInstagramMessage, fetchProfileName } from '../_shared/instagram.ts';

/** Detect Israeli phone number in free text */
const PHONE_REGEX = /(?:0\d{1,2}[-\s]?\d{3}[-\s]?\d{4}|(?:\+?972)[-\s]?\d{1,2}[-\s]?\d{3}[-\s]?\d{4})/;

/** Is this a Facebook/Instagram source? */
function isFbIgSource(source: string): boolean {
  return /facebook|instagram|fb|ig|messenger/i.test(source);
}

/** Is this specifically an Instagram-like source (not plain FB Lead Ads)? */
function isMessengerSource(source: string): boolean {
  return /messenger|instagram_dm|ig_dm/i.test(source);
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  if (req.method !== 'POST') {
    return errorResponse('Method not allowed', 405);
  }

  if (!validateApiKey(req)) {
    return errorResponse('Unauthorized', 401);
  }

  try {
    const body = await req.json();
    console.log('[lead-intake] Received:', JSON.stringify(body).slice(0, 500));

    const supabase = getSupabaseClient();

    const source = body.source || 'manual';
    const phone = body.phone || body.phone_number || null;
    let fullName = body.full_name || body.name || null;
    const email = body.email || null;
    const city = body.city || null;
    const notes = body.notes || body.message || null;
    const externalId = body.external_id || null;

    // ── Name enrichment for FB/IG sources ──
    const fbIg = isFbIgSource(source);
    if (fbIg && (!fullName || /^\d+$/.test(fullName))) {
      // Name is missing or is a numeric PSID — try Graph API enrichment
      const psid = fullName && /^\d+$/.test(fullName) ? fullName : externalId;

      if (psid) {
        // Store PSID as external_id for future reference
        if (!body.external_id) body.external_id = psid;

        const enrichedName = await fetchProfileName(psid);
        if (enrichedName) {
          fullName = enrichedName;
          console.log(`[lead-intake] Profile enrichment OK: ${psid} → ${fullName}`);
        }
      }

      // If still no name or still numeric, use friendly fallback
      if (!fullName || /^\d+$/.test(fullName)) {
        const suffix = (externalId || fullName || '0000').replace(/\D/g, '').slice(-4) || '0000';
        const label = /instagram|ig/i.test(source) ? 'אינסטגרם' : 'פייסבוק';
        fullName = `ליד ${label} #${suffix}`;
      }
    }

    // ── Extract phone from message text if no phone provided ──
    let extractedPhone: string | null = null;
    if (!phone && notes) {
      const phoneMatch = notes.match(PHONE_REGEX);
      if (phoneMatch) {
        extractedPhone = phoneMatch[0];
        console.log(`[lead-intake] Extracted phone from message: ${extractedPhone}`);
      }
    }

    const effectivePhone = phone || extractedPhone;

    if (!effectivePhone && !email && !fullName) {
      return errorResponse('At least phone, email, or full_name is required');
    }

    // Process lead through shared pipeline (dedup, create/update, log)
    const result = await processIncomingLead(supabase, {
      full_name: fullName,
      email,
      phone: effectivePhone,
      city,
      notes,
      property_interest: body.property_interest || null,
      budget_min: body.budget_min || null,
      budget_max: body.budget_max || null,
      external_id: body.external_id || externalId,
      source,
      raw_payload: body,
    }, source);

    if (!result.success) {
      return errorResponse(result.error || 'Failed to process lead', 500);
    }

    const normalizedPhone = normalizePhone(effectivePhone);

    // ── Determine channel ──
    const normalizedSource = (source || '').replace(/_.*/, '');
    const channel = ['facebook', 'instagram', 'whatsapp'].includes(normalizedSource)
      ? normalizedSource
      : isMessengerSource(source) ? 'facebook' : 'whatsapp';

    // ── Create conversation + initial message (always, even without phone) ──
    if (result.lead_id) {
      const { data: existingConvo } = await supabase
        .from('conversations')
        .select('id')
        .eq('lead_id', result.lead_id)
        .eq('channel', channel)
        .maybeSingle();

      let convoId = existingConvo?.id;
      if (!convoId) {
        const { data: newConvo } = await supabase
          .from('conversations')
          .insert({ lead_id: result.lead_id, channel })
          .select('id')
          .single();
        convoId = newConvo?.id;
      }

      if (convoId && notes) {
        await supabase.from('messages').insert({
          conversation_id: convoId,
          sender_type: 'lead',
          content: notes,
        });
      } else if (convoId && result.action === 'created') {
        const sourceLabel = { facebook: 'פייסבוק', instagram: 'אינסטגרם', whatsapp: 'וואטסאפ' }[channel] || source;
        await supabase.from('messages').insert({
          conversation_id: convoId,
          sender_type: 'system',
          content: `ליד נכנס מ-${sourceLabel}`,
        });
      }
    }

    // ── Create bot_session if we have a phone ──
    if (normalizedPhone && result.lead_id) {
      const { data: existingSession } = await supabase
        .from('bot_sessions')
        .select('id')
        .eq('lead_id', result.lead_id)
        .maybeSingle();

      if (!existingSession) {
        await supabase.from('bot_sessions').insert({
          lead_id: result.lead_id,
          wati_phone: toWhatsAppPhone(normalizedPhone),
          state: { message_count: 0 },
        });
      }

      // Send WhatsApp welcome template (non-blocking)
      const welcomeTemplate = body.welcome_template || 'karnaf_welcome';
      sendTemplate(normalizedPhone, welcomeTemplate, 'he', [
        { type: 'text', text: fullName || 'שלום' },
      ])
        .then((r) => {
          if (!r.ok) console.warn('[lead-intake] WhatsApp template failed:', r.error);
          else console.log('[lead-intake] Welcome sent to', normalizedPhone);
        })
        .catch((e) => console.warn('[lead-intake] WhatsApp template error:', e));
    }

    // ── Send Instagram DM reply if this is a messenger/IG source without phone ──
    if (!normalizedPhone && fbIg && externalId && result.action === 'created') {
      sendInstagramMessage(
        externalId,
        'היי! תודה שפנית אלינו 😊 נשמח לדבר איתך. מה מספר הטלפון שלך?',
      )
        .then((r) => {
          if (!r.ok) console.warn('[lead-intake] IG reply failed:', r.error);
          else console.log('[lead-intake] IG reply sent to', externalId);
        })
        .catch((e) => console.warn('[lead-intake] IG reply error:', e));
    }

    return successResponse({
      success: true,
      action: result.action,
      lead_id: result.lead_id,
    });
  } catch (error) {
    console.error('[lead-intake] Error:', error);
    return errorResponse('Internal server error', 500);
  }
});
