import { useState, useEffect, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";

interface LeadsBySource {
  source: string;
  count: number;
  percentage: number;
}

interface LeadsByStage {
  stage: string;
  count: number;
  percentage: number;
}

interface ConversionFunnel {
  stage: string;
  count: number;
  conversionRate: number;
}

interface TrendData {
  date: string;
  leads: number;
  conversions: number;
}

interface TeamPerformance {
  userId: string;
  userName: string;
  totalLeads: number;
  convertedLeads: number;
  conversionRate: number;
}

interface ReportsData {
  leadsBySource: LeadsBySource[];
  leadsByStage: LeadsByStage[];
  conversionFunnel: ConversionFunnel[];
  trends: TrendData[];
  teamPerformance: TeamPerformance[];
  totals: {
    totalLeads: number;
    totalConversions: number;
    overallConversionRate: number;
    avgLeadsPerDay: number;
  };
}

const stageOrder = [
  "new_lead",
  "contacted",
  "meeting_scheduled",
  "proposal_sent",
  "negotiation",
  "closed_won",
  "closed_lost",
];

const stageLabels: Record<string, string> = {
  new_lead: "ליד חדש",
  contacted: "נוצר קשר",
  meeting_scheduled: "נקבעה פגישה",
  proposal_sent: "נשלחה הצעה",
  negotiation: "משא ומתן",
  closed_won: "נסגר בהצלחה",
  closed_lost: "נסגר ללא הצלחה",
};

const sourceLabels: Record<string, string> = {
  instagram: "אינסטגרם",
  facebook: "פייסבוק",
  whatsapp: "וואטסאפ",
  website: "אתר",
  referral: "הפניות",
  manual: "ידני",
  phone: "טלפון",
};

export function useReports(dateRange: { start: Date; end: Date }) {
  const [data, setData] = useState<ReportsData | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchReports = useCallback(async () => {

    setLoading(true);
    try {
      const startISO = dateRange.start.toISOString();
      const endISO = dateRange.end.toISOString();

      // Fetch leads within date range
      const { data: leadsData, error: leadsError } = await supabase
        .from("leads")
        .select("id, source, stage, assigned_to, created_at")
        .gte("created_at", startISO)
        .lte("created_at", endISO);

      if (leadsError) throw leadsError;

      const leads = leadsData || [];
      const totalLeads = leads.length;

      // Calculate leads by source
      const sourceCount: Record<string, number> = {};
      leads.forEach(lead => {
        sourceCount[lead.source] = (sourceCount[lead.source] || 0) + 1;
      });

      const leadsBySource: LeadsBySource[] = Object.entries(sourceCount).map(([source, count]) => ({
        source: sourceLabels[source] || source,
        count,
        percentage: totalLeads > 0 ? Math.round((count / totalLeads) * 100) : 0,
      }));

      // Calculate leads by stage
      const stageCount: Record<string, number> = {};
      leads.forEach(lead => {
        stageCount[lead.stage] = (stageCount[lead.stage] || 0) + 1;
      });

      const leadsByStage: LeadsByStage[] = stageOrder.map(stage => ({
        stage: stageLabels[stage] || stage,
        count: stageCount[stage] || 0,
        percentage: totalLeads > 0 ? Math.round(((stageCount[stage] || 0) / totalLeads) * 100) : 0,
      }));

      // Calculate conversion funnel
      const stageOrderIndex = stageOrder.reduce((acc, stage, index) => {
        acc[stage] = index;
        return acc;
      }, {} as Record<string, number>);

      const conversionFunnel: ConversionFunnel[] = stageOrder.slice(0, 6).map((stage, index) => {
        const count = leads.filter(lead => stageOrderIndex[lead.stage] >= index).length;
        const prevCount = index === 0 ? totalLeads : conversionFunnel[index - 1]?.count || totalLeads;
        return {
          stage: stageLabels[stage] || stage,
          count,
          conversionRate: prevCount > 0 ? Math.round((count / prevCount) * 100) : 0,
        };
      });

      // Calculate trends (group by day)
      const trendMap: Record<string, { leads: number; conversions: number }> = {};
      leads.forEach(lead => {
        const date = new Date(lead.created_at).toISOString().split("T")[0];
        if (!trendMap[date]) {
          trendMap[date] = { leads: 0, conversions: 0 };
        }
        trendMap[date].leads++;
        if (lead.stage === "closed_won") {
          trendMap[date].conversions++;
        }
      });

      const trends: TrendData[] = Object.entries(trendMap)
        .sort(([a], [b]) => a.localeCompare(b))
        .map(([date, data]) => ({
          date,
          leads: data.leads,
          conversions: data.conversions,
        }));

      // Calculate team performance
      const teamMap: Record<string, { total: number; converted: number }> = {};
      leads.forEach(lead => {
        const userId = lead.assigned_to || "unassigned";
        if (!teamMap[userId]) {
          teamMap[userId] = { total: 0, converted: 0 };
        }
        teamMap[userId].total++;
        if (lead.stage === "closed_won") {
          teamMap[userId].converted++;
        }
      });

      // Fetch user names
      const userIds = Object.keys(teamMap).filter(id => id !== "unassigned");
      let userNameMap: Map<string, string> = new Map();
      
      if (userIds.length > 0) {
        const { data: profilesData } = await supabase
          .from("profiles")
          .select("id, full_name")
          .in("id", userIds);

        userNameMap = new Map(profilesData?.map(p => [p.id, p.full_name]) || []);
      }

      const teamPerformance: TeamPerformance[] = Object.entries(teamMap).map(([userId, data]) => ({
        userId,
        userName: userId === "unassigned" ? "לא משויך" : userNameMap.get(userId) || "משתמש לא ידוע",
        totalLeads: data.total,
        convertedLeads: data.converted,
        conversionRate: data.total > 0 ? Math.round((data.converted / data.total) * 100) : 0,
      }));

      // Calculate totals
      const totalConversions = leads.filter(l => l.stage === "closed_won").length;
      const daysDiff = Math.ceil((dateRange.end.getTime() - dateRange.start.getTime()) / (1000 * 60 * 60 * 24));

      setData({
        leadsBySource,
        leadsByStage,
        conversionFunnel,
        trends,
        teamPerformance,
        totals: {
          totalLeads,
          totalConversions,
          overallConversionRate: totalLeads > 0 ? Math.round((totalConversions / totalLeads) * 100) : 0,
          avgLeadsPerDay: daysDiff > 0 ? Math.round((totalLeads / daysDiff) * 10) / 10 : 0,
        },
      });
    } catch (error) {
      console.error("Error fetching reports:", error);
    } finally {
      setLoading(false);
    }
  }, [dateRange]);

  useEffect(() => {
    fetchReports();
  }, [fetchReports]);

  return {
    data,
    loading,
    refetch: fetchReports,
  };
}
