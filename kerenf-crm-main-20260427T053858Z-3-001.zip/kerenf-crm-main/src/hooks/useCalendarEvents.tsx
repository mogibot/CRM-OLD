import { useState, useEffect, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";

type CalendarEvent = Database["public"]["Tables"]["calendar_events"]["Row"];
type CalendarEventInsert = Database["public"]["Tables"]["calendar_events"]["Insert"];
type CalendarEventUpdate = Database["public"]["Tables"]["calendar_events"]["Update"];

export interface CalendarEventWithLead extends CalendarEvent {
  lead_name?: string | null;
}

export function useCalendarEvents() {
  const [events, setEvents] = useState<CalendarEventWithLead[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [viewMode, setViewMode] = useState<"month" | "week" | "day">("month");

  const fetchEvents = useCallback(async () => {

    setLoading(true);
    try {
      // Get events for the current month (with buffer)
      const startOfMonth = new Date(selectedDate.getFullYear(), selectedDate.getMonth(), 1);
      startOfMonth.setDate(startOfMonth.getDate() - 7);
      
      const endOfMonth = new Date(selectedDate.getFullYear(), selectedDate.getMonth() + 1, 0);
      endOfMonth.setDate(endOfMonth.getDate() + 7);

      const { data, error } = await supabase
        .from("calendar_events")
        .select("*")
        .gte("start_time", startOfMonth.toISOString())
        .lte("start_time", endOfMonth.toISOString())
        .order("start_time", { ascending: true });

      if (error) throw error;

      // Fetch lead names for events with lead_id
      if (data && data.length > 0) {
        const leadIds = data.filter(e => e.lead_id).map(e => e.lead_id!);
        
        if (leadIds.length > 0) {
          const { data: leadsData } = await supabase
            .from("leads")
            .select("id, full_name")
            .in("id", leadIds);

          const leadNameMap = new Map(leadsData?.map(l => [l.id, l.full_name]) || []);

          setEvents(data.map(event => ({
            ...event,
            lead_name: event.lead_id ? leadNameMap.get(event.lead_id) : null,
          })));
        } else {
          setEvents(data);
        }
      } else {
        setEvents([]);
      }
    } catch (error) {
      console.error("Error fetching calendar events:", error);
    } finally {
      setLoading(false);
    }
  }, [selectedDate]);

  useEffect(() => {
    fetchEvents();
  }, [fetchEvents]);

  const createEvent = async (eventData: Omit<CalendarEventInsert, "user_id">) => {
    try {
      // Get current user
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        throw new Error("לא מחובר למערכת");
      }

      const { data, error } = await supabase
        .from("calendar_events")
        .insert({
          ...eventData,
          user_id: user.id,
        })
        .select()
        .single();

      if (error) throw error;
      
      await fetchEvents();
      return data;
    } catch (error) {
      console.error("Error creating event:", error);
      throw error;
    }
  };

  const updateEvent = async (id: string, updates: CalendarEventUpdate) => {
    try {
      const { error } = await supabase
        .from("calendar_events")
        .update(updates)
        .eq("id", id);

      if (error) throw error;
      await fetchEvents();
    } catch (error) {
      console.error("Error updating event:", error);
      throw error;
    }
  };

  const deleteEvent = async (id: string) => {
    try {
      const { error } = await supabase
        .from("calendar_events")
        .delete()
        .eq("id", id);

      if (error) throw error;
      await fetchEvents();
    } catch (error) {
      console.error("Error deleting event:", error);
      throw error;
    }
  };

  // Get events for a specific day
  const getEventsForDate = (date: Date): CalendarEventWithLead[] => {
    const dateStr = date.toDateString();
    return events.filter(event => {
      const eventDate = new Date(event.start_time).toDateString();
      return eventDate === dateStr;
    });
  };

  // Get upcoming events
  const getUpcomingEvents = (limit = 5): CalendarEventWithLead[] => {
    const now = new Date();
    return events
      .filter(event => new Date(event.start_time) >= now)
      .slice(0, limit);
  };

  return {
    events,
    loading,
    selectedDate,
    setSelectedDate,
    viewMode,
    setViewMode,
    createEvent,
    updateEvent,
    deleteEvent,
    getEventsForDate,
    getUpcomingEvents,
    refetch: fetchEvents,
  };
}
