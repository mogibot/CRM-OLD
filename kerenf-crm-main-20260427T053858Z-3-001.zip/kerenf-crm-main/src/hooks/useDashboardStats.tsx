import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface DashboardStats {
  totalLeads: number;
  newLeadsToday: number;
  conversionRate: number;
  avgResponseTime: number;
  activeBotSessions: number;
  leadsBySource: { name: string; value: number; color: string }[];
  leadsByStage: { stage: string; count: number }[];
  previousPeriodComparison: {
    leadsChange: number;
    newLeadsChange: number;
    conversionChange: number;
    responseTimeChange: number;
  };
}

interface RecentLead {
  id: string;
  full_name: string;
  phone: string | null;
  source: string;
  stage: string;
  created_at: string;
  updated_at: string;
}

interface RecentActivity {
  id: string;
  activity_type: string;
  description: string | null;
  created_at: string;
  lead_id: string;
  lead_name?: string;
}

const sourceColors: Record<string, string> = {
  instagram: "hsl(340, 75%, 55%)",
  facebook: "hsl(220, 85%, 55%)",
  whatsapp: "hsl(142, 70%, 45%)",
  manychat: "hsl(210, 85%, 55%)",
  smoov: "hsl(270, 60%, 55%)",
  wix_site: "hsl(30, 45%, 65%)",
  email_list: "hsl(45, 80%, 50%)",
  referral: "hsl(190, 70%, 35%)",
  campaign: "hsl(300, 60%, 50%)",
  manual: "hsl(260, 60%, 55%)",
};

const sourceLabels: Record<string, string> = {
  instagram: "אינסטגרם",
  facebook: "פייסבוק",
  whatsapp: "וואטסאפ",
  manychat: "מאניצ'ט",
  smoov: "Smoov",
  wix_site: "אתר Wix",
  email_list: "רשימת מיילים",
  referral: "הפניות",
  campaign: "קמפיין",
  manual: "ידני",
};

export function useDashboardStats() {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [recentLeads, setRecentLeads] = useState<RecentLead[]>([]);
  const [recentActivities, setRecentActivities] = useState<RecentActivity[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    setLoading(true);
    try {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const todayISO = today.toISOString();

      const lastMonth = new Date();
      lastMonth.setMonth(lastMonth.getMonth() - 1);
      const lastMonthISO = lastMonth.toISOString();

      const twoMonthsAgo = new Date();
      twoMonthsAgo.setMonth(twoMonthsAgo.getMonth() - 2);
      const twoMonthsAgoISO = twoMonthsAgo.toISOString();

      // Fetch all data in parallel
      // Active bot sessions = sessions with activity in last 24h
      const oneDayAgo = new Date();
      oneDayAgo.setDate(oneDayAgo.getDate() - 1);
      const oneDayAgoISO = oneDayAgo.toISOString();

      const yesterday = new Date(today);
      yesterday.setDate(yesterday.getDate() - 1);
      const yesterdayISO = yesterday.toISOString();

      const [
        allLeadsResult,
        todayLeadsResult,
        yesterdayLeadsResult,
        lastMonthLeadsResult,
        previousMonthLeadsResult,
        closedLeadsResult,
        previousClosedResult,
        recentLeadsResult,
        activitiesResult,
        botSessionsResult,
      ] = await Promise.all([
        supabase.from("leads").select("id, source, stage", { count: "exact" }),
        supabase.from("leads").select("id", { count: "exact" }).gte("created_at", todayISO),
        supabase.from("leads").select("id", { count: "exact" }).gte("created_at", yesterdayISO).lt("created_at", todayISO),
        supabase.from("leads").select("id", { count: "exact" }).gte("created_at", lastMonthISO),
        supabase.from("leads").select("id", { count: "exact" }).gte("created_at", twoMonthsAgoISO).lt("created_at", lastMonthISO),
        supabase.from("leads").select("id", { count: "exact" }).eq("stage", "closed_won"),
        supabase.from("leads").select("id", { count: "exact" }).eq("stage", "closed_won").gte("created_at", twoMonthsAgoISO).lt("created_at", lastMonthISO),
        supabase.from("leads").select("id, full_name, phone, source, stage, created_at, updated_at").order("updated_at", { ascending: false }).limit(10),
        supabase.from("lead_activities").select("id, activity_type, description, created_at, lead_id").order("created_at", { ascending: false }).limit(20),
        supabase.from("bot_sessions").select("id", { count: "exact" }).gte("last_activity", oneDayAgoISO),
      ]);

      const totalLeads = allLeadsResult.count || 0;
      const newLeadsToday = todayLeadsResult.count || 0;
      const newLeadsYesterday = yesterdayLeadsResult.count || 0;
      const lastMonthLeads = lastMonthLeadsResult.count || 0;
      const previousMonthLeads = previousMonthLeadsResult.count || 0;
      const closedLeads = closedLeadsResult.count || 0;
      const previousClosedLeads = previousClosedResult.count || 0;
      const activeBotSessions = botSessionsResult.count || 0;

      const conversionRate = totalLeads > 0 ? (closedLeads / totalLeads) * 100 : 0;

      const sourceCount: Record<string, number> = {};
      allLeadsResult.data?.forEach((lead) => {
        sourceCount[lead.source] = (sourceCount[lead.source] || 0) + 1;
      });

      const leadsBySource = Object.entries(sourceCount).map(([source, count]) => ({
        name: sourceLabels[source] || source,
        value: Math.round((count / totalLeads) * 100) || 0,
        color: sourceColors[source] || "hsl(200, 50%, 50%)",
      }));

      const stageCount: Record<string, number> = {};
      allLeadsResult.data?.forEach((lead) => {
        stageCount[lead.stage] = (stageCount[lead.stage] || 0) + 1;
      });

      const leadsByStage = Object.entries(stageCount).map(([stage, count]) => ({
        stage,
        count,
      }));

      const leadsChange = previousMonthLeads > 0 
        ? Math.round(((lastMonthLeads - previousMonthLeads) / previousMonthLeads) * 100)
        : 0;

      const newLeadsChange = newLeadsYesterday > 0
        ? Math.round(((newLeadsToday - newLeadsYesterday) / newLeadsYesterday) * 100)
        : newLeadsToday > 0 ? 100 : 0;

      const previousConversionRate = previousMonthLeads > 0
        ? (previousClosedLeads / previousMonthLeads) * 100
        : 0;
      const conversionChange = Math.round((conversionRate - previousConversionRate) * 10) / 10;

      setStats({
        totalLeads,
        newLeadsToday,
        conversionRate: Math.round(conversionRate * 10) / 10,
        avgResponseTime: 0,
        activeBotSessions,
        leadsBySource,
        leadsByStage,
        previousPeriodComparison: {
          leadsChange,
          newLeadsChange,
          conversionChange,
          responseTimeChange: 0,
        },
      });

      setRecentLeads(recentLeadsResult.data || []);
      
      if (activitiesResult.data && activitiesResult.data.length > 0) {
        const leadIds = [...new Set(activitiesResult.data.map(a => a.lead_id))];
        const { data: leadsData } = await supabase
          .from("leads")
          .select("id, full_name")
          .in("id", leadIds);
        
        const leadNameMap = new Map(leadsData?.map(l => [l.id, l.full_name]) || []);
        
        setRecentActivities(activitiesResult.data.map(activity => ({
          ...activity,
          lead_name: leadNameMap.get(activity.lead_id) || "ליד לא ידוע",
        })));
      }

    } catch (error) {
      console.error("Error fetching dashboard data:", error);
    } finally {
      setLoading(false);
    }
  };

  // Fetch user name from profile
  const [userName, setUserName] = useState("משתמש");

  useEffect(() => {
    const fetchUserName = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        const { data: profile } = await supabase
          .from("profiles")
          .select("full_name")
          .eq("id", user.id)
          .maybeSingle();
        if (profile?.full_name) {
          setUserName(profile.full_name);
        }
      }
    };
    fetchUserName();
  }, []);

  // Realtime subscription for new leads
  useEffect(() => {
    const channel = supabase
      .channel('dashboard-leads-realtime')
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'leads' },
        (payload) => {
          toast.success(`ליד חדש התקבל: ${(payload.new as any).full_name}`, {
            description: `מקור: ${(payload.new as any).source}`,
          });
          fetchDashboardData();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  return {
    stats,
    recentLeads,
    recentActivities,
    loading,
    userName,
    refetch: fetchDashboardData,
  };
}
