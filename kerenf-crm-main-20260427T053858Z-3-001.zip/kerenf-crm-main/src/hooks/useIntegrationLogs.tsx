import { useState, useEffect, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";

interface IntegrationLog {
  id: string;
  source: string;
  status: string;
  request_data: Record<string, unknown> | null;
  response_data: Record<string, unknown> | null;
  error_message: string | null;
  lead_id: string | null;
  created_at: string;
}

interface IntegrationStats {
  source: string;
  total_count: number;
  success_count: number;
  last_received: string | null;
}

export function useIntegrationLogs() {
  const [logs, setLogs] = useState<IntegrationLog[]>([]);
  const [stats, setStats] = useState<IntegrationStats[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchLogs = useCallback(async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from("integration_logs")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(50);

      if (error) throw error;
      setLogs((data as IntegrationLog[]) || []);

      // Calculate stats per source
      const statsMap = new Map<string, IntegrationStats>();
      
      for (const log of (data as IntegrationLog[]) || []) {
        const existing = statsMap.get(log.source);
        if (existing) {
          existing.total_count++;
          if (log.status === "success") existing.success_count++;
          if (!existing.last_received || log.created_at > existing.last_received) {
            existing.last_received = log.created_at;
          }
        } else {
          statsMap.set(log.source, {
            source: log.source,
            total_count: 1,
            success_count: log.status === "success" ? 1 : 0,
            last_received: log.created_at,
          });
        }
      }

      setStats(Array.from(statsMap.values()));
    } catch (error) {
      console.error("Error fetching integration logs:", error);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchLogs();
  }, [fetchLogs]);

  const getLastLeadBySource = (source: string): IntegrationLog | undefined => {
    return logs.find(
      (log) => log.source === source && log.status === "success"
    );
  };

  const getSourceDisplayName = (source: string): string => {
    const names: Record<string, string> = {
      facebook: "Facebook",
      instagram: "Instagram",
      manychat: "ManyChat",
      smoov: "Smoov",
      whatsapp: "WhatsApp",
      website_form: "אתר / טפסים",
      csv_import: "ייבוא CSV",
      facebook_graph_api: "Facebook Graph API",
      email_parsed: "אימייל",
      generic: "API כללי",
    };
    return names[source] || source;
  };

  return {
    logs,
    stats,
    loading,
    fetchLogs,
    getLastLeadBySource,
    getSourceDisplayName,
  };
}
