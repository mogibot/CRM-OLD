import { useState, useMemo, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Database } from "@/integrations/supabase/types";

type Lead = Database["public"]["Tables"]["leads"]["Row"];
type LeadInsert = Database["public"]["Tables"]["leads"]["Insert"];
type LeadUpdate = Database["public"]["Tables"]["leads"]["Update"];
type LeadStage = Database["public"]["Enums"]["lead_stage"];
type LeadSource = Database["public"]["Enums"]["lead_source"];
type Profile = Database["public"]["Tables"]["profiles"]["Row"];

export interface LeadWithAssignee extends Lead {
  assignee_profile?: Profile | null;
}

export interface LeadFilters {
  stage: LeadStage | null;
  source: LeadSource | null;
  assignee: string | null;
  search: string;
}

async function fetchLeadsWithProfiles(): Promise<LeadWithAssignee[]> {
  const { data, error } = await supabase
    .from("leads")
    .select("*")
    .order("created_at", { ascending: false });

  if (error) throw error;

  const assigneeIds = [...new Set(data?.map((l) => l.assigned_to).filter(Boolean))];
  let profilesData: Profile[] = [];

  if (assigneeIds.length > 0) {
    const { data: fetched } = await supabase
      .from("profiles")
      .select("*")
      .in("id", assigneeIds);
    profilesData = fetched || [];
  }

  return (
    data?.map((lead) => ({
      ...lead,
      assignee_profile: profilesData.find((p) => p.id === lead.assigned_to) || null,
    })) || []
  );
}

export function useLeads() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [filters, setFilters] = useState<LeadFilters>({
    stage: null,
    source: null,
    assignee: null,
    search: "",
  });

  const { data: allLeads = [], isLoading: loading } = useQuery({
    queryKey: ["leads"],
    queryFn: fetchLeadsWithProfiles,
  });

  const { data: profiles = [] } = useQuery({
    queryKey: ["profiles"],
    queryFn: async () => {
      const { data } = await supabase.from("profiles").select("*");
      return data || [];
    },
    staleTime: 5 * 60 * 1000,
  });

  // Realtime subscription — invalidate React Query cache on changes
  useEffect(() => {
    const channel = supabase
      .channel("leads-rq-realtime")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "leads" },
        (payload) => {
          if (payload.eventType === "INSERT") {
            const newLead = payload.new as Lead;
            toast({
              title: "ליד חדש התקבל!",
              description: `${newLead.full_name} ${newLead.source ? `(${newLead.source})` : ""}`,
            });
          }
          queryClient.invalidateQueries({ queryKey: ["leads"] });
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [queryClient, toast]);

  const createMutation = useMutation({
    mutationFn: async (leadData: LeadInsert) => {
      const { data, error } = await supabase
        .from("leads")
        .insert(leadData)
        .select()
        .single();
      if (error) throw error;
      return data;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["leads"] });
      toast({ title: "ליד נוצר בהצלחה", description: `${data.full_name} נוסף למערכת` });
    },
    onError: (error: any) => {
      toast({ title: "שגיאה ביצירת ליד", description: error.message, variant: "destructive" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: string; updates: LeadUpdate }) => {
      const { error } = await supabase.from("leads").update(updates).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["leads"] });
      toast({ title: "ליד עודכן בהצלחה" });
    },
    onError: (error: any) => {
      toast({ title: "שגיאה בעדכון ליד", description: error.message, variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("leads").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["leads"] });
      toast({ title: "ליד נמחק בהצלחה" });
    },
    onError: (error: any) => {
      toast({ title: "שגיאה במחיקת ליד", description: error.message, variant: "destructive" });
    },
  });

  const filteredLeads = useMemo(() => {
    return allLeads.filter((lead) => {
      if (filters.stage && lead.stage !== filters.stage) return false;
      if (filters.source && lead.source !== filters.source) return false;
      if (filters.assignee && lead.assigned_to !== filters.assignee) return false;
      if (filters.search) {
        const search = filters.search.toLowerCase();
        return (
          lead.full_name.toLowerCase().includes(search) ||
          lead.phone?.toLowerCase().includes(search) ||
          lead.email?.toLowerCase().includes(search) ||
          lead.city?.toLowerCase().includes(search)
        );
      }
      return true;
    });
  }, [allLeads, filters]);

  const stageCounts = useMemo(() => {
    const counts: Record<string, number> = { all: allLeads.length };
    allLeads.forEach((lead) => {
      counts[lead.stage] = (counts[lead.stage] || 0) + 1;
    });
    return counts;
  }, [allLeads]);

  const createLead = async (leadData: LeadInsert) => {
    try {
      return await createMutation.mutateAsync(leadData);
    } catch {
      return null;
    }
  };

  const updateLead = async (id: string, updates: LeadUpdate) => {
    try {
      await updateMutation.mutateAsync({ id, updates });
      return true;
    } catch {
      return false;
    }
  };

  const deleteLead = async (id: string) => {
    try {
      await deleteMutation.mutateAsync(id);
      return true;
    } catch {
      return false;
    }
  };

  return {
    leads: filteredLeads,
    allLeads,
    profiles,
    loading,
    filters,
    setFilters,
    stageCounts,
    createLead,
    updateLead,
    deleteLead,
    refetch: () => queryClient.invalidateQueries({ queryKey: ["leads"] }),
  };
}
