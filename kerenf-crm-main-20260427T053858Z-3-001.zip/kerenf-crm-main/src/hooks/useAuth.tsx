import { useState, useEffect, createContext, useContext, ReactNode } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

type AppRole = 'admin' | 'manager' | 'investor_guide';

interface Profile {
  id: string;
  full_name: string;
  avatar_url: string | null;
  phone: string | null;
}

interface AuthContextType {
  user: User | null;
  session: Session | null;
  profile: Profile | null;
  role: AppRole | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<{ error: Error | null }>;
  signUp: (email: string, password: string, fullName: string) => Promise<{ error: Error | null }>;
  signOut: () => Promise<void>;
  updateProfile: (data: Partial<Profile>) => Promise<{ error: Error | null }>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [role, setRole] = useState<AppRole | null>(null);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    // Set up auth state listener FIRST
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (event, session) => {
        setSession(session);
        setUser(session?.user ?? null);
        
        // Defer fetching profile and role with setTimeout
        if (session?.user) {
          setTimeout(() => {
            fetchProfile(session.user.id);
            fetchRole(session.user.id);
          }, 0);
        } else {
          setProfile(null);
          setRole(null);
        }
      }
    );

    // THEN check for existing session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setUser(session?.user ?? null);
      
      if (session?.user) {
        fetchProfile(session.user.id);
        fetchRole(session.user.id);
      }
      setLoading(false);
    });

    return () => subscription.unsubscribe();
  }, []);

  const fetchProfile = async (userId: string) => {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .maybeSingle();
    
    if (data && !error) {
      setProfile(data as Profile);
    }
  };

  const fetchRole = async (userId: string) => {
    const { data, error } = await supabase
      .from('user_roles')
      .select('role')
      .eq('user_id', userId)
      .maybeSingle();
    
    if (data && !error) {
      setRole(data.role as AppRole);
    }
  };

  const signIn = async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (error) {
      let message = 'שגיאה בהתחברות';
      if (error.message.includes('Invalid login credentials')) {
        message = 'אימייל או סיסמא שגויים';
      } else if (error.message.includes('Email not confirmed')) {
        message = 'אנא אשר את האימייל שלך';
      }
      toast({
        title: 'שגיאה',
        description: message,
        variant: 'destructive',
      });
      return { error: new Error(message) };
    }

    toast({
      title: 'ברוכים הבאים!',
      description: 'התחברת בהצלחה',
    });
    return { error: null };
  };

  const signUp = async (email: string, password: string, fullName: string) => {
    const redirectUrl = `${window.location.origin}/`;
    
    const { error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        emailRedirectTo: redirectUrl,
        data: {
          full_name: fullName,
        },
      },
    });

    if (error) {
      let message = 'שגיאה בהרשמה';
      if (error.message.includes('User already registered')) {
        message = 'משתמש עם אימייל זה כבר קיים';
      } else if (error.message.includes('Password')) {
        message = 'הסיסמא חייבת להכיל לפחות 6 תווים';
      } else if (error.message.includes('email')) {
        message = 'כתובת אימייל לא תקינה';
      }
      toast({
        title: 'שגיאה',
        description: message,
        variant: 'destructive',
      });
      return { error: new Error(message) };
    }

    toast({
      title: 'נרשמת בהצלחה!',
      description: 'ברוכים הבאים לקרנף נדל״ן',
    });
    return { error: null };
  };

  const signOut = async () => {
    await supabase.auth.signOut();
    setUser(null);
    setSession(null);
    setProfile(null);
    setRole(null);
    toast({
      title: 'להתראות!',
      description: 'התנתקת בהצלחה',
    });
  };

  const updateProfile = async (data: Partial<Profile>) => {
    if (!user) return { error: new Error('לא מחובר') };

    const { error } = await supabase
      .from('profiles')
      .update(data)
      .eq('id', user.id);

    if (error) {
      toast({
        title: 'שגיאה',
        description: 'לא ניתן לעדכן את הפרופיל',
        variant: 'destructive',
      });
      return { error };
    }

    await fetchProfile(user.id);
    toast({
      title: 'עודכן!',
      description: 'הפרופיל עודכן בהצלחה',
    });
    return { error: null };
  };

  return (
    <AuthContext.Provider value={{
      user,
      session,
      profile,
      role,
      loading,
      signIn,
      signUp,
      signOut,
      updateProfile,
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
