import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useEffect } from "react";
import { toast } from "sonner";

export interface Message {
  id: string;
  conversation_id: string;
  content: string;
  sender_type: string;
  created_at: string;
}

export function useMessages(leadId: string | null) {
  const queryClient = useQueryClient();

  const { data: messages = [], isLoading } = useQuery({
    queryKey: ["messages", leadId],
    queryFn: async () => {
      if (!leadId) return [];

      // First get conversations for this lead
      const { data: convos, error: convoError } = await supabase
        .from("conversations")
        .select("id")
        .eq("lead_id", leadId)
        .limit(1);

      if (convoError || !convos?.length) return [];

      const conversationId = convos[0].id;

      const { data, error } = await supabase
        .from("messages")
        .select("*")
        .eq("conversation_id", conversationId)
        .order("created_at", { ascending: true })
        .limit(50);

      if (error) throw error;
      return (data || []) as Message[];
    },
    enabled: !!leadId,
  });

  // Realtime subscription for new messages
  useEffect(() => {
    if (!leadId) return;

    const channel = supabase
      .channel(`messages-${leadId}`)
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "messages" },
        () => {
          queryClient.invalidateQueries({ queryKey: ["messages", leadId] });
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [leadId, queryClient]);

  const sendMessage = useMutation({
    mutationFn: async ({ phone, text }: { phone: string; text: string }) => {
      if (!leadId) throw new Error("No lead");

      // Get or create conversation
      let { data: convos } = await supabase
        .from("conversations")
        .select("id")
        .eq("lead_id", leadId)
        .eq("channel", "whatsapp")
        .limit(1);

      let conversationId = convos?.[0]?.id;

      if (!conversationId) {
        const { data: newConvo, error } = await supabase
          .from("conversations")
          .insert({ lead_id: leadId, channel: "whatsapp" })
          .select("id")
          .single();
        if (error) throw error;
        conversationId = newConvo.id;
      }

      // Save message to DB
      const { error: msgError } = await supabase.from("messages").insert({
        conversation_id: conversationId,
        sender_type: "agent",
        content: text,
      });
      if (msgError) throw msgError;

      // Send via WATI through edge function
      const { data: { session } } = await supabase.auth.getSession();
      const res = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/send-agent-message`,
        {
          method: "POST",
          headers: {
            Authorization: `Bearer ${session?.access_token}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ phone, text }),
        }
      );

      if (!res.ok) {
        const body = await res.json().catch(() => ({}));
        throw new Error(body.error || "שליחת ההודעה נכשלה");
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["messages", leadId] });
      toast.success("ההודעה נשלחה בהצלחה");
    },
    onError: (err: Error) => {
      toast.error(err.message || "שגיאה בשליחת ההודעה");
    },
  });

  return {
    messages,
    loading: isLoading,
    sendMessage: sendMessage.mutate,
    sending: sendMessage.isPending,
  };
}
