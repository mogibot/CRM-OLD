import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export interface BotConfig {
  system_prompt: string;
  transfer_threshold: number;
  active_hours: { start: string; end: string };
}

const DEFAULT_CONFIG: BotConfig = {
  system_prompt: `אתה נציג מכירות של קרנף נדל״ן, חברה ישראלית לייעוץ והדרכה בנדל״ן.

## המוצרים שלנו:
1. "הדרך לדירה" — תוכנית הכשרה דיגיטלית ל-4,000-5,000 ₪
   מתאים ל: רוכשי דירה ראשונה, אנשים שרוצים להבין שוק הנדל״ן
2. ליווי משקיעים פרימיום — 30,000 ₪, ל-6 חודשים
   מתאים ל: בעלי הון מ-500K+ ₪ שרוצים להשקיע בנדל״ן
3. וובינרים — חינמי, כניסה לפאנל

## הוראות שיחה:
- כתוב בעברית פשוטה ואנושית, לא מכירתית מדי
- שאל שאלה אחת בכל הודעה — לא יותר
- אחרי 3-4 הודעות, אתה יודע מספיק לסווג
- אם הלקוח שואל שאלה מורכבת על מימון/עסקה ספציפית — העבר לנציגה
- אם הלקוח מתלונן — העבר לנציגה מיד

## JSON Output (חייב להחזיר JSON בלבד):
{ "reply": "...", "score_delta": 0-30, "product_guess": "...",
  "should_transfer": false, "transfer_reason": "" }`,
  transfer_threshold: 80,
  active_hours: { start: "09:00", end: "21:00" },
};

export function useBotConfig() {
  const queryClient = useQueryClient();

  const { data: config, isLoading } = useQuery({
    queryKey: ["bot-config"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("bot_config")
        .select("key, value");

      if (error) return DEFAULT_CONFIG;

      const result = { ...DEFAULT_CONFIG };
      for (const row of data || []) {
        const val = row.value as Record<string, unknown>;
        if (row.key === "system_prompt" && val?.content) {
          result.system_prompt = val.content as string;
        }
        if (row.key === "transfer_threshold" && val?.score != null) {
          result.transfer_threshold = val.score as number;
        }
        if (row.key === "active_hours" && val?.start) {
          result.active_hours = val as { start: string; end: string };
        }
      }
      return result;
    },
  });

  const updateConfig = useMutation({
    mutationFn: async (updates: Partial<BotConfig>) => {
      const upserts = [];
      if (updates.system_prompt !== undefined) {
        upserts.push({
          key: "system_prompt",
          value: { content: updates.system_prompt },
          updated_at: new Date().toISOString(),
        });
      }
      if (updates.transfer_threshold !== undefined) {
        upserts.push({
          key: "transfer_threshold",
          value: { score: updates.transfer_threshold },
          updated_at: new Date().toISOString(),
        });
      }
      if (updates.active_hours !== undefined) {
        upserts.push({
          key: "active_hours",
          value: updates.active_hours,
          updated_at: new Date().toISOString(),
        });
      }

      for (const row of upserts) {
        const { error } = await supabase
          .from("bot_config")
          .upsert(row, { onConflict: "key" });
        if (error) throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["bot-config"] });
      toast.success("ההגדרות נשמרו בהצלחה");
    },
    onError: () => {
      toast.error("שגיאה בשמירת ההגדרות");
    },
  });

  return {
    config: config || DEFAULT_CONFIG,
    loading: isLoading,
    updateConfig: updateConfig.mutate,
    saving: updateConfig.isPending,
  };
}
