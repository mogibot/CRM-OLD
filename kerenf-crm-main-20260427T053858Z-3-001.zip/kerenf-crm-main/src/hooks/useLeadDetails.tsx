import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Database } from "@/integrations/supabase/types";

type LeadActivity = Database["public"]["Tables"]["lead_activities"]["Row"];
type LeadNote = Database["public"]["Tables"]["lead_notes"]["Row"];
type Task = Database["public"]["Tables"]["tasks"]["Row"];
type LeadDocument = Database["public"]["Tables"]["lead_documents"]["Row"];
type LeadTag = Database["public"]["Tables"]["lead_tags"]["Row"];
type Profile = Database["public"]["Tables"]["profiles"]["Row"];

export interface LeadDetailsData {
  activities: (LeadActivity & { user_profile?: Profile | null })[];
  notes: (LeadNote & { user_profile?: Profile | null })[];
  tasks: (Task & { assignee_profile?: Profile | null })[];
  documents: LeadDocument[];
  tags: LeadTag[];
}

export function useLeadDetails(leadId: string | null) {
  const [data, setData] = useState<LeadDetailsData>({
    activities: [],
    notes: [],
    tasks: [],
    documents: [],
    tags: [],
  });
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const fetchDetails = async () => {
    if (!leadId) return;
    
    try {
      setLoading(true);

      // Fetch all data in parallel
      const [activitiesRes, notesRes, tasksRes, documentsRes, tagsRes] = await Promise.all([
        supabase
          .from("lead_activities")
          .select("*")
          .eq("lead_id", leadId)
          .order("created_at", { ascending: false }),
        supabase
          .from("lead_notes")
          .select("*")
          .eq("lead_id", leadId)
          .order("created_at", { ascending: false }),
        supabase
          .from("tasks")
          .select("*")
          .eq("lead_id", leadId)
          .order("due_date", { ascending: true }),
        supabase
          .from("lead_documents")
          .select("*")
          .eq("lead_id", leadId)
          .order("created_at", { ascending: false }),
        supabase
          .from("leads_tags")
          .select("tag_id")
          .eq("lead_id", leadId),
      ]);

      // Get tag details
      const tagIds = tagsRes.data?.map((t) => t.tag_id) || [];
      let tags: LeadTag[] = [];
      if (tagIds.length > 0) {
        const { data: tagData } = await supabase
          .from("lead_tags")
          .select("*")
          .in("id", tagIds);
        tags = tagData || [];
      }

      // Get user profiles for activities and notes
      const userIds = [
        ...new Set([
          ...(activitiesRes.data?.map((a) => a.user_id).filter(Boolean) || []),
          ...(notesRes.data?.map((n) => n.user_id).filter(Boolean) || []),
          ...(tasksRes.data?.map((t) => t.assigned_to).filter(Boolean) || []),
        ]),
      ];

      let profiles: Profile[] = [];
      if (userIds.length > 0) {
        const { data: profileData } = await supabase
          .from("profiles")
          .select("*")
          .in("id", userIds);
        profiles = profileData || [];
      }

      setData({
        activities: (activitiesRes.data || []).map((a) => ({
          ...a,
          user_profile: profiles.find((p) => p.id === a.user_id) || null,
        })),
        notes: (notesRes.data || []).map((n) => ({
          ...n,
          user_profile: profiles.find((p) => p.id === n.user_id) || null,
        })),
        tasks: (tasksRes.data || []).map((t) => ({
          ...t,
          assignee_profile: profiles.find((p) => p.id === t.assigned_to) || null,
        })),
        documents: documentsRes.data || [],
        tags,
      });
    } catch (error: any) {
      toast({
        title: "שגיאה בטעינת פרטי ליד",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDetails();
  }, [leadId]);

  const addNote = async (content: string) => {
    if (!leadId) return false;

    try {
      const { data: userData } = await supabase.auth.getUser();
      
      const { error } = await supabase.from("lead_notes").insert({
        lead_id: leadId,
        content,
        user_id: userData.user?.id,
      });

      if (error) throw error;

      toast({ title: "הערה נוספה בהצלחה" });
      await fetchDetails();
      return true;
    } catch (error: any) {
      toast({
        title: "שגיאה בהוספת הערה",
        description: error.message,
        variant: "destructive",
      });
      return false;
    }
  };

  const addActivity = async (activityType: Database["public"]["Enums"]["activity_type"], description?: string) => {
    if (!leadId) return false;

    try {
      const { data: userData } = await supabase.auth.getUser();

      const { error } = await supabase.from("lead_activities").insert({
        lead_id: leadId,
        activity_type: activityType,
        description,
        user_id: userData.user?.id,
      });

      if (error) throw error;

      await fetchDetails();
      return true;
    } catch (error: any) {
      toast({
        title: "שגיאה בהוספת פעילות",
        description: error.message,
        variant: "destructive",
      });
      return false;
    }
  };

  const toggleTaskComplete = async (taskId: string, isCompleted: boolean) => {
    try {
      const { error } = await supabase
        .from("tasks")
        .update({ is_completed: isCompleted })
        .eq("id", taskId);

      if (error) throw error;

      await fetchDetails();
      return true;
    } catch (error: any) {
      toast({
        title: "שגיאה בעדכון משימה",
        description: error.message,
        variant: "destructive",
      });
      return false;
    }
  };

  return {
    ...data,
    loading,
    refetch: fetchDetails,
    addNote,
    addActivity,
    toggleTaskComplete,
  };
}
