import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useEffect } from "react";

export interface WorkQueueItem {
  id: string;
  lead_id: string;
  reason: string;
  priority: number;
  status: string;
  agent_id: string | null;
  created_at: string;
  resolved_at: string | null;
  lead: {
    full_name: string;
    phone: string;
    email: string | null;
    bot_score: number | null;
    bot_stage: string | null;
    product_interest: string | null;
    agent_notes: string | null;
    source: string | null;
  };
}

export function useWorkQueueCount(): number {
  const { data } = useQuery({
    queryKey: ["work-queue-count"],
    queryFn: async () => {
      const { count, error } = await supabase
        .from("work_queue")
        .select("*", { count: "exact", head: true })
        .eq("status", "pending");
      if (error) return 0;
      return count || 0;
    },
    refetchInterval: 30000,
  });
  return data || 0;
}

export function useWorkQueue() {
  const queryClient = useQueryClient();

  const { data: items = [], isLoading } = useQuery({
    queryKey: ["work-queue"],
    queryFn: async () => {
      // Fetch pending/in_progress items
      const { data, error } = await supabase
        .from("work_queue")
        .select(`
          *,
          lead:leads(full_name, phone, email, bot_score, bot_stage, product_interest, agent_notes, source)
        `)
        .in("status", ["pending", "in_progress"])
        .order("priority", { ascending: true })
        .order("created_at", { ascending: true });
      if (error) throw error;

      // Also reactivate expired snoozed items
      const now = new Date().toISOString();
      const { data: snoozed } = await supabase
        .from("work_queue")
        .select("id")
        .eq("status", "snoozed")
        .not("resolved_at", "is", null)
        .lte("resolved_at", now);

      if (snoozed && snoozed.length > 0) {
        const ids = snoozed.map((s) => s.id);
        await supabase
          .from("work_queue")
          .update({ status: "pending", resolved_at: null })
          .in("id", ids);
        // Refetch to include reactivated items
        const { data: refreshed, error: refreshError } = await supabase
          .from("work_queue")
          .select(`
            *,
            lead:leads(full_name, phone, email, bot_score, bot_stage, product_interest, agent_notes, source)
          `)
          .in("status", ["pending", "in_progress"])
          .order("priority", { ascending: true })
          .order("created_at", { ascending: true });
        if (refreshError) throw refreshError;
        return (refreshed || []) as unknown as WorkQueueItem[];
      }

      return (data || []) as unknown as WorkQueueItem[];
    },
    refetchInterval: 60000, // Check every minute for expired snoozes
  });

  // Realtime subscription
  useEffect(() => {
    const channel = supabase
      .channel("work-queue-changes")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "work_queue" },
        () => {
          queryClient.invalidateQueries({ queryKey: ["work-queue"] });
          queryClient.invalidateQueries({ queryKey: ["work-queue-count"] });
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [queryClient]);

  const markDone = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from("work_queue")
        .update({ status: "done", resolved_at: new Date().toISOString() })
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["work-queue"] });
      queryClient.invalidateQueries({ queryKey: ["work-queue-count"] });
    },
  });

  const snooze = useMutation({
    mutationFn: async ({ id, hours }: { id: string; hours: number }) => {
      const snoozedUntil = new Date();
      snoozedUntil.setHours(snoozedUntil.getHours() + hours);
      const { error } = await supabase
        .from("work_queue")
        .update({ status: "snoozed", resolved_at: snoozedUntil.toISOString() })
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["work-queue"] });
      queryClient.invalidateQueries({ queryKey: ["work-queue-count"] });
    },
  });

  const updateAgentNotes = useMutation({
    mutationFn: async ({ leadId, notes }: { leadId: string; notes: string }) => {
      const { error } = await supabase
        .from("leads")
        .update({ agent_notes: notes })
        .eq("id", leadId);
      if (error) throw error;
    },
  });

  return {
    items,
    loading: isLoading,
    markDone: markDone.mutate,
    snooze: snooze.mutate,
    updateAgentNotes: updateAgentNotes.mutate,
    refetch: () => queryClient.invalidateQueries({ queryKey: ["work-queue"] }),
  };
}
