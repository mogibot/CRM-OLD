import { useState, useEffect } from "react";
import { BotConfig } from "@/hooks/useBotConfig";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Save, Loader2 } from "lucide-react";

interface BotConfigFormProps {
  config: BotConfig;
  saving: boolean;
  onSave: (updates: Partial<BotConfig>) => void;
}

export function BotConfigForm({ config, saving, onSave }: BotConfigFormProps) {
  const [prompt, setPrompt] = useState(config.system_prompt);
  const [threshold, setThreshold] = useState(config.transfer_threshold);
  const [startHour, setStartHour] = useState(config.active_hours.start);
  const [endHour, setEndHour] = useState(config.active_hours.end);

  useEffect(() => {
    setPrompt(config.system_prompt);
    setThreshold(config.transfer_threshold);
    setStartHour(config.active_hours.start);
    setEndHour(config.active_hours.end);
  }, [config]);

  const handleSave = () => {
    onSave({
      system_prompt: prompt,
      transfer_threshold: threshold,
      active_hours: { start: startHour, end: endHour },
    });
  };

  return (
    <div className="space-y-6">
      {/* System Prompt */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">פרומפט מערכת</CardTitle>
        </CardHeader>
        <CardContent>
          <Textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            className="min-h-[300px] font-mono text-sm"
            dir="rtl"
          />
          <p className="text-xs text-muted-foreground mt-2">
            ההנחיות שהבוט מקבל בתחילת כל שיחה. שנה בזהירות.
          </p>
        </CardContent>
      </Card>

      {/* Transfer Threshold */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">סף העברה לנציגה</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">ציון מינימלי להעברה</span>
            <span className="font-bold text-lg">{threshold}</span>
          </div>
          <Slider
            value={[threshold]}
            onValueChange={([val]) => setThreshold(val)}
            min={50}
            max={100}
            step={5}
          />
          <p className="text-xs text-muted-foreground">
            ליד עם ציון מעל {threshold} יועבר אוטומטית לתור העבודה של הנציגה.
          </p>
        </CardContent>
      </Card>

      {/* Active Hours */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">שעות פעילות הבוט</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4">
            <div className="flex-1">
              <Label className="text-sm">מ-</Label>
              <Input
                type="time"
                value={startHour}
                onChange={(e) => setStartHour(e.target.value)}
                className="mt-1"
              />
            </div>
            <div className="flex-1">
              <Label className="text-sm">עד</Label>
              <Input
                type="time"
                value={endHour}
                onChange={(e) => setEndHour(e.target.value)}
                className="mt-1"
              />
            </div>
          </div>
          <p className="text-xs text-muted-foreground mt-2">
            מחוץ לשעות אלו הבוט לא יגיב לפניות חדשות.
          </p>
        </CardContent>
      </Card>

      {/* Save Button */}
      <Button onClick={handleSave} disabled={saving} className="w-full gap-2">
        {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
        שמור הגדרות
      </Button>
    </div>
  );
}
