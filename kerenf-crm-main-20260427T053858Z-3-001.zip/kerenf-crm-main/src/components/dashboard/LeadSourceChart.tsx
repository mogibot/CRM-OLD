import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from "recharts";

interface ChartData {
  name: string;
  value: number;
  color: string;
}

interface LeadSourceChartProps {
  data: ChartData[];
}

export function LeadSourceChart({ data }: LeadSourceChartProps) {
  if (data.length === 0) {
    return (
      <div className="bg-card rounded-2xl border p-6 shadow-kranaf-sm">
        <h3 className="text-lg font-bold mb-4">מקורות לידים</h3>
        <div className="h-64 flex items-center justify-center">
          <p className="text-muted-foreground">אין נתונים להצגה</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-card rounded-2xl border p-6 shadow-kranaf-sm">
      <h3 className="text-lg font-bold mb-4">מקורות לידים</h3>
      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              innerRadius={60}
              outerRadius={90}
              paddingAngle={4}
              dataKey="value"
            >
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.color} />
              ))}
            </Pie>
            <Tooltip
              contentStyle={{
                backgroundColor: "hsl(var(--card))",
                border: "1px solid hsl(var(--border))",
                borderRadius: "0.75rem",
                direction: "rtl",
              }}
              formatter={(value: number) => [`${value}%`, "אחוז"]}
            />
            <Legend
              layout="vertical"
              align="left"
              verticalAlign="middle"
              formatter={(value) => <span className="text-sm">{value}</span>}
            />
          </PieChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
