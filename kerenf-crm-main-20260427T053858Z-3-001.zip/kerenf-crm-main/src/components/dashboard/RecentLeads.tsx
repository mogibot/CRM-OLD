import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { MessageSquare, Phone, MoreVertical } from "lucide-react";
import { cn } from "@/lib/utils";
import { useNavigate } from "react-router-dom";
import { leadSourceLabels, leadStageLabels, stageColors } from "@/types/database";
import { formatDistanceToNow } from "date-fns";
import { he } from "date-fns/locale";

interface RecentLead {
  id: string;
  full_name: string;
  phone: string | null;
  source: string;
  stage: string;
  created_at: string;
  updated_at: string;
}

interface RecentLeadsProps {
  leads: RecentLead[];
}

export function RecentLeads({ leads }: RecentLeadsProps) {
  const navigate = useNavigate();

  const getTimeAgo = (date: string) => {
    return formatDistanceToNow(new Date(date), { addSuffix: false, locale: he });
  };

  if (leads.length === 0) {
    return (
      <div className="bg-card rounded-2xl border shadow-kranaf-sm p-8 text-center">
        <p className="text-muted-foreground">אין לידים עדיין</p>
        <Button variant="outline" className="mt-4" onClick={() => navigate("/leads")}>
          צור ליד ראשון
        </Button>
      </div>
    );
  }

  return (
    <div className="bg-card rounded-2xl border shadow-kranaf-sm">
      <div className="flex items-center justify-between p-6 border-b">
        <h3 className="text-lg font-bold">לידים אחרונים</h3>
        <Button variant="ghost" size="sm" onClick={() => navigate("/leads")}>
          צפה בהכל
        </Button>
      </div>
      <div className="divide-y">
        {leads.slice(0, 5).map((lead, index) => (
          <div
            key={lead.id}
            className="flex items-center justify-between p-4 hover:bg-muted/30 transition-colors animate-slide-up cursor-pointer"
            style={{ animationDelay: `${index * 100}ms` }}
            onClick={() => navigate("/leads")}
          >
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold">
                {lead.full_name.charAt(0)}
              </div>
              <div>
                <p className="font-medium">{lead.full_name}</p>
                <p className="text-sm text-muted-foreground hebrew-nums">{lead.phone || "ללא טלפון"}</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Badge variant="secondary" className="text-xs">
                {leadSourceLabels[lead.source as keyof typeof leadSourceLabels] || lead.source}
              </Badge>
              <Badge className={cn("text-xs text-primary-foreground", stageColors[lead.stage as keyof typeof stageColors] || "bg-secondary")}>
                {leadStageLabels[lead.stage as keyof typeof leadStageLabels] || lead.stage}
              </Badge>
              <span className="text-xs text-muted-foreground w-24">לפני {getTimeAgo(lead.updated_at || lead.created_at)}</span>
              <div className="flex items-center gap-1">
                <Button variant="ghost" size="icon" className="h-8 w-8" onClick={(e) => { e.stopPropagation(); if (lead.phone) window.open(`tel:${lead.phone}`); }}>
                  <Phone className="w-4 h-4" />
                </Button>
                <Button variant="ghost" size="icon" className="h-8 w-8" onClick={(e) => { e.stopPropagation(); if (lead.phone) window.open(`https://wa.me/${lead.phone.replace(/\D/g, '')}`); }}>
                  <MessageSquare className="w-4 h-4" />
                </Button>
                <Button variant="ghost" size="icon" className="h-8 w-8" onClick={(e) => { e.stopPropagation(); navigate(`/leads?id=${lead.id}`); }}>
                  <MoreVertical className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
