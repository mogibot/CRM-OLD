import { Phone, MessageSquare, Mail, Calendar, CheckCircle, Edit, Eye, LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";
import { activityTypeLabels } from "@/types/database";
import { format } from "date-fns";

interface RecentActivity {
  id: string;
  activity_type: string;
  description: string | null;
  created_at: string;
  lead_id: string;
  lead_name?: string;
}

interface ActivityTimelineProps {
  activities: RecentActivity[];
}

const activityTypeConfig: Record<string, { icon: LucideIcon; color: string }> = {
  call: { icon: Phone, color: "bg-kranaf-success" },
  meeting: { icon: Calendar, color: "bg-kranaf-warning" },
  email: { icon: Mail, color: "bg-kranaf-info" },
  whatsapp: { icon: MessageSquare, color: "bg-kranaf-success" },
  note: { icon: Edit, color: "bg-secondary" },
  status_change: { icon: CheckCircle, color: "bg-primary" },
  task_completed: { icon: CheckCircle, color: "bg-kranaf-success" },
  document_upload: { icon: Eye, color: "bg-kranaf-info" },
};

export function ActivityTimeline({ activities }: ActivityTimelineProps) {
  if (activities.length === 0) {
    return (
      <div className="bg-card rounded-2xl border p-6 shadow-kranaf-sm">
        <h3 className="text-lg font-bold mb-4">פעילות היום</h3>
        <p className="text-muted-foreground text-center py-4">אין פעילות להצגה</p>
      </div>
    );
  }

  return (
    <div className="bg-card rounded-2xl border p-6 shadow-kranaf-sm">
      <h3 className="text-lg font-bold mb-4">פעילות אחרונה</h3>
      <div className="space-y-4">
        {activities.slice(0, 5).map((activity, index) => {
          const config = activityTypeConfig[activity.activity_type] || { icon: CheckCircle, color: "bg-secondary" };
          const Icon = config.icon;
          const time = format(new Date(activity.created_at), "HH:mm");
          
          return (
            <div
              key={activity.id}
              className="flex gap-4 animate-slide-right"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className="flex flex-col items-center">
                <div
                  className={cn(
                    "w-10 h-10 rounded-full flex items-center justify-center text-primary-foreground",
                    config.color
                  )}
                >
                  <Icon className="w-5 h-5" />
                </div>
                {index < activities.length - 1 && (
                  <div className="w-0.5 flex-1 bg-border mt-2" />
                )}
              </div>
              <div className="flex-1 pb-4">
                <div className="flex items-center justify-between">
                  <p className="font-medium">
                    {activityTypeLabels[activity.activity_type as keyof typeof activityTypeLabels] || activity.activity_type}
                    {activity.lead_name && ` - ${activity.lead_name}`}
                  </p>
                  <span className="text-sm text-muted-foreground hebrew-nums">{time}</span>
                </div>
                {activity.description && (
                  <p className="text-sm text-muted-foreground">{activity.description}</p>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
