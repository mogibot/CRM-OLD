import { LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";

interface StatsCardProps {
  title: string;
  value: string | number;
  change?: {
    value: number;
    label: string;
  };
  icon: LucideIcon;
  variant?: "default" | "gold" | "teal" | "success";
}

export function StatsCard({ title, value, change, icon: Icon, variant = "default" }: StatsCardProps) {
  const variantStyles = {
    default: "bg-card",
    gold: "bg-gradient-to-br from-kranaf-gold/20 to-kranaf-gold-light/10 border-kranaf-gold/30",
    teal: "bg-gradient-to-br from-primary/10 to-primary/5 border-primary/20",
    success: "bg-gradient-to-br from-kranaf-success/10 to-kranaf-success/5 border-kranaf-success/20",
  };

  const iconStyles = {
    default: "bg-muted text-muted-foreground",
    gold: "bg-kranaf-gold/20 text-kranaf-gold",
    teal: "bg-primary/20 text-primary",
    success: "bg-kranaf-success/20 text-kranaf-success",
  };

  return (
    <div
      className={cn(
        "rounded-2xl border p-6 shadow-kranaf-sm hover:shadow-kranaf-md transition-all duration-300 hover-lift",
        variantStyles[variant]
      )}
    >
      <div className="flex items-start justify-between">
        <div className="space-y-2">
          <p className="text-sm text-muted-foreground font-medium">{title}</p>
          <p className="text-3xl font-bold hebrew-nums">{value}</p>
          {change && (
            <div className="flex items-center gap-1">
              <span
                className={cn(
                  "text-sm font-medium hebrew-nums",
                  change.value >= 0 ? "text-kranaf-success" : "text-destructive"
                )}
              >
                {change.value >= 0 ? "+" : ""}
                {change.value}%
              </span>
              <span className="text-xs text-muted-foreground">{change.label}</span>
            </div>
          )}
        </div>
        <div className={cn("w-12 h-12 rounded-xl flex items-center justify-center", iconStyles[variant])}>
          <Icon className="w-6 h-6" />
        </div>
      </div>
    </div>
  );
}
