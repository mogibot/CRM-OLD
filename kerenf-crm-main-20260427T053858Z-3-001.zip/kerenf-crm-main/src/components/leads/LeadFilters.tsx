import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Search, Filter, X } from "lucide-react";
import { cn } from "@/lib/utils";
import { LeadFilters as LeadFiltersType } from "@/hooks/useLeads";
import { leadStageLabels, leadSourceLabels, stageColors, LeadStage, LeadSource } from "@/types/database";
import { Database } from "@/integrations/supabase/types";
import { useIsMobile } from "@/hooks/use-mobile";
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area";

type Profile = Database["public"]["Tables"]["profiles"]["Row"];

interface LeadFiltersProps {
  filters: LeadFiltersType;
  onFiltersChange: (filters: LeadFiltersType) => void;
  stageCounts: Record<string, number>;
  profiles: Profile[];
}

export function LeadFilters({
  filters,
  onFiltersChange,
  stageCounts,
  profiles,
}: LeadFiltersProps) {
  const isMobile = useIsMobile();
  const hasActiveFilters = filters.source || filters.assignee;

  return (
    <div className="space-y-3 md:space-y-4">
      {/* Stage Filters - Horizontal scroll on mobile */}
      <ScrollArea className="w-full">
        <div className="flex gap-2 md:gap-3 pb-2">
          <Button
            variant={filters.stage === null ? "default" : "outline"}
            onClick={() => onFiltersChange({ ...filters, stage: null })}
            className={cn("whitespace-nowrap shrink-0", isMobile && "h-9 px-3 text-sm")}
          >
            הכל
            <Badge variant="secondary" className={cn("mr-2 hebrew-nums", isMobile && "text-xs")}>
              {stageCounts.all || 0}
            </Badge>
          </Button>
          {(Object.keys(leadStageLabels) as LeadStage[]).map((stage) => (
            <Button
              key={stage}
              variant={filters.stage === stage ? "default" : "outline"}
              onClick={() => onFiltersChange({ ...filters, stage })}
              className={cn("whitespace-nowrap shrink-0", isMobile && "h-9 px-3 text-sm")}
            >
              <span className={cn("w-2 h-2 rounded-full ml-2", stageColors[stage])} />
              {isMobile ? leadStageLabels[stage].slice(0, 10) : leadStageLabels[stage]}
              <Badge variant="secondary" className={cn("mr-2 hebrew-nums", isMobile && "text-xs")}>
                {stageCounts[stage] || 0}
              </Badge>
            </Button>
          ))}
        </div>
        <ScrollBar orientation="horizontal" />
      </ScrollArea>

      {/* Search & Filters */}
      <div className="flex gap-2 md:gap-4">
        <div className="relative flex-1">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder={isMobile ? "חיפוש..." : "חיפוש לפי שם, טלפון, אימייל..."}
            className="pr-10"
            value={filters.search}
            onChange={(e) => onFiltersChange({ ...filters, search: e.target.value })}
          />
        </div>

        <Popover>
          <PopoverTrigger asChild>
            <Button variant="outline" className={cn("gap-2", isMobile && "px-3")}>
              <Filter className="w-4 h-4" />
              {!isMobile && "סינון"}
              {hasActiveFilters && (
                <Badge variant="secondary" className={cn(isMobile ? "" : "mr-1")}>
                  {(filters.source ? 1 : 0) + (filters.assignee ? 1 : 0)}
                </Badge>
              )}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-80" align="end">
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium mb-2 block">מקור</label>
                <Select
                  value={filters.source || "all"}
                  onValueChange={(value) =>
                    onFiltersChange({
                      ...filters,
                      source: value === "all" ? null : (value as LeadSource),
                    })
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="כל המקורות" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">כל המקורות</SelectItem>
                    {(Object.entries(leadSourceLabels) as [LeadSource, string][]).map(([value, label]) => (
                      <SelectItem key={value} value={value}>
                        {label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm font-medium mb-2 block">אחראי</label>
                <Select
                  value={filters.assignee || "all"}
                  onValueChange={(value) =>
                    onFiltersChange({
                      ...filters,
                      assignee: value === "all" ? null : value,
                    })
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="כל האחראים" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">כל האחראים</SelectItem>
                    {profiles.map((profile) => (
                      <SelectItem key={profile.id} value={profile.id}>
                        {profile.full_name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {hasActiveFilters && (
                <Button
                  variant="ghost"
                  className="w-full gap-2"
                  onClick={() =>
                    onFiltersChange({
                      ...filters,
                      source: null,
                      assignee: null,
                    })
                  }
                >
                  <X className="w-4 h-4" />
                  נקה סינון
                </Button>
              )}
            </div>
          </PopoverContent>
        </Popover>
      </div>
    </div>
  );
}
