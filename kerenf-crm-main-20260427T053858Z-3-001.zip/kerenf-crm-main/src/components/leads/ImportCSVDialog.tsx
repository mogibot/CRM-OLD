import { useState, useCallback } from "react";
import { Upload, FileText, AlertCircle, CheckCircle2, X, Loader2 } from "lucide-react";
import * as XLSX from "xlsx";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";

type LeadSource = Database["public"]["Enums"]["lead_source"];

interface ImportCSVDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onImportComplete: () => void;
}

interface DataRow {
  [key: string]: string;
}

interface ColumnMapping {
  [csvColumn: string]: string;
}

// Supported file extensions
const SUPPORTED_EXTENSIONS = [".csv", ".xlsx", ".xls", ".tsv"];
const ACCEPTED_MIME_TYPES = ".csv,.xlsx,.xls,.tsv,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel,text/csv,text/tab-separated-values";

const LEAD_FIELDS = [
  { value: "full_name", label: "שם מלא" },
  { value: "email", label: "אימייל" },
  { value: "phone", label: "טלפון" },
  { value: "city", label: "עיר" },
  { value: "property_interest", label: "עניין בנכס" },
  { value: "notes", label: "הערות" },
  { value: "budget_min", label: "תקציב מינימלי" },
  { value: "budget_max", label: "תקציב מקסימלי" },
  { value: "skip", label: "דלג על עמודה" },
];

const AUTO_MAPPING: { [key: string]: string } = {
  "name": "full_name",
  "שם": "full_name",
  "full_name": "full_name",
  "שם מלא": "full_name",
  "email": "email",
  "אימייל": "email",
  "מייל": "email",
  "phone": "phone",
  "טלפון": "phone",
  "נייד": "phone",
  "mobile": "phone",
  "city": "city",
  "עיר": "city",
  "notes": "notes",
  "הערות": "notes",
  "הערה": "notes",
  "property": "property_interest",
  "נכס": "property_interest",
  "budget": "budget_max",
  "תקציב": "budget_max",
};

// Maximum file size: 10MB
const MAX_FILE_SIZE = 10 * 1024 * 1024;

export function ImportCSVDialog({
  open,
  onOpenChange,
  onImportComplete,
}: ImportCSVDialogProps) {
  const [file, setFile] = useState<File | null>(null);
  const [data, setData] = useState<DataRow[]>([]);
  const [headers, setHeaders] = useState<string[]>([]);
  const [columnMapping, setColumnMapping] = useState<ColumnMapping>({});
  const [importing, setImporting] = useState(false);
  const [progress, setProgress] = useState(0);
  const [importResult, setImportResult] = useState<{
    total: number;
    success: number;
    duplicates: number;
    errors: number;
  } | null>(null);
  const [step, setStep] = useState<"upload" | "mapping" | "importing" | "done">("upload");
  const [isDragging, setIsDragging] = useState(false);

  // Parse CSV/TSV text files
  const parseTextFile = (text: string, delimiter: string = ","): { headers: string[]; rows: DataRow[] } => {
    const lines = text.split(/\r?\n/).filter(line => line.trim());
    if (lines.length === 0) return { headers: [], rows: [] };

    // Parse headers
    const headerLine = lines[0];
    const parsedHeaders = parseDelimitedLine(headerLine, delimiter);

    // Parse rows
    const rows: DataRow[] = [];
    for (let i = 1; i < lines.length; i++) {
      const values = parseDelimitedLine(lines[i], delimiter);
      const row: DataRow = {};
      parsedHeaders.forEach((header, index) => {
        row[header] = values[index] || "";
      });
      rows.push(row);
    }

    return { headers: parsedHeaders, rows };
  };

  const parseDelimitedLine = (line: string, delimiter: string): string[] => {
    const result: string[] = [];
    let current = "";
    let inQuotes = false;

    for (let i = 0; i < line.length; i++) {
      const char = line[i];
      
      if (char === '"') {
        inQuotes = !inQuotes;
      } else if (char === delimiter && !inQuotes) {
        result.push(current.trim());
        current = "";
      } else {
        current += char;
      }
    }
    result.push(current.trim());
    
    return result;
  };

  // Parse Excel files (xlsx, xls)
  const parseExcelFile = async (file: File): Promise<{ headers: string[]; rows: DataRow[] }> => {
    const arrayBuffer = await file.arrayBuffer();
    const workbook = XLSX.read(arrayBuffer, { type: "array" });
    
    // Get first sheet
    const firstSheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[firstSheetName];
    
    // Convert to JSON array with headers
    const jsonData = XLSX.utils.sheet_to_json<string[]>(worksheet, { header: 1, defval: "" });
    
    if (jsonData.length === 0) {
      return { headers: [], rows: [] };
    }

    // First row is headers
    const headers = jsonData[0].map((h: unknown) => String(h || "").trim()).filter(Boolean);
    
    // Rest are data rows
    const rows: DataRow[] = [];
    for (let i = 1; i < jsonData.length; i++) {
      const rowData = jsonData[i];
      const row: DataRow = {};
      let hasData = false;
      
      headers.forEach((header, index) => {
        const value = String(rowData[index] || "").trim();
        row[header] = value;
        if (value) hasData = true;
      });
      
      // Only add rows that have at least some data
      if (hasData) {
        rows.push(row);
      }
    }

    return { headers, rows };
  };

  // Universal file parser
  const parseFile = async (file: File): Promise<{ headers: string[]; rows: DataRow[] }> => {
    const extension = file.name.split(".").pop()?.toLowerCase();

    if (extension === "xlsx" || extension === "xls") {
      return parseExcelFile(file);
    } else if (extension === "tsv") {
      const text = await file.text();
      return parseTextFile(text, "\t");
    } else {
      // Default: CSV
      const text = await file.text();
      return parseTextFile(text, ",");
    }
  };

  // Validate file
  const validateFile = (file: File): string | null => {
    // Check file size
    if (file.size > MAX_FILE_SIZE) {
      return "גודל הקובץ חורג מהמותר (מקסימום 10MB)";
    }

    // Check extension
    const extension = "." + (file.name.split(".").pop()?.toLowerCase() || "");
    if (!SUPPORTED_EXTENSIONS.includes(extension)) {
      return `סוג קובץ לא נתמך. פורמטים נתמכים: ${SUPPORTED_EXTENSIONS.join(", ")}`;
    }

    return null;
  };

  const handleFileChange = useCallback(async (selectedFile: File | null) => {
    if (!selectedFile) return;

    // Validate file
    const validationError = validateFile(selectedFile);
    if (validationError) {
      toast.error(validationError);
      return;
    }

    setFile(selectedFile);

    try {
      const { headers: parsedHeaders, rows } = await parseFile(selectedFile);
      
      if (parsedHeaders.length === 0) {
        toast.error("לא נמצאו כותרות בקובץ");
        return;
      }

      if (rows.length === 0) {
        toast.error("לא נמצאו שורות נתונים בקובץ");
        return;
      }

      setHeaders(parsedHeaders);
      setData(rows);

      // Auto-map columns
      const mapping: ColumnMapping = {};
      parsedHeaders.forEach((header) => {
        const normalizedHeader = header.toLowerCase().trim();
        if (AUTO_MAPPING[normalizedHeader]) {
          mapping[header] = AUTO_MAPPING[normalizedHeader];
        }
      });
      setColumnMapping(mapping);
      setStep("mapping");
      
      // Show warning for large files
      if (rows.length > 500) {
        toast.info(`נמצאו ${rows.length} שורות. ייבוא קבצים גדולים עשוי לקחת זמן.`);
      }
    } catch (error) {
      console.error("Error parsing file:", error);
      toast.error("שגיאה בקריאת הקובץ. נסה קובץ אחר או פורמט אחר.");
    }
  }, []);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const droppedFile = e.dataTransfer.files[0];
    handleFileChange(droppedFile);
  }, [handleFileChange]);

  const handleMappingChange = (csvColumn: string, leadField: string) => {
    setColumnMapping((prev) => ({
      ...prev,
      [csvColumn]: leadField,
    }));
  };

  const handleImport = async () => {
    if (!columnMapping.full_name && !Object.values(columnMapping).includes("full_name")) {
      const hasNameMapping = Object.entries(columnMapping).some(([_, value]) => value === "full_name");
      if (!hasNameMapping) {
        toast.error("חובה למפות עמודת שם מלא");
        return;
      }
    }

    setStep("importing");
    setImporting(true);
    setProgress(0);

    const result = { total: data.length, success: 0, duplicates: 0, errors: 0 };

    for (let i = 0; i < data.length; i++) {
      const row = data[i];
      
      // Build lead data from mapping
      const leadData: Record<string, string | number | null> = {
        source: "manual" as LeadSource,
        stage: "new_lead",
      };

      Object.entries(columnMapping).forEach(([csvCol, leadField]) => {
        if (leadField !== "skip" && row[csvCol]) {
          if (leadField === "budget_min" || leadField === "budget_max") {
            const numValue = parseFloat(row[csvCol].replace(/[^\d.-]/g, ""));
            leadData[leadField] = isNaN(numValue) ? null : numValue;
          } else {
            leadData[leadField] = row[csvCol];
          }
        }
      });

      // Skip rows without a name
      if (!leadData.full_name) {
        result.errors++;
        continue;
      }

      // Check for duplicates by phone or email
      if (leadData.phone || leadData.email) {
        const { data: existing } = await supabase
          .from("leads")
          .select("id")
          .or(`phone.eq.${leadData.phone || ""},email.eq.${leadData.email || ""}`)
          .maybeSingle();

        if (existing) {
          result.duplicates++;
          setProgress(Math.round(((i + 1) / data.length) * 100));
          continue;
        }
      }

      // Insert lead
      const { error } = await supabase.from("leads").insert({
        full_name: leadData.full_name as string,
        email: leadData.email as string | undefined,
        phone: leadData.phone as string | undefined,
        city: leadData.city as string | undefined,
        property_interest: leadData.property_interest as string | undefined,
        notes: leadData.notes as string | undefined,
        budget_min: leadData.budget_min as number | undefined,
        budget_max: leadData.budget_max as number | undefined,
        source: "manual",
        stage: "new_lead",
      });

      if (error) {
        console.error("Error inserting lead:", error);
        result.errors++;
      } else {
        result.success++;
      }

      setProgress(Math.round(((i + 1) / data.length) * 100));
    }

    setImportResult(result);
    setImporting(false);
    setStep("done");
    
    // Log the import
    await supabase.from("integration_logs").insert({
      source: "file_import",
      status: "success",
      request_data: { filename: file?.name, total_rows: data.length },
      response_data: result,
    });

    if (result.success > 0) {
      onImportComplete();
    }
  };

  const resetDialog = () => {
    setFile(null);
    setData([]);
    setHeaders([]);
    setColumnMapping({});
    setImporting(false);
    setProgress(0);
    setImportResult(null);
    setStep("upload");
  };

  const handleClose = (open: boolean) => {
    if (!open) {
      resetDialog();
    }
    onOpenChange(open);
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5" />
            ייבוא לידים מקובץ
          </DialogTitle>
          <DialogDescription>
            העלה קובץ Excel או CSV עם לידים קיימים להוספה למערכת
          </DialogDescription>
        </DialogHeader>

        {step === "upload" && (
          <div className="space-y-4">
            <div
              className={`border-2 border-dashed rounded-lg p-12 text-center transition-colors ${
                isDragging
                  ? "border-primary bg-primary/5"
                  : "border-muted-foreground/25 hover:border-primary/50"
              }`}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
            >
              <Upload className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
              <p className="text-lg font-medium mb-2">גרור קובץ לכאן</p>
              <p className="text-sm text-muted-foreground mb-4">או לחץ לבחירת קובץ</p>
              <input
                type="file"
                accept={ACCEPTED_MIME_TYPES}
                onChange={(e) => handleFileChange(e.target.files?.[0] || null)}
                className="hidden"
                id="file-upload"
              />
              <Button variant="outline" asChild>
                <label htmlFor="file-upload" className="cursor-pointer">
                  בחר קובץ
                </label>
              </Button>
            </div>
            
            <div className="flex flex-wrap gap-2 justify-center">
              <Badge variant="outline" className="text-xs">
                .xlsx
              </Badge>
              <Badge variant="outline" className="text-xs">
                .xls
              </Badge>
              <Badge variant="outline" className="text-xs">
                .csv
              </Badge>
              <Badge variant="outline" className="text-xs">
                .tsv
              </Badge>
            </div>
            <p className="text-xs text-center text-muted-foreground">
              מקסימום 10MB • השורה הראשונה צריכה להיות כותרות העמודות
            </p>
          </div>
        )}

        {step === "mapping" && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">{file?.name}</p>
                <p className="text-sm text-muted-foreground">
                  {data.length} שורות נמצאו
                </p>
              </div>
              <Button variant="ghost" size="sm" onClick={resetDialog}>
                <X className="w-4 h-4 ml-1" />
                בחר קובץ אחר
              </Button>
            </div>

            <div className="space-y-4">
              <Label>מיפוי עמודות</Label>
              <p className="text-sm text-muted-foreground">
                התאם את העמודות בקובץ לשדות במערכת
              </p>

              <div className="border rounded-lg overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>עמודה בקובץ</TableHead>
                      <TableHead>דוגמא</TableHead>
                      <TableHead>שדה במערכת</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {headers.map((header) => (
                      <TableRow key={header}>
                        <TableCell className="font-medium">{header}</TableCell>
                        <TableCell className="text-muted-foreground text-sm">
                          {data[0]?.[header]?.substring(0, 30) || "-"}
                        </TableCell>
                        <TableCell>
                          <Select
                            value={columnMapping[header] || ""}
                            onValueChange={(value) => handleMappingChange(header, value)}
                          >
                            <SelectTrigger className="w-40">
                              <SelectValue placeholder="בחר שדה" />
                            </SelectTrigger>
                            <SelectContent>
                              {LEAD_FIELDS.map((field) => (
                                <SelectItem key={field.value} value={field.value}>
                                  {field.label}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </div>

            <div className="flex justify-between">
              <Button variant="outline" onClick={resetDialog}>
                ביטול
              </Button>
              <Button onClick={handleImport}>
                ייבא {data.length} לידים
              </Button>
            </div>
          </div>
        )}

        {step === "importing" && (
          <div className="py-8 space-y-6 text-center">
            <Loader2 className="w-12 h-12 mx-auto animate-spin text-primary" />
            <div>
              <p className="text-lg font-medium mb-2">מייבא לידים...</p>
              <p className="text-sm text-muted-foreground">נא לא לסגור את החלון</p>
            </div>
            <Progress value={progress} className="h-2" />
            <p className="text-sm text-muted-foreground">{progress}%</p>
          </div>
        )}

        {step === "done" && importResult && (
          <div className="py-6 space-y-6">
            <div className="text-center">
              <CheckCircle2 className="w-16 h-16 mx-auto mb-4 text-green-500" />
              <p className="text-lg font-medium">הייבוא הושלם!</p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-4 text-center">
                <p className="text-2xl font-bold text-green-600">{importResult.success}</p>
                <p className="text-sm text-muted-foreground">לידים נוספו בהצלחה</p>
              </div>
              <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-lg p-4 text-center">
                <p className="text-2xl font-bold text-yellow-600">{importResult.duplicates}</p>
                <p className="text-sm text-muted-foreground">כפילויות דולגו</p>
              </div>
              {importResult.errors > 0 && (
                <div className="col-span-2 bg-red-500/10 border border-red-500/20 rounded-lg p-4 text-center">
                  <p className="text-2xl font-bold text-red-600">{importResult.errors}</p>
                  <p className="text-sm text-muted-foreground">שגיאות</p>
                </div>
              )}
            </div>

            <div className="flex justify-center gap-3">
              <Button variant="outline" onClick={resetDialog}>
                ייבא עוד
              </Button>
              <Button onClick={() => handleClose(false)}>
                סיום
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
