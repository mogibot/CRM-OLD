import { useState } from "react";
import { format, formatDistanceToNow } from "date-fns";
import { he } from "date-fns/locale";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Drawer,
  DrawerContent,
  DrawerHeader,
  DrawerTitle,
} from "@/components/ui/drawer";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Phone,
  Mail,
  MapPin,
  Calendar,
  MessageSquare,
  FileText,
  CheckSquare,
  History,
  Tag,
  Edit,
  Trash2,
  Send,
  User,
  DollarSign,
  Home,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { LeadWithAssignee } from "@/hooks/useLeads";
import { useLeadDetails } from "@/hooks/useLeadDetails";
import { leadStageLabels, leadSourceLabels, activityTypeLabels, stageColors, LeadStage } from "@/types/database";
import { useIsMobile } from "@/hooks/use-mobile";

interface LeadCardProps {
  lead: LeadWithAssignee | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onUpdateStage: (stage: LeadStage) => void;
  onEdit?: () => void;
  onDelete: () => void;
}

export function LeadCard({ lead, open, onOpenChange, onUpdateStage, onEdit, onDelete }: LeadCardProps) {
  const isMobile = useIsMobile();
  const [newNote, setNewNote] = useState("");
  const [isAddingNote, setIsAddingNote] = useState(false);
  const { activities, notes, tasks, documents, tags, loading, addNote, toggleTaskComplete } = useLeadDetails(lead?.id || null);

  if (!lead) return null;

  const handleAddNote = async () => {
    if (!newNote.trim()) return;
    setIsAddingNote(true);
    const success = await addNote(newNote);
    if (success) setNewNote("");
    setIsAddingNote(false);
  };

  const formatBudget = (min?: number | null, max?: number | null) => {
    if (!min && !max) return "לא צוין";
    const formatter = new Intl.NumberFormat("he-IL", { style: "currency", currency: "ILS", maximumFractionDigits: 0 });
    if (min && max) return `${formatter.format(min)} - ${formatter.format(max)}`;
    if (min) return `מ-${formatter.format(min)}`;
    return `עד ${formatter.format(max!)}`;
  };

  const handleCallClick = () => {
    if (lead.phone) {
      window.open(`tel:${lead.phone}`, "_blank");
    }
  };

  const handleMessageClick = () => {
    if (lead.phone) {
      const cleanPhone = lead.phone.replace(/\D/g, "");
      const israelPhone = cleanPhone.startsWith("0") ? `972${cleanPhone.slice(1)}` : cleanPhone;
      window.open(`https://wa.me/${israelPhone}`, "_blank");
    }
  };

  // Content component shared between Dialog and Drawer
  const LeadContent = () => (
    <>
      {/* Header */}
      <div className={cn("border-b pb-4", isMobile && "px-4")}>
        <div className={cn("flex items-start justify-between gap-3", isMobile && "flex-col")}>
          <div className="flex items-center gap-3">
            <div className={cn(
              "rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold",
              isMobile ? "w-12 h-12 text-xl" : "w-16 h-16 text-2xl"
            )}>
              {lead.full_name.charAt(0)}
            </div>
            <div>
              <h2 className={cn("font-bold", isMobile ? "text-lg" : "text-2xl")}>{lead.full_name}</h2>
              <div className="flex items-center gap-2 mt-1 flex-wrap">
                <Badge className={cn("text-primary-foreground", stageColors[lead.stage])}>
                  {leadStageLabels[lead.stage]}
                </Badge>
                <Badge variant="outline">{leadSourceLabels[lead.source]}</Badge>
                {lead.score && (
                  <Badge variant="secondary" className="hebrew-nums">
                    ציון: {lead.score}
                  </Badge>
                )}
              </div>
            </div>
          </div>
          <div className={cn("flex items-center gap-2", isMobile && "w-full justify-between mt-3")}>
            <Select value={lead.stage} onValueChange={(value) => onUpdateStage(value as LeadStage)}>
              <SelectTrigger className={cn(isMobile ? "flex-1" : "w-40")}>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {(Object.entries(leadStageLabels) as [LeadStage, string][]).map(([value, label]) => (
                  <SelectItem key={value} value={value}>{label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            {!isMobile && (
              <>
                <Button variant="ghost" size="icon" onClick={onEdit}>
                  <Edit className="w-4 h-4" />
                </Button>
                <Button variant="ghost" size="icon" className="text-destructive" onClick={onDelete}>
                  <Trash2 className="w-4 h-4" />
                </Button>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Body */}
      <div className={cn("flex-1 overflow-y-auto", isMobile ? "px-4" : "")}>
        <div className={cn("py-4", isMobile ? "space-y-4" : "grid grid-cols-3 gap-6")}>
          {/* Lead Info Column */}
          <div className={cn(isMobile ? "" : "col-span-1", "space-y-4")}>
            {/* Quick Actions - Mobile prominent */}
            {isMobile && (
              <div className="flex gap-2">
                <Button variant="default" className="flex-1 h-12 gap-2" onClick={handleCallClick}>
                  <Phone className="w-5 h-5" />
                  התקשר
                </Button>
                <Button variant="secondary" className="flex-1 h-12 gap-2" onClick={handleMessageClick}>
                  <MessageSquare className="w-5 h-5" />
                  WhatsApp
                </Button>
              </div>
            )}

            <div className="bg-muted/50 rounded-xl p-4 space-y-3">
              <h3 className="font-semibold text-sm text-muted-foreground">פרטי קשר</h3>
              {lead.phone && (
                <div className="flex items-center gap-2">
                  <Phone className="w-4 h-4 text-muted-foreground" />
                  <span className="hebrew-nums">{lead.phone}</span>
                </div>
              )}
              {lead.email && (
                <div className="flex items-center gap-2">
                  <Mail className="w-4 h-4 text-muted-foreground" />
                  <span dir="ltr" className="text-sm truncate">{lead.email}</span>
                </div>
              )}
              {lead.city && (
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-muted-foreground" />
                  <span>{lead.city}</span>
                </div>
              )}
            </div>

            <div className="bg-muted/50 rounded-xl p-4 space-y-3">
              <h3 className="font-semibold text-sm text-muted-foreground">פרטי נכס</h3>
              <div className="flex items-center gap-2">
                <Home className="w-4 h-4 text-muted-foreground" />
                <span>{lead.property_interest || "לא צוין"}</span>
              </div>
              <div className="flex items-center gap-2">
                <DollarSign className="w-4 h-4 text-muted-foreground" />
                <span className="hebrew-nums">{formatBudget(lead.budget_min, lead.budget_max)}</span>
              </div>
            </div>

            {(lead as any).conversation_summary && (
              <div className="bg-blue-50 dark:bg-blue-950/30 rounded-xl p-4 space-y-2">
                <h3 className="font-semibold text-sm text-muted-foreground flex items-center gap-2">
                  <MessageSquare className="w-4 h-4" />
                  סיכום שיחה
                </h3>
                <p className="text-sm leading-relaxed">{(lead as any).conversation_summary}</p>
              </div>
            )}

            {!isMobile && (
              <>
                <div className="bg-muted/50 rounded-xl p-4 space-y-3">
                  <h3 className="font-semibold text-sm text-muted-foreground">מידע נוסף</h3>
                  <div className="flex items-center gap-2">
                    <User className="w-4 h-4 text-muted-foreground" />
                    <span>אחראי: {lead.assignee_profile?.full_name || "לא משויך"}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-muted-foreground" />
                    <span className="text-sm">
                      נוצר: {format(new Date(lead.created_at), "dd/MM/yyyy", { locale: he })}
                    </span>
                  </div>
                  {lead.last_contact_at && (
                    <div className="flex items-center gap-2">
                      <MessageSquare className="w-4 h-4 text-muted-foreground" />
                      <span className="text-sm">
                        קשר אחרון: {formatDistanceToNow(new Date(lead.last_contact_at), { locale: he, addSuffix: true })}
                      </span>
                    </div>
                  )}
                </div>

                {tags.length > 0 && (
                  <div className="bg-muted/50 rounded-xl p-4 space-y-2">
                    <h3 className="font-semibold text-sm text-muted-foreground flex items-center gap-2">
                      <Tag className="w-4 h-4" />
                      תגיות
                    </h3>
                    <div className="flex flex-wrap gap-1">
                      {tags.map((tag) => (
                        <Badge
                          key={tag.id}
                          style={{ backgroundColor: tag.color }}
                          className="text-primary-foreground"
                        >
                          {tag.name}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}

                {/* Quick Actions - Desktop */}
                <div className="flex gap-2">
                  <Button variant="outline" className="flex-1 gap-2" onClick={handleCallClick}>
                    <Phone className="w-4 h-4" />
                    התקשר
                  </Button>
                  <Button variant="outline" className="flex-1 gap-2" onClick={handleMessageClick}>
                    <MessageSquare className="w-4 h-4" />
                    הודעה
                  </Button>
                </div>
              </>
            )}
          </div>

          {/* Tabs Column */}
          <div className={cn(isMobile ? "" : "col-span-2")}>
            <Tabs defaultValue="timeline" className="w-full">
              <TabsList className={cn("w-full", isMobile ? "grid grid-cols-4 h-auto p-1" : "justify-start")}>
                <TabsTrigger value="timeline" className={cn("gap-1", isMobile && "flex-col py-2 px-1 text-xs")}>
                  <History className="w-4 h-4" />
                  {isMobile ? "ציר זמן" : "ציר זמן"}
                </TabsTrigger>
                <TabsTrigger value="notes" className={cn("gap-1", isMobile && "flex-col py-2 px-1 text-xs")}>
                  <FileText className="w-4 h-4" />
                  {isMobile ? `הערות` : `הערות (${notes.length})`}
                </TabsTrigger>
                <TabsTrigger value="tasks" className={cn("gap-1", isMobile && "flex-col py-2 px-1 text-xs")}>
                  <CheckSquare className="w-4 h-4" />
                  {isMobile ? `משימות` : `משימות (${tasks.length})`}
                </TabsTrigger>
                <TabsTrigger value="documents" className={cn("gap-1", isMobile && "flex-col py-2 px-1 text-xs")}>
                  <FileText className="w-4 h-4" />
                  {isMobile ? "מסמכים" : `מסמכים (${documents.length})`}
                </TabsTrigger>
              </TabsList>

              <TabsContent value="timeline" className={cn("mt-4 space-y-4", isMobile ? "max-h-[250px]" : "max-h-[400px]", "overflow-y-auto")}>
                {loading ? (
                  <div className="text-center py-8 text-muted-foreground">טוען...</div>
                ) : activities.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">אין פעילות עדיין</div>
                ) : (
                  activities.map((activity) => (
                    <div key={activity.id} className="flex gap-3 p-3 bg-muted/30 rounded-lg">
                      <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                        <History className="w-4 h-4 text-primary" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-medium">{activityTypeLabels[activity.activity_type]}</p>
                        {activity.description && (
                          <p className="text-sm text-muted-foreground truncate">{activity.description}</p>
                        )}
                        <p className="text-xs text-muted-foreground mt-1">
                          {activity.user_profile?.full_name || "מערכת"} •{" "}
                          {formatDistanceToNow(new Date(activity.created_at), { locale: he, addSuffix: true })}
                        </p>
                      </div>
                    </div>
                  ))
                )}
              </TabsContent>

              <TabsContent value="notes" className="mt-4 space-y-4">
                {/* Add Note */}
                <div className="flex gap-2">
                  <Textarea
                    placeholder="הוסף הערה..."
                    value={newNote}
                    onChange={(e) => setNewNote(e.target.value)}
                    className="flex-1 min-h-[60px]"
                  />
                  <Button
                    onClick={handleAddNote}
                    disabled={!newNote.trim() || isAddingNote}
                    className="self-end"
                  >
                    <Send className="w-4 h-4" />
                  </Button>
                </div>

                <div className={cn("space-y-3 overflow-y-auto", isMobile ? "max-h-[200px]" : "max-h-[350px]")}>
                  {notes.map((note) => (
                    <div key={note.id} className="p-3 bg-muted/30 rounded-lg">
                      <p className="text-sm">{note.content}</p>
                      <p className="text-xs text-muted-foreground mt-2">
                        {note.user_profile?.full_name || "משתמש"} •{" "}
                        {formatDistanceToNow(new Date(note.created_at), { locale: he, addSuffix: true })}
                      </p>
                    </div>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="tasks" className={cn("mt-4 space-y-3 overflow-y-auto", isMobile ? "max-h-[250px]" : "max-h-[400px]")}>
                {tasks.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">אין משימות</div>
                ) : (
                  tasks.map((task) => (
                    <div
                      key={task.id}
                      className={cn(
                        "flex items-start gap-3 p-3 rounded-lg border",
                        task.is_completed ? "bg-muted/30 opacity-60" : "bg-card"
                      )}
                    >
                      <Checkbox
                        checked={task.is_completed || false}
                        onCheckedChange={(checked) => toggleTaskComplete(task.id, !!checked)}
                      />
                      <div className="flex-1 min-w-0">
                        <p className={cn("font-medium", task.is_completed && "line-through")}>
                          {task.title}
                        </p>
                        {task.description && (
                          <p className="text-sm text-muted-foreground truncate">{task.description}</p>
                        )}
                        <div className="flex items-center gap-2 mt-1 text-xs text-muted-foreground flex-wrap">
                          {task.due_date && (
                            <span>עד: {format(new Date(task.due_date), "dd/MM/yyyy", { locale: he })}</span>
                          )}
                          {task.assignee_profile && <span>• {task.assignee_profile.full_name}</span>}
                        </div>
                      </div>
                      <Badge
                        variant={
                          task.priority === "high"
                            ? "destructive"
                            : task.priority === "medium"
                            ? "secondary"
                            : "outline"
                        }
                        className="shrink-0"
                      >
                        {task.priority === "high" ? "גבוה" : task.priority === "medium" ? "בינוני" : "נמוך"}
                      </Badge>
                    </div>
                  ))
                )}
              </TabsContent>

              <TabsContent value="documents" className={cn("mt-4 space-y-3 overflow-y-auto", isMobile ? "max-h-[250px]" : "max-h-[400px]")}>
                {documents.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">אין מסמכים</div>
                ) : (
                  documents.map((doc) => (
                    <div key={doc.id} className="flex items-center gap-3 p-3 bg-muted/30 rounded-lg">
                      <FileText className="w-8 h-8 text-muted-foreground shrink-0" />
                      <div className="flex-1 min-w-0">
                        <p className="font-medium truncate">{doc.file_name}</p>
                        <p className="text-xs text-muted-foreground">
                          {doc.file_type} • {format(new Date(doc.created_at), "dd/MM/yyyy", { locale: he })}
                        </p>
                      </div>
                      <Button variant="ghost" size="sm" asChild>
                        <a href={doc.file_url} target="_blank" rel="noopener noreferrer">
                          הורד
                        </a>
                      </Button>
                    </div>
                  ))
                )}
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </>
  );

  // Mobile: Use Drawer
  if (isMobile) {
    return (
      <Drawer open={open} onOpenChange={onOpenChange}>
        <DrawerContent className="max-h-[95vh]">
          <DrawerHeader className="sr-only">
            <DrawerTitle>{lead.full_name}</DrawerTitle>
          </DrawerHeader>
          <div className="overflow-y-auto flex-1">
            <LeadContent />
          </div>
        </DrawerContent>
      </Drawer>
    );
  }

  // Desktop: Use Dialog
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader className="sr-only">
          <DialogTitle>{lead.full_name}</DialogTitle>
        </DialogHeader>
        <LeadContent />
      </DialogContent>
    </Dialog>
  );
}
