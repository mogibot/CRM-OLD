import { formatDistanceToNow } from "date-fns";
import { he } from "date-fns/locale";
import { Phone, MessageSquare, Mail, MoreVertical } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";
import { LeadWithAssignee } from "@/hooks/useLeads";
import { leadStageLabels, leadSourceLabels, stageColors } from "@/types/database";
import { useIsMobile } from "@/hooks/use-mobile";

interface LeadsTableProps {
  leads: LeadWithAssignee[];
  loading: boolean;
  onLeadClick: (lead: LeadWithAssignee) => void;
  onCallClick: (lead: LeadWithAssignee) => void;
  onMessageClick: (lead: LeadWithAssignee) => void;
  onEmailClick: (lead: LeadWithAssignee) => void;
  onDeleteClick: (lead: LeadWithAssignee) => void;
  onEditClick?: (lead: LeadWithAssignee) => void;
}

// Mobile Card Component
function MobileLeadCard({
  lead,
  onLeadClick,
  onCallClick,
  onMessageClick,
}: {
  lead: LeadWithAssignee;
  onLeadClick: (lead: LeadWithAssignee) => void;
  onCallClick: (lead: LeadWithAssignee) => void;
  onMessageClick: (lead: LeadWithAssignee) => void;
}) {
  return (
    <Card
      className="cursor-pointer hover:shadow-md transition-shadow active:scale-[0.99]"
      onClick={() => onLeadClick(lead)}
    >
      <CardContent className="p-4">
        <div className="flex items-start justify-between gap-3 mb-3">
          <div className="flex items-center gap-3 flex-1 min-w-0">
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold shrink-0">
              {lead.full_name.charAt(0)}
            </div>
            <div className="min-w-0">
              <h3 className="font-semibold text-base truncate">{lead.full_name}</h3>
              <p className="text-sm text-muted-foreground truncate hebrew-nums">
                {lead.phone || "אין טלפון"}
              </p>
            </div>
          </div>
          <Badge className={cn("text-primary-foreground shrink-0 text-xs", stageColors[lead.stage])}>
            {leadStageLabels[lead.stage]}
          </Badge>
        </div>

        <div className="flex items-center gap-2 mb-3 flex-wrap">
          <Badge variant="secondary" className="text-xs">
            {leadSourceLabels[lead.source]}
          </Badge>
          {lead.city && (
            <span className="text-xs text-muted-foreground">{lead.city}</span>
          )}
          <span className="text-xs text-muted-foreground mr-auto">
            {formatDistanceToNow(new Date(lead.updated_at), {
              addSuffix: true,
              locale: he,
            })}
          </span>
        </div>

        {/* Score indicator */}
        {lead.score !== null && lead.score > 0 && (
          <div className="mb-3">
            <div className="flex items-center gap-2">
              <div className="w-full h-1.5 rounded-full bg-muted overflow-hidden">
                <div
                  className={cn(
                    "h-full rounded-full",
                    lead.score >= 80
                      ? "bg-kranaf-success"
                      : lead.score >= 50
                      ? "bg-kranaf-warning"
                      : "bg-destructive"
                  )}
                  style={{ width: `${lead.score}%` }}
                />
              </div>
              <span className="text-xs text-muted-foreground w-8 hebrew-nums">{lead.score}</span>
            </div>
          </div>
        )}

        {/* Quick actions */}
        <div className="flex items-center gap-2 pt-3 border-t border-border">
          <Button
            variant="default"
            size="sm"
            className="flex-1 h-11"
            onClick={(e) => {
              e.stopPropagation();
              onCallClick(lead);
            }}
          >
            <Phone className="h-4 w-4 ml-2" />
            התקשר
          </Button>
          <Button
            variant="secondary"
            size="sm"
            className="flex-1 h-11"
            onClick={(e) => {
              e.stopPropagation();
              onMessageClick(lead);
            }}
          >
            <MessageSquare className="h-4 w-4 ml-2" />
            WhatsApp
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

// Mobile Loading State
function MobileLoadingSkeleton() {
  return (
    <div className="space-y-3">
      {[1, 2, 3, 4].map((i) => (
        <Card key={i}>
          <CardContent className="p-4">
            <div className="flex items-center gap-3 mb-3">
              <Skeleton className="w-10 h-10 rounded-full" />
              <div className="flex-1">
                <Skeleton className="h-4 w-24 mb-1" />
                <Skeleton className="h-3 w-20" />
              </div>
              <Skeleton className="h-5 w-16" />
            </div>
            <div className="flex gap-2 mb-3">
              <Skeleton className="h-5 w-16" />
              <Skeleton className="h-4 w-20" />
            </div>
            <div className="flex gap-2 pt-3 border-t">
              <Skeleton className="h-11 flex-1" />
              <Skeleton className="h-11 flex-1" />
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

export function LeadsTable({
  leads,
  loading,
  onLeadClick,
  onCallClick,
  onMessageClick,
  onEmailClick,
  onDeleteClick,
  onEditClick,
}: LeadsTableProps) {
  const isMobile = useIsMobile();

  // Loading state
  if (loading) {
    if (isMobile) {
      return <MobileLoadingSkeleton />;
    }

    return (
      <div className="bg-card rounded-2xl border shadow-kranaf-sm overflow-hidden">
        <table className="w-full">
          <thead className="bg-muted/50">
            <tr>
              <th className="text-right p-4 font-medium text-muted-foreground">שם</th>
              <th className="text-right p-4 font-medium text-muted-foreground">טלפון</th>
              <th className="text-right p-4 font-medium text-muted-foreground">מקור</th>
              <th className="text-right p-4 font-medium text-muted-foreground">שלב</th>
              <th className="text-right p-4 font-medium text-muted-foreground">אחראי</th>
              <th className="text-right p-4 font-medium text-muted-foreground">ציון</th>
              <th className="text-right p-4 font-medium text-muted-foreground">עודכן</th>
              <th className="text-right p-4 font-medium text-muted-foreground">פעולות</th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {[...Array(5)].map((_, i) => (
              <tr key={i}>
                <td className="p-4">
                  <div className="flex items-center gap-3">
                    <Skeleton className="w-10 h-10 rounded-full" />
                    <div>
                      <Skeleton className="h-4 w-24 mb-1" />
                      <Skeleton className="h-3 w-32" />
                    </div>
                  </div>
                </td>
                <td className="p-4"><Skeleton className="h-4 w-24" /></td>
                <td className="p-4"><Skeleton className="h-6 w-16" /></td>
                <td className="p-4"><Skeleton className="h-6 w-20" /></td>
                <td className="p-4"><Skeleton className="h-4 w-20" /></td>
                <td className="p-4"><Skeleton className="h-4 w-12" /></td>
                <td className="p-4"><Skeleton className="h-4 w-24" /></td>
                <td className="p-4"><Skeleton className="h-8 w-32" /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  }

  // Empty state
  if (leads.length === 0) {
    return (
      <div className="bg-card rounded-2xl border shadow-kranaf-sm p-8 md:p-12 text-center">
        <p className="text-muted-foreground">לא נמצאו לידים</p>
      </div>
    );
  }

  // Mobile Card View
  if (isMobile) {
    return (
      <div className="space-y-3">
        {leads.map((lead) => (
          <MobileLeadCard
            key={lead.id}
            lead={lead}
            onLeadClick={onLeadClick}
            onCallClick={onCallClick}
            onMessageClick={onMessageClick}
          />
        ))}
      </div>
    );
  }

  // Desktop Table View
  return (
    <div className="bg-card rounded-2xl border shadow-kranaf-sm overflow-hidden">
      <table className="w-full">
        <thead className="bg-muted/50">
          <tr>
            <th className="text-right p-4 font-medium text-muted-foreground">שם</th>
            <th className="text-right p-4 font-medium text-muted-foreground">טלפון</th>
            <th className="text-right p-4 font-medium text-muted-foreground">מקור</th>
            <th className="text-right p-4 font-medium text-muted-foreground">שלב</th>
            <th className="text-right p-4 font-medium text-muted-foreground">אחראי</th>
            <th className="text-right p-4 font-medium text-muted-foreground">ציון</th>
            <th className="text-right p-4 font-medium text-muted-foreground">עודכן</th>
            <th className="text-right p-4 font-medium text-muted-foreground">פעולות</th>
          </tr>
        </thead>
        <tbody className="divide-y">
          {leads.map((lead, index) => (
            <tr
              key={lead.id}
              className="hover:bg-muted/30 transition-colors animate-slide-up cursor-pointer"
              style={{ animationDelay: `${index * 30}ms` }}
              onClick={() => onLeadClick(lead)}
            >
              <td className="p-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold">
                    {lead.full_name.charAt(0)}
                  </div>
                  <div>
                    <p className="font-medium">{lead.full_name}</p>
                    {lead.email && (
                      <p className="text-sm text-muted-foreground" dir="ltr">
                        {lead.email}
                      </p>
                    )}
                  </div>
                </div>
              </td>
              <td className="p-4 hebrew-nums">{lead.phone || "-"}</td>
              <td className="p-4">
                <Badge variant="secondary">{leadSourceLabels[lead.source]}</Badge>
              </td>
              <td className="p-4">
                <Badge className={cn("text-primary-foreground", stageColors[lead.stage])}>
                  {leadStageLabels[lead.stage]}
                </Badge>
              </td>
              <td className="p-4 text-sm">
                {lead.assignee_profile?.full_name || "-"}
              </td>
              <td className="p-4">
                <div className="flex items-center gap-2">
                  <div className="w-12 h-2 rounded-full bg-muted overflow-hidden">
                    <div
                      className={cn(
                        "h-full rounded-full",
                        (lead.score || 0) >= 80
                          ? "bg-kranaf-success"
                          : (lead.score || 0) >= 50
                          ? "bg-kranaf-warning"
                          : "bg-destructive"
                      )}
                      style={{ width: `${lead.score || 0}%` }}
                    />
                  </div>
                  <span className="text-sm hebrew-nums">{lead.score || 0}</span>
                </div>
              </td>
              <td className="p-4 text-sm text-muted-foreground">
                {formatDistanceToNow(new Date(lead.updated_at), { locale: he, addSuffix: true })}
              </td>
              <td className="p-4">
                <div className="flex items-center gap-1" onClick={(e) => e.stopPropagation()}>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8"
                    onClick={() => onCallClick(lead)}
                  >
                    <Phone className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8"
                    onClick={() => onMessageClick(lead)}
                  >
                    <MessageSquare className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8"
                    onClick={() => onEmailClick(lead)}
                  >
                    <Mail className="w-4 h-4" />
                  </Button>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <MoreVertical className="w-4 h-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => onLeadClick(lead)}>
                        צפה בכרטיס
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => onEditClick?.(lead)}>ערוך ליד</DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem
                        className="text-destructive"
                        onClick={() => onDeleteClick(lead)}
                      >
                        מחק ליד
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
