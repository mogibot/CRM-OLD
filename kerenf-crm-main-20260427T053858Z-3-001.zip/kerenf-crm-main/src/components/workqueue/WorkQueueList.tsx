import { WorkQueueItem } from "@/hooks/useWorkQueue";
import { WorkQueueCard } from "./WorkQueueCard";

interface WorkQueueListProps {
  items: WorkQueueItem[];
  selectedId: string | null;
  onSelect: (item: WorkQueueItem) => void;
}

export function WorkQueueList({ items, selectedId, onSelect }: WorkQueueListProps) {
  return (
    <div className="space-y-3">
      {items.map((item) => (
        <WorkQueueCard
          key={item.id}
          item={item}
          isSelected={item.id === selectedId}
          onClick={() => onSelect(item)}
        />
      ))}
    </div>
  );
}
