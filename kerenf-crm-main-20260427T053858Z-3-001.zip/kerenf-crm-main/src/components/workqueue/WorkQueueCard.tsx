import { WorkQueueItem } from "@/hooks/useWorkQueue";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Phone, Clock } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { he } from "date-fns/locale";

interface WorkQueueCardProps {
  item: WorkQueueItem;
  isSelected: boolean;
  onClick: () => void;
}

const reasonLabels: Record<string, string> = {
  hot_lead: "ליד חם 🔥",
  complaint: "תלונה ⚠️",
  complex_question: "שאלה מורכבת ❓",
  stalled: "תקוע ⏸️",
};

const productLabels: Record<string, string> = {
  derech_ladira: "הדרך לדירה",
  premium_coaching: "ליווי פרימיום",
  webinar: "וובינר",
  consulting: "ייעוץ",
  unknown: "לא ידוע",
};

export function WorkQueueCard({ item, isSelected, onClick }: WorkQueueCardProps) {
  const timeAgo = formatDistanceToNow(new Date(item.created_at), {
    addSuffix: true,
    locale: he,
  });

  return (
    <button
      onClick={onClick}
      className={cn(
        "w-full text-right p-4 rounded-xl border transition-all duration-200 hover:shadow-kranaf-sm",
        isSelected
          ? "border-primary bg-primary/5 shadow-kranaf-sm"
          : "border-border bg-card hover:border-primary/30"
      )}
    >
      <div className="flex items-start justify-between gap-2">
        <div className="flex-1 min-w-0">
          <p className="font-semibold truncate">{item.lead?.full_name || "ללא שם"}</p>
          <div className="flex items-center gap-1 text-sm text-muted-foreground mt-1">
            <Phone className="w-3.5 h-3.5" />
            <span dir="ltr">{item.lead?.phone || "—"}</span>
          </div>
        </div>
        <div className="flex flex-col items-end gap-1.5 shrink-0">
          {item.lead?.bot_score != null && (
            <Badge variant={item.lead.bot_score >= 80 ? "destructive" : "secondary"} className="text-xs">
              {item.lead.bot_score}
            </Badge>
          )}
        </div>
      </div>

      <div className="flex flex-wrap gap-1.5 mt-3">
        {item.reason && (
          <Badge variant="outline" className="text-xs">
            {reasonLabels[item.reason] || item.reason}
          </Badge>
        )}
        {item.lead?.product_interest && item.lead.product_interest !== "unknown" && (
          <Badge variant="outline" className="text-xs bg-kranaf-gold/10 text-kranaf-gold border-kranaf-gold/30">
            {productLabels[item.lead.product_interest] || item.lead.product_interest}
          </Badge>
        )}
      </div>

      <div className="flex items-center gap-1 text-xs text-muted-foreground mt-3">
        <Clock className="w-3 h-3" />
        <span>{timeAgo}</span>
      </div>
    </button>
  );
}
