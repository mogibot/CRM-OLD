import { useState } from "react";
import { WorkQueueItem } from "@/hooks/useWorkQueue";
import { useMessages } from "@/hooks/useMessages";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Phone, MessageCircle, CheckCircle, Clock, ExternalLink, Send, Loader2 } from "lucide-react";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

interface AgentPanelProps {
  item: WorkQueueItem;
  onMarkDone: (id: string) => void;
  onSnooze: (id: string, hours: number) => void;
  onUpdateNotes: (params: { leadId: string; notes: string }) => void;
}

export function AgentPanel({ item, onMarkDone, onSnooze, onUpdateNotes }: AgentPanelProps) {
  const { messages, loading: messagesLoading, sendMessage, sending } = useMessages(item.lead_id);
  const [notes, setNotes] = useState(item.lead?.agent_notes || "");
  const [replyText, setReplyText] = useState("");

  const waLink = item.lead?.phone
    ? `https://wa.me/${item.lead.phone.replace(/^0/, "972")}`
    : null;

  return (
    <div className="space-y-4">
      {/* Lead Info */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-start justify-between">
            <div>
              <CardTitle className="text-lg">{item.lead?.full_name || "ללא שם"}</CardTitle>
              <p className="text-sm text-muted-foreground mt-1" dir="ltr">
                {item.lead?.phone || "—"}
              </p>
              {item.lead?.email && (
                <p className="text-sm text-muted-foreground">{item.lead.email}</p>
              )}
            </div>
            <div className="flex gap-2">
              {waLink && (
                <Button variant="outline" size="sm" asChild>
                  <a href={waLink} target="_blank" rel="noopener noreferrer" className="gap-1.5">
                    <Phone className="w-4 h-4" />
                    WhatsApp
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </Button>
              )}
            </div>
          </div>
          <div className="flex flex-wrap gap-2 mt-2">
            {item.lead?.bot_score != null && (
              <Badge variant={item.lead.bot_score >= 80 ? "destructive" : "secondary"}>
                ציון: {item.lead.bot_score}
              </Badge>
            )}
            {item.lead?.bot_stage && (
              <Badge variant="outline">{item.lead.bot_stage}</Badge>
            )}
            {item.lead?.source && (
              <Badge variant="outline">{item.lead.source}</Badge>
            )}
          </div>
        </CardHeader>
      </Card>

      {/* Conversation History */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base flex items-center gap-2">
            <MessageCircle className="w-4 h-4" />
            היסטוריית שיחה
          </CardTitle>
        </CardHeader>
        <CardContent>
          {messagesLoading ? (
            <p className="text-sm text-muted-foreground">טוען...</p>
          ) : messages.length === 0 ? (
            <p className="text-sm text-muted-foreground">אין הודעות עדיין</p>
          ) : (
            <div className="space-y-3 max-h-80 overflow-y-auto">
              {messages.map((msg) => (
                <div
                  key={msg.id}
                  className={cn(
                    "rounded-lg px-3 py-2 text-sm max-w-[85%]",
                    msg.sender_type === "bot"
                      ? "bg-primary/10 mr-auto"
                      : msg.sender_type === "lead"
                      ? "bg-muted ml-auto"
                      : "bg-kranaf-gold/10 mr-auto border border-kranaf-gold/20"
                  )}
                >
                  <p className="text-xs font-medium text-muted-foreground mb-1">
                    {msg.sender_type === "bot" ? "🤖 בוט" : msg.sender_type === "lead" ? "👤 ליד" : "👩‍💼 נציגה"}
                  </p>
                  <p className="whitespace-pre-wrap">{msg.content}</p>
                </div>
              ))}
            </div>
          )}
          {/* Reply Input */}
          {item.lead?.phone && (
            <div className="flex gap-2 mt-3 pt-3 border-t">
              <Input
                value={replyText}
                onChange={(e) => setReplyText(e.target.value)}
                placeholder="כתוב הודעה..."
                disabled={sending}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.shiftKey && replyText.trim()) {
                    e.preventDefault();
                    sendMessage({ phone: item.lead!.phone, text: replyText.trim() });
                    setReplyText("");
                  }
                }}
              />
              <Button
                size="icon"
                disabled={!replyText.trim() || sending}
                onClick={() => {
                  if (replyText.trim()) {
                    sendMessage({ phone: item.lead!.phone, text: replyText.trim() });
                    setReplyText("");
                  }
                }}
              >
                {sending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Agent Notes */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base">הערות נציגה</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <Textarea
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="הוסף הערות לגבי הליד..."
            className="min-h-[80px]"
          />
          <Button
            variant="outline"
            size="sm"
            onClick={() => onUpdateNotes({ leadId: item.lead_id, notes })}
          >
            שמור הערות
          </Button>
        </CardContent>
      </Card>

      {/* Actions */}
      <div className="flex gap-3">
        <Button
          onClick={() => onMarkDone(item.id)}
          className="flex-1 gap-2"
        >
          <CheckCircle className="w-4 h-4" />
          סמן כטופל
        </Button>
        <DropdownMenu dir="rtl">
          <DropdownMenuTrigger asChild>
            <Button variant="outline" className="gap-2">
              <Clock className="w-4 h-4" />
              סנוז
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent>
            <DropdownMenuItem onClick={() => onSnooze(item.id, 1)}>שעה</DropdownMenuItem>
            <DropdownMenuItem onClick={() => onSnooze(item.id, 3)}>3 שעות</DropdownMenuItem>
            <DropdownMenuItem onClick={() => onSnooze(item.id, 24)}>מחר</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </div>
  );
}
