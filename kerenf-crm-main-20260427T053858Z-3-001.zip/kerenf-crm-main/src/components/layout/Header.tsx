import { useState } from "react";
import { Search, Plus, User, Menu, LogOut, Inbox } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useIsMobile } from "@/hooks/use-mobile";
import { useAuth } from "@/hooks/useAuth";
import { useWorkQueueCount } from "@/hooks/useWorkQueue";
import { useNavigate } from "react-router-dom";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface HeaderProps {
  onMenuClick?: () => void;
  showMenuButton?: boolean;
}

export function Header({ onMenuClick, showMenuButton }: HeaderProps) {
  const isMobile = useIsMobile();
  const { profile, role, signOut } = useAuth();
  const pendingCount = useWorkQueueCount();
  const navigate = useNavigate();

  const getRoleLabel = (role: string | null) => {
    switch (role) {
      case 'admin':
        return 'מנהל';
      case 'manager':
        return 'מנהל צוות';
      case 'investor_guide':
        return 'מדריך משקיעים';
      default:
        return 'משתמש';
    }
  };

  return (
    <header className="sticky top-0 z-30 bg-background/80 backdrop-blur-md border-b border-border">
      <div className="flex items-center justify-between h-14 md:h-16 px-3 md:px-6 gap-3">
        {/* Right side - Menu button (mobile) + Search */}
        <div className="flex items-center gap-3 flex-1">
          {showMenuButton && (
            <Button
              variant="ghost"
              size="icon"
              onClick={onMenuClick}
              className="shrink-0"
            >
              <Menu className="h-5 w-5" />
            </Button>
          )}

          {!isMobile && (
            <div className="relative w-full max-w-md">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="חיפוש לידים, לקוחות, משימות..."
                className="pr-10 bg-muted/50 border-0 focus:bg-card focus:ring-2 focus:ring-primary/20"
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    const q = (e.target as HTMLInputElement).value.trim();
                    if (q) navigate(`/leads?search=${encodeURIComponent(q)}`);
                  }
                }}
              />
            </div>
          )}
        </div>

        {/* Left side - Actions */}
        <div className="flex items-center gap-2 md:gap-3">
          {isMobile && (
            <Button variant="ghost" size="icon" className="shrink-0">
              <Search className="h-5 w-5" />
            </Button>
          )}

          {!isMobile && (
            <Button variant="gold" className="gap-2">
              <Plus className="w-4 h-4" />
              ליד חדש
            </Button>
          )}

          <Button
            variant="ghost"
            size="icon"
            className="relative shrink-0"
            onClick={() => navigate('/work-queue')}
          >
            <Inbox className="w-5 h-5" />
            {pendingCount > 0 && (
              <span className="absolute -top-1 -left-1 w-5 h-5 rounded-full bg-destructive text-destructive-foreground text-xs flex items-center justify-center font-bold">
                {pendingCount}
              </span>
            )}
          </Button>

          <DropdownMenu dir="rtl">
            <DropdownMenuTrigger asChild>
              <div className={`flex items-center gap-2 md:gap-3 cursor-pointer ${!isMobile ? 'mr-4 pr-4 border-r border-border' : ''}`}>
                {!isMobile && (
                  <div className="text-left">
                    <p className="text-sm font-medium">{profile?.full_name || 'משתמש'}</p>
                    <p className="text-xs text-muted-foreground">{getRoleLabel(role)}</p>
                  </div>
                )}
                <div className="w-9 h-9 md:w-10 md:h-10 rounded-xl bg-primary flex items-center justify-center">
                  <User className="w-4 h-4 md:w-5 md:h-5 text-primary-foreground" />
                </div>
              </div>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="w-48">
              <div className="px-2 py-1.5">
                <p className="text-sm font-medium">{profile?.full_name || 'משתמש'}</p>
                <p className="text-xs text-muted-foreground">{getRoleLabel(role)}</p>
              </div>
              <DropdownMenuSeparator />
              <DropdownMenuItem
                onClick={signOut}
                className="text-destructive focus:text-destructive cursor-pointer"
              >
                <LogOut className="w-4 h-4 ml-2" />
                התנתק
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  );
}
