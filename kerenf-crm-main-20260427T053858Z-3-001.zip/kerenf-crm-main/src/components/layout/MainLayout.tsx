import { ReactNode, useState } from "react";
import { Sidebar } from "./Sidebar";
import { MobileSidebar } from "./MobileSidebar";
import { Header } from "./Header";
import { useIsMobile } from "@/hooks/use-mobile";

interface MainLayoutProps {
  children: ReactNode;
}

export function MainLayout({ children }: MainLayoutProps) {
  const isMobile = useIsMobile();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <div className="min-h-screen bg-background" dir="rtl">
      {/* Desktop Sidebar */}
      {!isMobile && <Sidebar />}
      
      {/* Mobile Sidebar (Sheet) */}
      {isMobile && (
        <MobileSidebar 
          open={mobileMenuOpen} 
          onOpenChange={setMobileMenuOpen} 
        />
      )}

      <div className={isMobile ? "" : "mr-64 transition-all duration-300"}>
        <Header 
          onMenuClick={() => setMobileMenuOpen(true)} 
          showMenuButton={isMobile} 
        />
        <main className={`${isMobile ? "p-3" : "p-6"} animate-fade-in`}>
          {children}
        </main>
      </div>
    </div>
  );
}
