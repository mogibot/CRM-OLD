import { NavLink, useLocation } from "react-router-dom";
import { cn } from "@/lib/utils";
import {
  LayoutDashboard,
  Users,
  Inbox,
  Bot,
  Calendar,
  BarChart3,
  Settings,
  Building2,
} from "lucide-react";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { useWorkQueueCount } from "@/hooks/useWorkQueue";

const navigationItems = [
  { icon: LayoutDashboard, label: "לוח בקרה", path: "/" },
  { icon: Inbox, label: "תור עבודה", path: "/work-queue", hasBadge: true },
  { icon: Users, label: "לידים", path: "/leads" },
  { icon: Bot, label: "הגדרות בוט", path: "/bot-config" },
  { icon: BarChart3, label: "דוחות", path: "/reports" },
  { icon: Calendar, label: "יומן", path: "/calendar" },
  { icon: Settings, label: "הגדרות", path: "/settings" },
];

interface MobileSidebarProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function MobileSidebar({ open, onOpenChange }: MobileSidebarProps) {
  const location = useLocation();
  const pendingCount = useWorkQueueCount();

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="right" className="w-72 p-0 bg-sidebar text-sidebar-foreground">
        <SheetHeader className="p-4 border-b border-sidebar-border">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-sidebar-primary flex items-center justify-center">
              <Building2 className="w-6 h-6 text-sidebar-primary-foreground" />
            </div>
            <div>
              <SheetTitle className="font-bold text-lg text-sidebar-foreground">קרנף נדל״ן</SheetTitle>
              <p className="text-xs text-sidebar-foreground/70">CRM מערכת</p>
            </div>
          </div>
        </SheetHeader>

        <nav className="p-3 space-y-1">
          {navigationItems.map((item) => {
            const isActive = location.pathname === item.path;
            return (
              <NavLink
                key={item.path}
                to={item.path}
                onClick={() => onOpenChange(false)}
                className={cn(
                  "flex items-center gap-3 px-4 py-3.5 rounded-xl transition-all duration-200 relative",
                  isActive
                    ? "bg-sidebar-accent text-sidebar-accent-foreground shadow-kranaf-sm"
                    : "hover:bg-sidebar-accent/50 text-sidebar-foreground/80 hover:text-sidebar-foreground"
                )}
              >
                <item.icon
                  className={cn(
                    "w-5 h-5 transition-transform duration-200",
                    isActive && "text-sidebar-primary"
                  )}
                />
                <span className="font-medium text-base">{item.label}</span>
                {item.hasBadge && pendingCount > 0 && (
                  <span className="mr-auto flex items-center justify-center rounded-full bg-destructive text-destructive-foreground text-xs font-bold min-w-[20px] h-5 px-1">
                    {pendingCount}
                  </span>
                )}
                {isActive && !item.hasBadge && (
                  <div className="mr-auto w-1.5 h-1.5 rounded-full bg-sidebar-primary animate-pulse-slow" />
                )}
              </NavLink>
            );
          })}
        </nav>
      </SheetContent>
    </Sheet>
  );
}
