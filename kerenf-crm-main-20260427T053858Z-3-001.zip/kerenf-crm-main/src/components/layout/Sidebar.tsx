import { useState } from "react";
import { NavLink, useLocation } from "react-router-dom";
import { cn } from "@/lib/utils";
import {
  LayoutDashboard,
  Users,
  Inbox,
  Bot,
  Calendar,
  BarChart3,
  Settings,
  Building2,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";
import { useWorkQueueCount } from "@/hooks/useWorkQueue";

const navigationItems = [
  { icon: LayoutDashboard, label: "לוח בקרה", path: "/" },
  { icon: Inbox, label: "תור עבודה", path: "/work-queue", hasBadge: true },
  { icon: Users, label: "לידים", path: "/leads" },
  { icon: Bot, label: "הגדרות בוט", path: "/bot-config" },
  { icon: BarChart3, label: "דוחות", path: "/reports" },
  { icon: Calendar, label: "יומן", path: "/calendar" },
  { icon: Settings, label: "הגדרות", path: "/settings" },
];

export function Sidebar() {
  const [collapsed, setCollapsed] = useState(false);
  const location = useLocation();
  const pendingCount = useWorkQueueCount();

  return (
    <aside
      className={cn(
        "fixed right-0 top-0 z-40 h-screen bg-sidebar text-sidebar-foreground transition-all duration-300 flex flex-col",
        collapsed ? "w-20" : "w-64"
      )}
    >
      {/* Logo */}
      <div className="flex items-center justify-between p-4 border-b border-sidebar-border">
        <div className={cn("flex items-center gap-3", collapsed && "justify-center w-full")}>
          <div className="w-10 h-10 rounded-xl bg-sidebar-primary flex items-center justify-center">
            <Building2 className="w-6 h-6 text-sidebar-primary-foreground" />
          </div>
          {!collapsed && (
            <div className="animate-fade-in">
              <h1 className="font-bold text-lg">קרנף נדל״ן</h1>
              <p className="text-xs text-sidebar-foreground/70">CRM מערכת</p>
            </div>
          )}
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
        {navigationItems.map((item) => {
          const isActive = location.pathname === item.path;
          return (
            <NavLink
              key={item.path}
              to={item.path}
              className={cn(
                "flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 group relative",
                isActive
                  ? "bg-sidebar-accent text-sidebar-accent-foreground shadow-kranaf-sm"
                  : "hover:bg-sidebar-accent/50 text-sidebar-foreground/80 hover:text-sidebar-foreground",
                collapsed && "justify-center px-3"
              )}
            >
              <item.icon
                className={cn(
                  "w-5 h-5 transition-transform duration-200",
                  isActive && "text-sidebar-primary"
                )}
              />
              {!collapsed && (
                <span className="font-medium animate-fade-in">{item.label}</span>
              )}
              {item.hasBadge && pendingCount > 0 && (
                <span className={cn(
                  "absolute flex items-center justify-center rounded-full bg-destructive text-destructive-foreground text-xs font-bold min-w-[20px] h-5 px-1",
                  collapsed ? "top-1 left-1" : "mr-auto"
                )}>
                  {pendingCount}
                </span>
              )}
              {isActive && !collapsed && !item.hasBadge && (
                <div className="mr-auto w-1.5 h-1.5 rounded-full bg-sidebar-primary animate-pulse-slow" />
              )}
            </NavLink>
          );
        })}
      </nav>

      {/* Collapse Toggle */}
      <button
        onClick={() => setCollapsed(!collapsed)}
        className="absolute -left-3 top-20 w-6 h-6 rounded-full bg-sidebar-primary text-sidebar-primary-foreground flex items-center justify-center shadow-kranaf-md hover:scale-110 transition-transform"
      >
        {collapsed ? (
          <ChevronLeft className="w-4 h-4" />
        ) : (
          <ChevronRight className="w-4 h-4" />
        )}
      </button>
    </aside>
  );
}
