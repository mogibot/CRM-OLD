export type AppRole = 'admin' | 'manager' | 'investor_guide';

export type LeadStage = 
  | 'new_lead'
  | 'contacted'
  | 'follow_up'
  | 'info_sent'
  | 'meeting_scheduled'
  | 'evaluation'
  | 'closing'
  | 'closed_won'
  | 'closed_lost'
  | 'not_relevant';

export type LeadSource =
  | 'instagram'
  | 'facebook'
  | 'whatsapp'
  | 'manychat'
  | 'smoov'
  | 'wix_site'
  | 'email_list'
  | 'referral'
  | 'campaign'
  | 'manual';

export type MessageChannel = 'whatsapp' | 'instagram' | 'facebook' | 'email' | 'sms';

export type ActivityType = 
  | 'call'
  | 'message_sent'
  | 'message_received'
  | 'meeting'
  | 'note_added'
  | 'stage_changed'
  | 'tag_added'
  | 'document_uploaded'
  | 'task_created'
  | 'email_sent'
  | 'email_received';

export interface Profile {
  id: string;
  full_name: string;
  avatar_url: string | null;
  phone: string | null;
  created_at: string;
  updated_at: string;
}

export interface Lead {
  id: string;
  full_name: string;
  email: string | null;
  phone: string | null;
  source: LeadSource;
  stage: LeadStage;
  score: number;
  assigned_to: string | null;
  notes: string | null;
  city: string | null;
  budget_min: number | null;
  budget_max: number | null;
  property_interest: string | null;
  last_contact_at: string | null;
  next_follow_up_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface LeadTag {
  id: string;
  name: string;
  color: string;
  created_at: string;
}

export interface LeadNote {
  id: string;
  lead_id: string;
  user_id: string | null;
  content: string;
  created_at: string;
}

export interface LeadActivity {
  id: string;
  lead_id: string;
  user_id: string | null;
  activity_type: ActivityType;
  description: string | null;
  metadata: Record<string, unknown>;
  created_at: string;
}

export interface Conversation {
  id: string;
  lead_id: string;
  channel: MessageChannel;
  external_id: string | null;
  last_message_at: string | null;
  unread_count: number;
  created_at: string;
  updated_at: string;
}

export interface Message {
  id: string;
  conversation_id: string;
  sender_type: 'user' | 'lead' | 'system';
  sender_id: string | null;
  content: string;
  attachments: unknown[];
  is_read: boolean;
  created_at: string;
}

export interface Task {
  id: string;
  lead_id: string | null;
  assigned_to: string | null;
  created_by: string | null;
  title: string;
  description: string | null;
  due_date: string | null;
  is_completed: boolean;
  priority: 'low' | 'medium' | 'high' | 'urgent';
  created_at: string;
  updated_at: string;
}

export interface CalendarEvent {
  id: string;
  lead_id: string | null;
  user_id: string;
  title: string;
  description: string | null;
  start_time: string;
  end_time: string;
  location: string | null;
  google_event_id: string | null;
  created_at: string;
  updated_at: string;
}

export interface AIInsight {
  id: string;
  lead_id: string | null;
  insight_type: string;
  title: string;
  description: string;
  priority: 'low' | 'medium' | 'high';
  is_dismissed: boolean;
  action_taken: boolean;
  created_at: string;
}

export interface MessageTemplate {
  id: string;
  name: string;
  channel: MessageChannel;
  content: string;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

// Hebrew labels for enums
export const leadStageLabels: Record<LeadStage, string> = {
  new_lead: 'ליד חדש',
  contacted: 'נוצר קשר',
  follow_up: 'מעקב',
  info_sent: 'נשלח מידע',
  meeting_scheduled: 'נקבעה פגישה',
  evaluation: 'בהערכה',
  closing: 'בתהליך סגירה',
  closed_won: 'נסגר בהצלחה',
  closed_lost: 'נסגר ללא עסקה',
  not_relevant: 'לא רלוונטי',
};

export const leadSourceLabels: Record<LeadSource, string> = {
  instagram: 'אינסטגרם',
  facebook: 'פייסבוק',
  whatsapp: 'וואטסאפ',
  manychat: 'ManyChat',
  smoov: 'Smoov',
  wix_site: 'אתר Wix',
  email_list: 'רשימת דיוור',
  referral: 'הפניה',
  campaign: 'קמפיין',
  manual: 'ידני',
};

export const channelLabels: Record<MessageChannel, string> = {
  whatsapp: 'וואטסאפ',
  instagram: 'אינסטגרם',
  facebook: 'פייסבוק',
  email: 'אימייל',
  sms: 'SMS',
};

export const activityTypeLabels: Record<ActivityType, string> = {
  call: 'שיחה',
  message_sent: 'הודעה נשלחה',
  message_received: 'הודעה התקבלה',
  meeting: 'פגישה',
  note_added: 'הערה נוספה',
  stage_changed: 'שלב השתנה',
  tag_added: 'תגית נוספה',
  document_uploaded: 'מסמך הועלה',
  task_created: 'משימה נוצרה',
  email_sent: 'אימייל נשלח',
  email_received: 'אימייל התקבל',
};

export const priorityLabels: Record<string, string> = {
  low: 'נמוכה',
  medium: 'בינונית',
  high: 'גבוהה',
  urgent: 'דחוף',
};

export const roleLabels: Record<AppRole, string> = {
  admin: 'מנהל מערכת',
  manager: 'מנהל כללי',
  investor_guide: 'מלווה משקיעים',
};

export const stageColors: Record<LeadStage, string> = {
  new_lead: 'bg-blue-500',
  contacted: 'bg-cyan-500',
  follow_up: 'bg-yellow-500',
  info_sent: 'bg-purple-500',
  meeting_scheduled: 'bg-indigo-500',
  evaluation: 'bg-orange-500',
  closing: 'bg-pink-500',
  closed_won: 'bg-green-500',
  closed_lost: 'bg-red-500',
  not_relevant: 'bg-gray-500',
};
