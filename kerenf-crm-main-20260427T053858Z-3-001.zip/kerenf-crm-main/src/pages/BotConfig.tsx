import { useBotConfig } from "@/hooks/useBotConfig";
import { BotConfigForm } from "@/components/bot/BotConfigForm";
import { Loader2, Bot } from "lucide-react";

export default function BotConfig() {
  const { config, loading, updateConfig, saving } = useBotConfig();

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-4 max-w-3xl">
      <div>
        <div className="flex items-center gap-2">
          <Bot className="w-6 h-6 text-primary" />
          <h1 className="text-xl md:text-2xl font-bold">הגדרות בוט</h1>
        </div>
        <p className="text-sm text-muted-foreground mt-1">
          ניהול הפרומפט, סף ההעברה ושעות הפעילות של הבוט
        </p>
      </div>

      <BotConfigForm
        config={config}
        saving={saving}
        onSave={updateConfig}
      />
    </div>
  );
}
