import { useState, useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import { Download, Plus, Upload } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useLeads, LeadWithAssignee } from "@/hooks/useLeads";
import { LeadFilters } from "@/components/leads/LeadFilters";
import { LeadsTable } from "@/components/leads/LeadsTable";
import { CreateLeadDialog } from "@/components/leads/CreateLeadDialog";
import { LeadCard } from "@/components/leads/LeadCard";
import { ImportCSVDialog } from "@/components/leads/ImportCSVDialog";
import { EditLeadDialog } from "@/components/leads/EditLeadDialog";
import { Database } from "@/integrations/supabase/types";
import { useIsMobile } from "@/hooks/use-mobile";
import { leadStageLabels, leadSourceLabels } from "@/types/database";
import * as XLSX from "xlsx";

type LeadStage = Database["public"]["Enums"]["lead_stage"];

export default function Leads() {
  const isMobile = useIsMobile();
  const [searchParams] = useSearchParams();
  const {
    leads,
    profiles,
    loading,
    filters,
    setFilters,
    stageCounts,
    createLead,
    updateLead,
    deleteLead,
    refetch,
  } = useLeads();

  // Apply search param from URL (e.g. from header search)
  useEffect(() => {
    const q = searchParams.get('search');
    if (q && q !== filters.search) {
      setFilters((prev) => ({ ...prev, search: q }));
    }
  }, [searchParams]);

  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [importDialogOpen, setImportDialogOpen] = useState(false);
  const [selectedLead, setSelectedLead] = useState<LeadWithAssignee | null>(null);
  const [leadCardOpen, setLeadCardOpen] = useState(false);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [leadToEdit, setLeadToEdit] = useState<LeadWithAssignee | null>(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [leadToDelete, setLeadToDelete] = useState<LeadWithAssignee | null>(null);

  const handleLeadClick = (lead: LeadWithAssignee) => {
    setSelectedLead(lead);
    setLeadCardOpen(true);
  };

  const handleCallClick = (lead: LeadWithAssignee) => {
    if (lead.phone) {
      window.open(`tel:${lead.phone}`, "_blank");
    }
  };

  const handleMessageClick = (lead: LeadWithAssignee) => {
    if (lead.phone) {
      const cleanPhone = lead.phone.replace(/\D/g, "");
      const israelPhone = cleanPhone.startsWith("0") ? `972${cleanPhone.slice(1)}` : cleanPhone;
      window.open(`https://wa.me/${israelPhone}`, "_blank");
    }
  };

  const handleEmailClick = (lead: LeadWithAssignee) => {
    if (lead.email) {
      window.open(`mailto:${lead.email}`, "_blank");
    }
  };

  const handleEditClick = (lead: LeadWithAssignee) => {
    setLeadToEdit(lead);
    setEditDialogOpen(true);
  };

  const handleDeleteClick = (lead: LeadWithAssignee) => {
    setLeadToDelete(lead);
    setDeleteDialogOpen(true);
  };

  const confirmDelete = async () => {
    if (leadToDelete) {
      await deleteLead(leadToDelete.id);
      setDeleteDialogOpen(false);
      setLeadToDelete(null);
      if (selectedLead?.id === leadToDelete.id) {
        setLeadCardOpen(false);
        setSelectedLead(null);
      }
    }
  };

  const handleExport = () => {
    const rows = leads.map((lead) => ({
      "שם מלא": lead.full_name,
      "טלפון": lead.phone || "",
      "אימייל": lead.email || "",
      "עיר": lead.city || "",
      "מקור": leadSourceLabels[lead.source] || lead.source,
      "שלב": leadStageLabels[lead.stage] || lead.stage,
      "ציון": lead.score || 0,
      "ציון בוט": lead.bot_score || 0,
      "אחראי": lead.assignee_profile?.full_name || "",
      "נוצר בתאריך": new Date(lead.created_at).toLocaleDateString("he-IL"),
    }));
    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "לידים");
    XLSX.writeFile(wb, `leads_export_${new Date().toISOString().split("T")[0]}.xlsx`);
  };

  const handleUpdateStage = async (stage: LeadStage) => {
    if (selectedLead) {
      await updateLead(selectedLead.id, { stage });
      setSelectedLead({ ...selectedLead, stage });
    }
  };

  return (
    <div className="space-y-4 md:space-y-6">
      {/* Page Header */}
      <div className={`flex ${isMobile ? 'flex-col gap-3' : 'items-center justify-between'}`}>
        <div>
          <h1 className="text-xl md:text-2xl font-bold">ניהול לידים</h1>
          <p className="text-sm md:text-base text-muted-foreground">צפייה וניהול של כל הלידים במערכת</p>
        </div>
        <div className={`flex items-center gap-2 ${isMobile ? 'flex-wrap' : 'gap-3'}`}>
          {!isMobile && (
            <>
              <Button variant="outline" className="gap-2" onClick={() => setImportDialogOpen(true)}>
                <Upload className="w-4 h-4" />
                ייבוא CSV
              </Button>
              <Button variant="outline" className="gap-2" onClick={handleExport}>
                <Download className="w-4 h-4" />
                ייצוא
              </Button>
            </>
          )}
          <Button 
            variant="gold" 
            className={`gap-2 ${isMobile ? 'flex-1' : ''}`} 
            onClick={() => setCreateDialogOpen(true)}
          >
            <Plus className="w-4 h-4" />
            ליד חדש
          </Button>
          {isMobile && (
            <Button 
              variant="outline" 
              size="icon"
              onClick={() => setImportDialogOpen(true)}
            >
              <Upload className="w-4 h-4" />
            </Button>
          )}
        </div>
      </div>

      {/* Filters */}
      <LeadFilters
        filters={filters}
        onFiltersChange={setFilters}
        stageCounts={stageCounts}
        profiles={profiles}
      />

      {/* Leads Table / Card View */}
      <LeadsTable
        leads={leads}
        loading={loading}
        onLeadClick={handleLeadClick}
        onCallClick={handleCallClick}
        onMessageClick={handleMessageClick}
        onEmailClick={handleEmailClick}
        onDeleteClick={handleDeleteClick}
        onEditClick={handleEditClick}
      />

      {/* Create Lead Dialog */}
      <CreateLeadDialog
        open={createDialogOpen}
        onOpenChange={setCreateDialogOpen}
        onSubmit={createLead}
        profiles={profiles}
      />

      {/* Import CSV Dialog */}
      <ImportCSVDialog
        open={importDialogOpen}
        onOpenChange={setImportDialogOpen}
        onImportComplete={refetch}
      />

      {/* Edit Lead Dialog */}
      <EditLeadDialog
        lead={leadToEdit}
        open={editDialogOpen}
        onOpenChange={setEditDialogOpen}
        onSubmit={updateLead}
        profiles={profiles}
      />

      {/* Lead Card Dialog */}
      <LeadCard
        lead={selectedLead}
        open={leadCardOpen}
        onOpenChange={setLeadCardOpen}
        onUpdateStage={handleUpdateStage}
        onEdit={() => {
          if (selectedLead) {
            setLeadCardOpen(false);
            handleEditClick(selectedLead);
          }
        }}
        onDelete={() => {
          if (selectedLead) handleDeleteClick(selectedLead);
        }}
      />

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>האם למחוק את הליד?</AlertDialogTitle>
            <AlertDialogDescription>
              פעולה זו תמחק לצמיתות את הליד "{leadToDelete?.full_name}" וכל המידע הקשור אליו.
              לא ניתן לבטל פעולה זו.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="gap-2">
            <AlertDialogCancel>ביטול</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              מחק
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
