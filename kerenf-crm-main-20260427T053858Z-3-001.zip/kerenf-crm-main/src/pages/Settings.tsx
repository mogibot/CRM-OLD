import { useState } from "react";
import { Settings2, CheckCircle, XCircle, Copy, ExternalLink, Play, Loader2, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { format } from "date-fns";

const envVars = [
  { label: "Gemini API Key (חינם)", key: "GEMINI_API_KEY" },
  { label: "WhatsApp Token (Meta)", key: "WHATSAPP_TOKEN" },
  { label: "WhatsApp Phone ID", key: "WHATSAPP_PHONE_ID" },
  { label: "Webhook API Key", key: "WEBHOOK_API_KEY" },
];

const SUPABASE_URL = "https://lhccqntpelmfsfhttkjv.supabase.co";

const endpoints = [
  { label: "WATI Webhook", url: `${SUPABASE_URL}/functions/v1/wati-webhook` },
  { label: "Lead Intake", url: `${SUPABASE_URL}/functions/v1/lead-intake` },
  { label: "Bot Handler", url: `${SUPABASE_URL}/functions/v1/bot-handler` },
  { label: "Send Agent Message", url: `${SUPABASE_URL}/functions/v1/send-agent-message` },
  { label: "Generic Webhook", url: `${SUPABASE_URL}/functions/v1/generic-webhook` },
];

function copyToClipboard(text: string) {
  navigator.clipboard.writeText(text);
  toast.success("הועתק ללוח");
}

export default function Settings() {
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState<{ ok: boolean; message: string } | null>(null);

  const { data: logs, isLoading: logsLoading, refetch: refetchLogs } = useQuery({
    queryKey: ["integration-logs"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("integration_logs")
        .select("id, source, status, error_message, created_at")
        .order("created_at", { ascending: false })
        .limit(20);
      if (error) throw error;
      return data || [];
    },
    staleTime: 30_000,
  });

  const handleTestWebhook = async () => {
    setTesting(true);
    setTestResult(null);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      const res = await fetch(`${SUPABASE_URL}/functions/v1/test-webhook`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...(session?.access_token ? { Authorization: `Bearer ${session.access_token}` } : {}),
        },
        body: JSON.stringify({ test: true, timestamp: new Date().toISOString() }),
      });
      const data = await res.json();
      setTestResult({
        ok: res.ok,
        message: res.ok ? "החיבור תקין!" : `שגיאה: ${data.error || res.statusText}`,
      });
      refetchLogs();
    } catch (err: any) {
      setTestResult({ ok: false, message: `שגיאת רשת: ${err.message}` });
    } finally {
      setTesting(false);
    }
  };

  return (
    <div className="space-y-4 md:space-y-6 max-w-3xl">
      <div>
        <div className="flex items-center gap-2">
          <Settings2 className="w-6 h-6 text-primary" />
          <h1 className="text-xl md:text-2xl font-bold">הגדרות מערכת</h1>
        </div>
        <p className="text-sm text-muted-foreground mt-1">
          חיבורים, מפתחות API וכתובות webhook
        </p>
      </div>

      {/* Connection Status */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <CardTitle className="text-base">סטטוס חיבורים</CardTitle>
          <Button variant="outline" size="sm" className="gap-2" onClick={handleTestWebhook} disabled={testing}>
            {testing ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Play className="w-3.5 h-3.5" />}
            בדוק חיבור
          </Button>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
            <span className="font-medium">Supabase</span>
            <Badge variant="outline" className="bg-green-500/10 text-green-600 border-green-500/20">
              <CheckCircle className="w-3 h-3 ml-1" />
              מחובר
            </Badge>
          </div>
          <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
            <span className="font-medium">WhatsApp Cloud API (Meta)</span>
            <Badge variant="outline" className="bg-yellow-500/10 text-yellow-600 border-yellow-500/20">
              <XCircle className="w-3 h-3 ml-1" />
              צריך הגדרה
            </Badge>
          </div>
          <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
            <span className="font-medium">Gemini Flash (חינם)</span>
            <Badge variant="outline" className="bg-yellow-500/10 text-yellow-600 border-yellow-500/20">
              <XCircle className="w-3 h-3 ml-1" />
              צריך הגדרה
            </Badge>
          </div>
          {testResult && (
            <div className={`p-3 rounded-lg text-sm ${testResult.ok ? "bg-green-500/10 text-green-700" : "bg-red-500/10 text-red-700"}`}>
              {testResult.message}
            </div>
          )}
        </CardContent>
      </Card>

      {/* API Keys */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">מפתחות API (Supabase Secrets)</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {envVars.map((env) => (
            <div key={env.key} className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
              <div>
                <p className="font-medium text-sm">{env.label}</p>
                <p className="text-xs text-muted-foreground font-mono">{env.key}</p>
              </div>
              <span className="text-xs text-muted-foreground">מוגדר ב-Supabase secrets</span>
            </div>
          ))}
          <p className="text-xs text-muted-foreground">
            להגדרת מפתחות: <code className="bg-muted px-1 rounded">supabase secrets set KEY=VALUE</code>
          </p>
        </CardContent>
      </Card>

      {/* Webhook Endpoints */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Webhook Endpoints</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {endpoints.map((ep) => (
            <div key={ep.label} className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
              <div className="min-w-0 flex-1">
                <p className="font-medium text-sm">{ep.label}</p>
                <p className="text-xs text-muted-foreground font-mono truncate">{ep.url}</p>
              </div>
              <Button variant="ghost" size="icon" onClick={() => copyToClipboard(ep.url)} className="shrink-0">
                <Copy className="w-4 h-4" />
              </Button>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Integration Logs */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <CardTitle className="text-base">לוג אינטגרציות</CardTitle>
          <Button variant="ghost" size="icon" onClick={() => refetchLogs()} className="h-8 w-8">
            <RefreshCw className={`w-4 h-4 ${logsLoading ? "animate-spin" : ""}`} />
          </Button>
        </CardHeader>
        <CardContent>
          {logsLoading ? (
            <div className="flex justify-center py-4">
              <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
            </div>
          ) : !logs || logs.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-4">אין לוגים עדיין</p>
          ) : (
            <div className="space-y-2 max-h-80 overflow-y-auto">
              {logs.map((log) => (
                <div key={log.id} className="flex items-center justify-between p-2.5 rounded-lg bg-muted/50 text-sm">
                  <div className="flex items-center gap-3 min-w-0">
                    <Badge
                      variant="outline"
                      className={
                        log.status === "success"
                          ? "bg-green-500/10 text-green-600 border-green-500/20"
                          : log.status === "error"
                          ? "bg-red-500/10 text-red-600 border-red-500/20"
                          : "bg-yellow-500/10 text-yellow-600 border-yellow-500/20"
                      }
                    >
                      {log.status}
                    </Badge>
                    <span className="font-medium">{log.source}</span>
                    {log.error_message && (
                      <span className="text-xs text-muted-foreground truncate max-w-[200px]">{log.error_message}</span>
                    )}
                  </div>
                  <span className="text-xs text-muted-foreground hebrew-nums whitespace-nowrap">
                    {format(new Date(log.created_at), "dd/MM HH:mm")}
                  </span>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Links */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">קישורים שימושיים</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          <a href="https://app.supabase.com/project/lhccqntpelmfsfhttkjv" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-sm text-primary hover:underline">
            <ExternalLink className="w-4 h-4" /> Supabase Dashboard
          </a>
          <a href="https://app.wati.io" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-sm text-primary hover:underline">
            <ExternalLink className="w-4 h-4" /> WATI Dashboard
          </a>
          <a href="https://www.make.com" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-sm text-primary hover:underline">
            <ExternalLink className="w-4 h-4" /> Make.com
          </a>
        </CardContent>
      </Card>
    </div>
  );
}
