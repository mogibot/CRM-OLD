import { useState } from "react";
import { useWorkQueue, WorkQueueItem } from "@/hooks/useWorkQueue";
import { WorkQueueList } from "@/components/workqueue/WorkQueueList";
import { AgentPanel } from "@/components/workqueue/AgentPanel";
import { useIsMobile } from "@/hooks/use-mobile";
import { Loader2, Inbox } from "lucide-react";

export default function WorkQueue() {
  const { items, loading, markDone, snooze, updateAgentNotes } = useWorkQueue();
  const [selectedItem, setSelectedItem] = useState<WorkQueueItem | null>(null);
  const isMobile = useIsMobile();

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-96 text-muted-foreground">
        <Inbox className="w-16 h-16 mb-4 opacity-30" />
        <h2 className="text-xl font-semibold mb-2">אין לידים ממתינים כרגע</h2>
        <p className="text-sm">הבוט מטפל בכל הלידים. אפשר לנוח! 🎉</p>
      </div>
    );
  }

  // Mobile: show either list or panel
  if (isMobile && selectedItem) {
    return (
      <div className="space-y-4">
        <button
          onClick={() => setSelectedItem(null)}
          className="text-sm text-primary hover:underline"
        >
          ← חזרה לרשימה
        </button>
        <AgentPanel
          item={selectedItem}
          onMarkDone={(id) => {
            markDone(id);
            setSelectedItem(null);
          }}
          onSnooze={(id, hours) => {
            snooze({ id, hours });
            setSelectedItem(null);
          }}
          onUpdateNotes={updateAgentNotes}
        />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl md:text-2xl font-bold">תור עבודה</h1>
          <p className="text-sm text-muted-foreground">
            {items.length} לידים ממתינים לטיפולך
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-4 md:gap-6">
        {/* Lead list */}
        <div className="lg:col-span-2">
          <WorkQueueList
            items={items}
            selectedId={selectedItem?.id || null}
            onSelect={setSelectedItem}
          />
        </div>

        {/* Agent panel - desktop only */}
        {!isMobile && (
          <div className="lg:col-span-3">
            {selectedItem ? (
              <AgentPanel
                item={selectedItem}
                onMarkDone={(id) => {
                  markDone(id);
                  setSelectedItem(null);
                }}
                onSnooze={(id, hours) => {
                  snooze({ id, hours });
                  setSelectedItem(null);
                }}
                onUpdateNotes={updateAgentNotes}
              />
            ) : (
              <div className="flex items-center justify-center h-96 border rounded-xl border-dashed text-muted-foreground">
                <p>בחר ליד מהרשימה לצפייה בפרטים</p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
