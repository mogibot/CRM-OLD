import { useState } from "react";
import { Calendar as CalendarIcon, ChevronLeft, ChevronRight, Plus, Clock, MapPin, User, Loader2, Trash2, Pencil } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { cn } from "@/lib/utils";
import { useCalendarEvents, CalendarEventWithLead } from "@/hooks/useCalendarEvents";
import { useLeads } from "@/hooks/useLeads";
import { useIsMobile } from "@/hooks/use-mobile";
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay, addMonths, subMonths } from "date-fns";
import { he } from "date-fns/locale";
import { toast } from "sonner";

const emptyForm = { title: "", description: "", location: "", start_time: "", end_time: "", lead_id: "" };

export default function CalendarPage() {
  const { events, loading, selectedDate, setSelectedDate, createEvent, updateEvent, deleteEvent, getEventsForDate, getUpcomingEvents } = useCalendarEvents();
  const { leads } = useLeads();
  const isMobile = useIsMobile();
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [selectedDayEvents, setSelectedDayEvents] = useState<CalendarEventWithLead[]>([]);
  const [editingEvent, setEditingEvent] = useState<CalendarEventWithLead | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<CalendarEventWithLead | null>(null);
  const [formData, setFormData] = useState(emptyForm);

  const monthStart = startOfMonth(selectedDate);
  const monthEnd = endOfMonth(selectedDate);
  const daysInMonth = eachDayOfInterval({ start: monthStart, end: monthEnd });
  const startDay = monthStart.getDay();
  const emptyDays = Array(startDay).fill(null);
  const dayNames = isMobile ? ["א", "ב", "ג", "ד", "ה", "ו", "ש"] : ["ראשון", "שני", "שלישי", "רביעי", "חמישי", "שישי", "שבת"];

  const handlePrevMonth = () => setSelectedDate(subMonths(selectedDate, 1));
  const handleNextMonth = () => setSelectedDate(addMonths(selectedDate, 1));

  const handleDayClick = (date: Date) => {
    setSelectedDayEvents(getEventsForDate(date));
  };

  const handleCreateEvent = async () => {
    if (!formData.title || !formData.start_time || !formData.end_time) {
      toast.error("נא למלא את כל השדות הנדרשים");
      return;
    }
    try {
      await createEvent({
        title: formData.title,
        description: formData.description || null,
        location: formData.location || null,
        start_time: formData.start_time,
        end_time: formData.end_time,
        lead_id: formData.lead_id || null,
      });
      setIsCreateDialogOpen(false);
      setFormData(emptyForm);
      toast.success("האירוע נוצר בהצלחה");
    } catch {
      toast.error("שגיאה ביצירת האירוע");
    }
  };

  const handleEditClick = (event: CalendarEventWithLead) => {
    setEditingEvent(event);
    setFormData({
      title: event.title,
      description: event.description || "",
      location: event.location || "",
      start_time: event.start_time ? event.start_time.slice(0, 16) : "",
      end_time: event.end_time ? event.end_time.slice(0, 16) : "",
      lead_id: event.lead_id || "",
    });
  };

  const handleUpdateEvent = async () => {
    if (!editingEvent || !formData.title || !formData.start_time || !formData.end_time) {
      toast.error("נא למלא את כל השדות הנדרשים");
      return;
    }
    try {
      await updateEvent(editingEvent.id, {
        title: formData.title,
        description: formData.description || null,
        location: formData.location || null,
        start_time: formData.start_time,
        end_time: formData.end_time,
        lead_id: formData.lead_id || null,
      });
      setEditingEvent(null);
      setFormData(emptyForm);
      // Refresh selected day events
      setSelectedDayEvents((prev) => prev.map((e) => e.id === editingEvent.id ? { ...e, ...formData } : e));
      toast.success("האירוע עודכן בהצלחה");
    } catch {
      toast.error("שגיאה בעדכון האירוע");
    }
  };

  const handleDeleteEvent = async () => {
    if (!deleteTarget) return;
    try {
      await deleteEvent(deleteTarget.id);
      setSelectedDayEvents((prev) => prev.filter((e) => e.id !== deleteTarget.id));
      setDeleteTarget(null);
      toast.success("האירוע נמחק בהצלחה");
    } catch {
      toast.error("שגיאה במחיקת האירוע");
    }
  };

  const upcomingEvents = getUpcomingEvents(5);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  const eventFormFields = (
    <div className="space-y-4 mt-4">
      <div>
        <Label htmlFor="title">כותרת *</Label>
        <Input id="title" value={formData.title} onChange={(e) => setFormData({ ...formData, title: e.target.value })} placeholder="שם האירוע" />
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="start_time">התחלה *</Label>
          <Input id="start_time" type="datetime-local" value={formData.start_time} onChange={(e) => setFormData({ ...formData, start_time: e.target.value })} />
        </div>
        <div>
          <Label htmlFor="end_time">סיום *</Label>
          <Input id="end_time" type="datetime-local" value={formData.end_time} onChange={(e) => setFormData({ ...formData, end_time: e.target.value })} />
        </div>
      </div>
      <div>
        <Label htmlFor="location">מיקום</Label>
        <Input id="location" value={formData.location} onChange={(e) => setFormData({ ...formData, location: e.target.value })} placeholder="כתובת או קישור לזום" />
      </div>
      <div>
        <Label htmlFor="lead_id">שיוך לליד</Label>
        <Select value={formData.lead_id} onValueChange={(value) => setFormData({ ...formData, lead_id: value })}>
          <SelectTrigger>
            <SelectValue placeholder="בחר ליד (אופציונלי)" />
          </SelectTrigger>
          <SelectContent>
            {leads.map((lead) => (
              <SelectItem key={lead.id} value={lead.id}>{lead.full_name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <div>
        <Label htmlFor="description">תיאור</Label>
        <Textarea id="description" value={formData.description} onChange={(e) => setFormData({ ...formData, description: e.target.value })} placeholder="פרטים נוספים" />
      </div>
    </div>
  );

  return (
    <div className="space-y-4 md:space-y-6">
      {/* Header */}
      <div className={`flex ${isMobile ? 'flex-col gap-3' : 'items-center justify-between'}`}>
        <div>
          <h1 className="text-xl md:text-2xl font-bold">יומן</h1>
          <p className="text-sm md:text-base text-muted-foreground">ניהול פגישות ואירועים</p>
        </div>
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button variant="gold" className={isMobile ? "w-full" : ""}>
              <Plus className="w-4 h-4 ml-2" />
              אירוע חדש
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>יצירת אירוע חדש</DialogTitle>
            </DialogHeader>
            {eventFormFields}
            <Button className="w-full" variant="gold" onClick={handleCreateEvent}>צור אירוע</Button>
          </DialogContent>
        </Dialog>
      </div>

      <div className={`grid grid-cols-1 ${isMobile ? '' : 'lg:grid-cols-4'} gap-4 md:gap-6`}>
        {/* Calendar Grid */}
        <div className={`${isMobile ? '' : 'lg:col-span-3'} bg-card rounded-2xl border shadow-kranaf-sm p-4 md:p-6`}>
          {/* Month Navigation */}
          <div className="flex items-center justify-between mb-4 md:mb-6">
            <Button variant="ghost" size="icon" onClick={handlePrevMonth}>
              <ChevronRight className="w-5 h-5" />
            </Button>
            <h2 className="text-lg md:text-xl font-bold">
              {format(selectedDate, "MMMM yyyy", { locale: he })}
            </h2>
            <Button variant="ghost" size="icon" onClick={handleNextMonth}>
              <ChevronLeft className="w-5 h-5" />
            </Button>
          </div>

          {/* Day Names */}
          <div className="grid grid-cols-7 gap-1 md:gap-2 mb-2">
            {dayNames.map((day) => (
              <div key={day} className="text-center text-xs md:text-sm font-medium text-muted-foreground py-1 md:py-2">
                {day}
              </div>
            ))}
          </div>

          {/* Calendar Days */}
          <div className="grid grid-cols-7 gap-1 md:gap-2">
            {emptyDays.map((_, index) => (
              <div key={`empty-${index}`} className="aspect-square" />
            ))}
            {daysInMonth.map((date) => {
              const dayEvents = getEventsForDate(date);
              const isToday = isSameDay(date, new Date());

              return (
                <div
                  key={date.toISOString()}
                  onClick={() => handleDayClick(date)}
                  className={cn(
                    "aspect-square p-1 md:p-2 rounded-lg cursor-pointer transition-colors border",
                    isToday ? "border-primary bg-primary/5" : "border-transparent hover:bg-muted/50",
                    dayEvents.length > 0 && "bg-kranaf-gold/10"
                  )}
                >
                  <div className={cn("text-xs md:text-sm font-medium hebrew-nums", isToday && "text-primary")}>
                    {format(date, "d")}
                  </div>
                  {!isMobile && dayEvents.length > 0 && (
                    <div className="mt-1 space-y-1">
                      {dayEvents.slice(0, 2).map((event) => (
                        <div key={event.id} className="text-xs truncate bg-primary/20 text-primary rounded px-1 py-0.5">
                          {event.title}
                        </div>
                      ))}
                      {dayEvents.length > 2 && (
                        <div className="text-xs text-muted-foreground">+{dayEvents.length - 2} עוד</div>
                      )}
                    </div>
                  )}
                  {isMobile && dayEvents.length > 0 && (
                    <div className="flex justify-center mt-0.5">
                      <div className="w-1.5 h-1.5 rounded-full bg-primary" />
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Upcoming Events Sidebar */}
        <div className="bg-card rounded-2xl border shadow-kranaf-sm p-4 md:p-6">
          <h3 className="text-base md:text-lg font-bold mb-4">אירועים קרובים</h3>
          {upcomingEvents.length === 0 ? (
            <p className="text-muted-foreground text-center py-4 text-sm">אין אירועים קרובים</p>
          ) : (
            <div className="space-y-3">
              {upcomingEvents.map((event) => (
                <div key={event.id} className="p-3 rounded-lg border bg-muted/30 group relative">
                  <div className="absolute top-2 left-2 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => handleEditClick(event)}>
                      <Pencil className="w-3 h-3" />
                    </Button>
                    <Button variant="ghost" size="icon" className="h-6 w-6 text-destructive" onClick={() => setDeleteTarget(event)}>
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  </div>
                  <p className="font-medium text-sm">{event.title}</p>
                  <div className="flex items-center gap-2 mt-1.5 text-xs md:text-sm text-muted-foreground">
                    <Clock className="w-3.5 h-3.5" />
                    <span className="hebrew-nums">{format(new Date(event.start_time), "dd/MM HH:mm")}</span>
                  </div>
                  {event.location && (
                    <div className="flex items-center gap-2 mt-1 text-xs md:text-sm text-muted-foreground">
                      <MapPin className="w-3.5 h-3.5" />
                      <span>{event.location}</span>
                    </div>
                  )}
                  {event.lead_name && (
                    <div className="flex items-center gap-2 mt-1 text-xs md:text-sm text-muted-foreground">
                      <User className="w-3.5 h-3.5" />
                      <span>{event.lead_name}</span>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Selected Day Events */}
      {selectedDayEvents.length > 0 && (
        <div className="bg-card rounded-2xl border shadow-kranaf-sm p-4 md:p-6">
          <h3 className="text-base md:text-lg font-bold mb-4">אירועים ביום שנבחר</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 md:gap-4">
            {selectedDayEvents.map((event) => (
              <div key={event.id} className="p-3 md:p-4 rounded-lg border bg-muted/30">
                <div className="flex items-start justify-between">
                  <p className="font-medium text-sm md:text-base">{event.title}</p>
                  <div className="flex gap-1 mr-2">
                    <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => handleEditClick(event)}>
                      <Pencil className="w-3.5 h-3.5" />
                    </Button>
                    <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive" onClick={() => setDeleteTarget(event)}>
                      <Trash2 className="w-3.5 h-3.5" />
                    </Button>
                  </div>
                </div>
                <div className="flex items-center gap-2 mt-2 text-xs md:text-sm text-muted-foreground">
                  <Clock className="w-3.5 h-3.5" />
                  <span className="hebrew-nums">
                    {format(new Date(event.start_time), "HH:mm")} - {format(new Date(event.end_time), "HH:mm")}
                  </span>
                </div>
                {event.description && (
                  <p className="text-xs md:text-sm text-muted-foreground mt-2">{event.description}</p>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Edit Event Dialog */}
      <Dialog open={!!editingEvent} onOpenChange={(open) => { if (!open) { setEditingEvent(null); setFormData(emptyForm); } }}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>עריכת אירוע</DialogTitle>
          </DialogHeader>
          {eventFormFields}
          <Button className="w-full" variant="gold" onClick={handleUpdateEvent}>שמור שינויים</Button>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={!!deleteTarget} onOpenChange={(open) => { if (!open) setDeleteTarget(null); }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>האם למחוק את האירוע?</AlertDialogTitle>
            <AlertDialogDescription>
              פעולה זו תמחק לצמיתות את האירוע "{deleteTarget?.title}".
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="gap-2">
            <AlertDialogCancel>ביטול</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteEvent} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              מחק
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
