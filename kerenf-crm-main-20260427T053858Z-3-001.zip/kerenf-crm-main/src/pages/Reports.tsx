import { useState } from "react";
import { BarChart3, TrendingUp, Users, Target, Calendar as CalendarIcon, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip, BarChart, Bar, XAxis, YAxis, CartesianGrid, LineChart, Line } from "recharts";
import { useReports } from "@/hooks/useReports";
import { useIsMobile } from "@/hooks/use-mobile";
import { format, subDays, subMonths, startOfMonth, endOfMonth } from "date-fns";
import { he } from "date-fns/locale";

const sourceColors = [
  "hsl(340, 75%, 55%)",
  "hsl(220, 85%, 55%)",
  "hsl(142, 70%, 45%)",
  "hsl(30, 45%, 65%)",
  "hsl(190, 70%, 35%)",
  "hsl(260, 60%, 55%)",
];

const dateRangeOptions = [
  { value: "7d", label: "7 ימים" },
  { value: "30d", label: "30 ימים" },
  { value: "90d", label: "90 ימים" },
  { value: "thisMonth", label: "החודש" },
  { value: "lastMonth", label: "חודש שעבר" },
];

export default function Reports() {
  const isMobile = useIsMobile();
  const [selectedRange, setSelectedRange] = useState("30d");

  const getDateRange = () => {
    const now = new Date();
    switch (selectedRange) {
      case "7d":
        return { start: subDays(now, 7), end: now };
      case "30d":
        return { start: subDays(now, 30), end: now };
      case "90d":
        return { start: subDays(now, 90), end: now };
      case "thisMonth":
        return { start: startOfMonth(now), end: now };
      case "lastMonth":
        const lastMonth = subMonths(now, 1);
        return { start: startOfMonth(lastMonth), end: endOfMonth(lastMonth) };
      default:
        return { start: subDays(now, 30), end: now };
    }
  };

  const { data, loading } = useReports(getDateRange());

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-4 md:space-y-6">
      {/* Header */}
      <div className={`flex ${isMobile ? 'flex-col gap-3' : 'items-center justify-between'}`}>
        <div>
          <h1 className="text-xl md:text-2xl font-bold">דוחות ואנליטיקס</h1>
          <p className="text-sm md:text-base text-muted-foreground">סטטיסטיקות וביצועים</p>
        </div>
        <Select value={selectedRange} onValueChange={setSelectedRange}>
          <SelectTrigger className={isMobile ? "w-full" : "w-48"}>
            <CalendarIcon className="w-4 h-4 ml-2" />
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {dateRangeOptions.map((option) => (
              <SelectItem key={option.value} value={option.value}>
                {option.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4">
        <Card>
          <CardHeader className="pb-1 md:pb-2 p-3 md:p-6">
            <CardTitle className="text-xs md:text-sm font-medium text-muted-foreground">סה"כ לידים</CardTitle>
          </CardHeader>
          <CardContent className="p-3 md:p-6 pt-0">
            <div className="flex items-center gap-2">
              <Users className="w-4 h-4 md:w-5 md:h-5 text-primary" />
              <span className="text-2xl md:text-3xl font-bold hebrew-nums">{data?.totals.totalLeads || 0}</span>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-1 md:pb-2 p-3 md:p-6">
            <CardTitle className="text-xs md:text-sm font-medium text-muted-foreground">המרות</CardTitle>
          </CardHeader>
          <CardContent className="p-3 md:p-6 pt-0">
            <div className="flex items-center gap-2">
              <Target className="w-4 h-4 md:w-5 md:h-5 text-kranaf-success" />
              <span className="text-2xl md:text-3xl font-bold hebrew-nums">{data?.totals.totalConversions || 0}</span>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-1 md:pb-2 p-3 md:p-6">
            <CardTitle className="text-xs md:text-sm font-medium text-muted-foreground">שיעור המרה</CardTitle>
          </CardHeader>
          <CardContent className="p-3 md:p-6 pt-0">
            <div className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4 md:w-5 md:h-5 text-kranaf-gold" />
              <span className="text-2xl md:text-3xl font-bold hebrew-nums">{data?.totals.overallConversionRate || 0}%</span>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-1 md:pb-2 p-3 md:p-6">
            <CardTitle className="text-xs md:text-sm font-medium text-muted-foreground">ממוצע יומי</CardTitle>
          </CardHeader>
          <CardContent className="p-3 md:p-6 pt-0">
            <div className="flex items-center gap-2">
              <BarChart3 className="w-4 h-4 md:w-5 md:h-5 text-kranaf-info" />
              <span className="text-2xl md:text-3xl font-bold hebrew-nums">{data?.totals.avgLeadsPerDay || 0}</span>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-6">
        {/* Leads by Source */}
        <Card>
          <CardHeader className="p-4 md:p-6">
            <CardTitle className="text-base md:text-lg">לידים לפי מקור</CardTitle>
          </CardHeader>
          <CardContent className="p-4 md:p-6 pt-0">
            {data?.leadsBySource && data.leadsBySource.length > 0 ? (
              <div className={isMobile ? "h-52" : "h-64"}>
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={data.leadsBySource}
                      cx="50%"
                      cy="50%"
                      innerRadius={isMobile ? 40 : 60}
                      outerRadius={isMobile ? 65 : 90}
                      paddingAngle={4}
                      dataKey="count"
                      nameKey="source"
                    >
                      {data.leadsBySource.map((_, index) => (
                        <Cell key={`cell-${index}`} fill={sourceColors[index % sourceColors.length]} />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "hsl(var(--card))",
                        border: "1px solid hsl(var(--border))",
                        borderRadius: "0.75rem",
                        direction: "rtl",
                        fontSize: isMobile ? "12px" : "14px",
                      }}
                      formatter={(value: number, name: string) => [`${value} לידים`, name]}
                    />
                    <Legend
                      layout={isMobile ? "horizontal" : "vertical"}
                      align={isMobile ? "center" : "left"}
                      verticalAlign={isMobile ? "bottom" : "middle"}
                      formatter={(value) => <span className="text-xs md:text-sm">{value}</span>}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <div className="h-52 md:h-64 flex items-center justify-center text-muted-foreground">
                אין נתונים להצגה
              </div>
            )}
          </CardContent>
        </Card>

        {/* Leads by Stage */}
        <Card>
          <CardHeader className="p-4 md:p-6">
            <CardTitle className="text-base md:text-lg">לידים לפי שלב</CardTitle>
          </CardHeader>
          <CardContent className="p-4 md:p-6 pt-0">
            {data?.leadsByStage && data.leadsByStage.some(s => s.count > 0) ? (
              <div className={isMobile ? "h-52" : "h-64"}>
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={data.leadsByStage} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis type="number" tick={{ fontSize: isMobile ? 10 : 12 }} />
                    <YAxis type="category" dataKey="stage" width={isMobile ? 70 : 100} tick={{ fontSize: isMobile ? 10 : 12 }} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "hsl(var(--card))",
                        border: "1px solid hsl(var(--border))",
                        borderRadius: "0.75rem",
                        direction: "rtl",
                        fontSize: isMobile ? "12px" : "14px",
                      }}
                    />
                    <Bar dataKey="count" fill="hsl(190, 70%, 35%)" radius={4} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <div className="h-52 md:h-64 flex items-center justify-center text-muted-foreground">
                אין נתונים להצגה
              </div>
            )}
          </CardContent>
        </Card>

        {/* Trends */}
        <Card className="lg:col-span-2">
          <CardHeader className="p-4 md:p-6">
            <CardTitle className="text-base md:text-lg">טרנד לידים לאורך זמן</CardTitle>
          </CardHeader>
          <CardContent className="p-4 md:p-6 pt-0">
            {data?.trends && data.trends.length > 0 ? (
              <div className={isMobile ? "h-56" : "h-80"}>
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={data.trends}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis
                      dataKey="date"
                      tickFormatter={(value) => format(new Date(value), "dd/MM")}
                      tick={{ fontSize: isMobile ? 10 : 12 }}
                    />
                    <YAxis tick={{ fontSize: isMobile ? 10 : 12 }} width={isMobile ? 30 : 40} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "hsl(var(--card))",
                        border: "1px solid hsl(var(--border))",
                        borderRadius: "0.75rem",
                        direction: "rtl",
                        fontSize: isMobile ? "12px" : "14px",
                      }}
                      labelFormatter={(value) => format(new Date(value), "dd/MM/yyyy")}
                    />
                    <Line
                      type="monotone"
                      dataKey="leads"
                      name="לידים"
                      stroke="hsl(190, 70%, 35%)"
                      strokeWidth={2}
                      dot={isMobile ? false : { fill: "hsl(190, 70%, 35%)" }}
                    />
                    <Line
                      type="monotone"
                      dataKey="conversions"
                      name="המרות"
                      stroke="hsl(142, 70%, 45%)"
                      strokeWidth={2}
                      dot={isMobile ? false : { fill: "hsl(142, 70%, 45%)" }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <div className="h-56 md:h-80 flex items-center justify-center text-muted-foreground">
                אין נתונים להצגה
              </div>
            )}
          </CardContent>
        </Card>

        {/* Team Performance */}
        <Card className="lg:col-span-2">
          <CardHeader className="p-4 md:p-6">
            <CardTitle className="text-base md:text-lg">ביצועי צוות</CardTitle>
          </CardHeader>
          <CardContent className="p-4 md:p-6 pt-0">
            {data?.teamPerformance && data.teamPerformance.length > 0 ? (
              <div className="overflow-x-auto -mx-4 md:mx-0">
                <table className="w-full min-w-[400px]">
                  <thead>
                    <tr className="border-b">
                      <th className="text-right py-2 md:py-3 px-3 md:px-4 font-medium text-sm">שם</th>
                      <th className="text-right py-2 md:py-3 px-3 md:px-4 font-medium text-sm">לידים</th>
                      <th className="text-right py-2 md:py-3 px-3 md:px-4 font-medium text-sm">המרות</th>
                      <th className="text-right py-2 md:py-3 px-3 md:px-4 font-medium text-sm">שיעור</th>
                    </tr>
                  </thead>
                  <tbody>
                    {data.teamPerformance.map((member) => (
                      <tr key={member.userId} className="border-b">
                        <td className="py-2 md:py-3 px-3 md:px-4 text-sm">{member.userName}</td>
                        <td className="py-2 md:py-3 px-3 md:px-4 hebrew-nums text-sm">{member.totalLeads}</td>
                        <td className="py-2 md:py-3 px-3 md:px-4 hebrew-nums text-sm">{member.convertedLeads}</td>
                        <td className="py-2 md:py-3 px-3 md:px-4">
                          <span className={`px-2 py-0.5 rounded text-xs md:text-sm hebrew-nums ${
                            member.conversionRate >= 20
                              ? "bg-kranaf-success/10 text-kranaf-success"
                              : member.conversionRate >= 10
                              ? "bg-kranaf-warning/10 text-kranaf-warning"
                              : "bg-muted text-muted-foreground"
                          }`}>
                            {member.conversionRate}%
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="h-40 flex items-center justify-center text-muted-foreground">
                אין נתונים להצגה
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
