import { Users, UserPlus, Bot, Inbox, Loader2 } from "lucide-react";
import { StatsCard } from "@/components/dashboard/StatsCard";
import { LeadSourceChart } from "@/components/dashboard/LeadSourceChart";
import { RecentLeads } from "@/components/dashboard/RecentLeads";
import { ActivityTimeline } from "@/components/dashboard/ActivityTimeline";
import { useDashboardStats } from "@/hooks/useDashboardStats";
import { useWorkQueue } from "@/hooks/useWorkQueue";
import { useIsMobile } from "@/hooks/use-mobile";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";

export default function Dashboard() {
  const isMobile = useIsMobile();
  const { stats, recentLeads, recentActivities, loading, userName } = useDashboardStats();
  const { items: queueItems } = useWorkQueue();
  const navigate = useNavigate();

  const today = new Date();
  const dayNames = ["יום ראשון", "יום שני", "יום שלישי", "יום רביעי", "יום חמישי", "יום שישי", "שבת"];
  const monthNames = ["ינואר", "פברואר", "מרץ", "אפריל", "מאי", "יוני", "יולי", "אוגוסט", "ספטמבר", "אוקטובר", "נובמבר", "דצמבר"];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  const topQueue = queueItems.slice(0, 3);

  return (
    <div className="space-y-4 md:space-y-6">
      {/* Page Header */}
      <div className={`flex ${isMobile ? 'flex-col gap-1' : 'items-center justify-between'}`}>
        <div>
          <h1 className="text-xl md:text-2xl font-bold">שלום, {userName} 👋</h1>
          <p className="text-sm md:text-base text-muted-foreground">הנה סיכום הפעילות שלך להיום</p>
        </div>
        {!isMobile && (
          <div className="text-left">
            <p className="text-sm text-muted-foreground">{dayNames[today.getDay()]}</p>
            <p className="font-bold hebrew-nums">{today.getDate()} ב{monthNames[today.getMonth()]}, {today.getFullYear()}</p>
          </div>
        )}
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4">
        <StatsCard
          title="סה״כ לידים"
          value={stats?.totalLeads.toLocaleString() || "0"}
          change={{ value: stats?.previousPeriodComparison.leadsChange || 0, label: isMobile ? "" : "מהחודש שעבר" }}
          icon={Users}
          variant="teal"
        />
        <StatsCard
          title={isMobile ? "חדשים היום" : "לידים חדשים היום"}
          value={stats?.newLeadsToday.toString() || "0"}
          change={{ value: stats?.previousPeriodComparison.newLeadsChange || 0, label: isMobile ? "" : "מאתמול" }}
          icon={UserPlus}
          variant="gold"
        />
        <StatsCard
          title="בוט פעיל"
          value={stats?.activeBotSessions?.toString() || "0"}
          change={{ value: 0, label: "שיחות ב-24 שעות" }}
          icon={Bot}
          variant="success"
        />
        <StatsCard
          title={isMobile ? "ממתינים" : "ממתינים לנציגה"}
          value={queueItems.length.toString()}
          change={{ value: 0, label: "בתור עבודה" }}
          icon={Inbox}
        />
      </div>

      {/* Work Queue Preview */}
      {topQueue.length > 0 && (
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-base flex items-center gap-2">
                <Inbox className="w-4 h-4 text-destructive" />
                לידים חמים — דורשים טיפול
              </CardTitle>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => navigate("/work-queue")}
              >
                לתור המלא →
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {topQueue.map((item) => (
                <div
                  key={item.id}
                  className="flex items-center justify-between p-3 rounded-lg bg-muted/50 hover:bg-muted cursor-pointer transition-colors"
                  onClick={() => navigate("/work-queue")}
                >
                  <div className="flex items-center gap-3">
                    <span className="font-medium">{item.lead?.full_name || "ללא שם"}</span>
                    {item.lead?.product_interest && item.lead.product_interest !== "unknown" && (
                      <Badge variant="outline" className="text-xs">
                        {item.lead.product_interest}
                      </Badge>
                    )}
                  </div>
                  {item.lead?.bot_score != null && (
                    <Badge variant={item.lead.bot_score >= 80 ? "destructive" : "secondary"}>
                      {item.lead.bot_score}
                    </Badge>
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 md:gap-6">
        <div className="lg:col-span-2 space-y-4 md:space-y-6">
          <RecentLeads leads={recentLeads} />
          {!isMobile && <LeadSourceChart data={stats?.leadsBySource || []} />}
        </div>
        <div className="space-y-4 md:space-y-6">
          {!isMobile && <ActivityTimeline activities={recentActivities} />}
        </div>
      </div>
    </div>
  );
}
